package com.m4ub2b.iezant.model;

public class ApiResponse {
    private boolean apistatus;
    private String message,totalamount,area_manager_id,orderid,distance_km;

    public ApiResponse(boolean apistatus, String message, String totalamount, String area_manager_id, String orderid, String distance_km) {
        this.apistatus = apistatus;
        this.message = message;
        this.totalamount = totalamount;
        this.area_manager_id = area_manager_id;
        this.orderid = orderid;
        this.distance_km = distance_km;
    }

    public boolean isApistatus() {
        return apistatus;
    }

    public void setApistatus(boolean apistatus) {
        this.apistatus = apistatus;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getTotalamount() {
        return totalamount;
    }

    public void setTotalamount(String totalamount) {
        this.totalamount = totalamount;
    }

    public String getArea_manager_id() {
        return area_manager_id;
    }

    public void setArea_manager_id(String area_manager_id) {
        this.area_manager_id = area_manager_id;
    }

    public String getOrderid() {
        return orderid;
    }

    public void setOrderid(String orderid) {
        this.orderid = orderid;
    }

    public String getDistance_km() {
        return distance_km;
    }

    public void setDistance_km(String distance_km) {
        this.distance_km = distance_km;
    }
}
