package com.m4ub2b.iezant.model;

public class WalletBalance {
    private boolean status;
    private String id,message,user_id,wallet_balance,created_at,updated_at;

    public WalletBalance(boolean status, String id, String message, String user_id, String wallet_balance, String created_at, String updated_at) {
        this.status = status;
        this.id = id;
        this.message = message;
        this.user_id = user_id;
        this.wallet_balance = wallet_balance;
        this.created_at = created_at;
        this.updated_at = updated_at;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getWallet_balance() {
        return wallet_balance;
    }

    public void setWallet_balance(String wallet_balance) {
        this.wallet_balance = wallet_balance;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public String getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(String updated_at) {
        this.updated_at = updated_at;
    }
}
