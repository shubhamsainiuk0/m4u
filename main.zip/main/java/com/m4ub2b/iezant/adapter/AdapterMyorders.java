package com.m4ub2b.iezant.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.m4ub2b.iezant.model.MyOrdesModel;
import com.m4ub2b.iezant.R;

public class AdapterMyorders extends RecyclerView.Adapter<AdapterMyorders.ViewHolder> {
  //  private List<AllOrder> allOrderList;
  private MyOrdesModel[] myOrdesModels;
    private Context context;
    private String type;


    public AdapterMyorders(Context context, MyOrdesModel[] myOrdesModels,String type) {
        this.myOrdesModels = myOrdesModels;
        this.context=context;
        this.type=type;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater=LayoutInflater.from(parent.getContext());
        View listItem=layoutInflater.inflate(R.layout.item_myorder_list,parent,false);
    //    AdapterAllOrders.ViewHolder viewHolder=new AdapterAllOrders.ViewHolder(listItem);
        AdapterMyorders.ViewHolder viewHolder=new AdapterMyorders.ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MyOrdesModel allOrder=myOrdesModels[position];
        holder.name.setText(allOrder.getName());
        holder.amount.setText("₹ "+allOrder.getAmount());
        holder.order_id.setText("ORDER NO. : "+allOrder.getOrder_id());
        holder.order_status.setText("Order "+allOrder.getOrder_status());
        if(type.equals("complete")){
        holder.cardView.setCardBackgroundColor(ContextCompat.getColor(context,R.color.light_green_50));}
        if(type.equals("cancel")){
        holder.cardView.setCardBackgroundColor(ContextCompat.getColor(context,R.color.red_50));}

    }

    @Override
    public int getItemCount() {
        return myOrdesModels.length;
    }

    public  static  class ViewHolder extends RecyclerView.ViewHolder{


        TextView name,order_id,order_status,amount;
        CardView cardView;
        LinearLayout lyt_details,lyt_track;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name=(TextView) itemView.findViewById(R.id.order_name);
            order_id=(TextView) itemView.findViewById(R.id.order_id);
            amount=(TextView) itemView.findViewById(R.id.order_amount);
            order_status=(TextView) itemView.findViewById(R.id.order_status);
            cardView=(CardView) itemView.findViewById(R.id.myorderCard);
           // amount=(TextView) itemView.findViewById(R.id.amount);
            lyt_details=itemView.findViewById(R.id.lyt_details);
            lyt_track=itemView.findViewById(R.id.lyt_track);
        }
    }
}
