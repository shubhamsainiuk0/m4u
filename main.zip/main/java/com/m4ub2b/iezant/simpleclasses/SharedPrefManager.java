package com.m4ub2b.iezant.simpleclasses;

import android.content.Context;
import android.content.SharedPreferences;

import com.m4ub2b.iezant.model.User;

public class SharedPrefManager {

    private static  String SHARED_PREF_NAME = "m4ub2b";
    private static  String KEY_ID = "id";
    private static  String KEY_NAME = "keyname";
    private static  String KEY_EMAIL = "keyemail";
    private static  String KEY_MOBILE = "keymobile";
    private static  String KEY_IMAGE = "keyimage";
    private static  String KEY_IMAGEBG = "keyimagebg";
    private static  String KEY_ADDRESS = "keyaddress";
    private static  String KEY_BUSINESS_NAME = "keybusinessname";
    private static  String KEY_BUSINESS_DESCRIPTION = "keybusinessdescription";
    private static  String KEY_ABOUT = "keyabout";
    private static  String KEY_GSTIN = "keygstin";
    private static  String KEY_CAT_ID = "keycatid";
    private static  String KEY_CREATED_AT = "keycreated_at";
    private static  String KEY_IS_APP = "keyisapp";
    private static  String KEY_IS_MOBILE_STATUS = "keyismobilestatus";
    private static SharedPrefManager mInstance;
    private static Context ctx;

    private SharedPrefManager(Context context) {
        ctx = context;
    }
    public static synchronized SharedPrefManager getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new SharedPrefManager(context);
        }
        return mInstance;
    }

    //this method will store the user data in shared preferences
    public void userLogin(User user) {
        SharedPreferences sharedPreferences = ctx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putString(KEY_CAT_ID, user.getCategory_id());
        editor.putString(KEY_ID, user.getId());
        editor.putString(KEY_NAME, user.getName());
        editor.putString(KEY_ADDRESS, user.getAddress());
        editor.putString(KEY_BUSINESS_NAME, user.getBusinessName());
        editor.putString(KEY_BUSINESS_DESCRIPTION, user.getBusiness_description());
        editor.putString(KEY_ABOUT, user.getAbout());
        editor.putString(KEY_GSTIN, user.getGstin());
        editor.putString(KEY_EMAIL, user.getEmail());
        editor.putString(KEY_MOBILE, user.getMobile());
        editor.putString(KEY_IMAGE, user.getImage());
        editor.putString(KEY_IMAGEBG, user.getImagebg());
        editor.putString(KEY_CREATED_AT, user.getCreated_at());
        editor.putString(KEY_IS_APP, user.getIsapp());
        editor.putString(KEY_IS_MOBILE_STATUS, user.getMobilestatus());
        editor.apply();
    }

    //this method will checker whether user is already logged in or not
    public boolean isLoggedIn() {
        SharedPreferences sharedPreferences = ctx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getString(KEY_NAME, null) != null;
    }

    //this method will give the logged in user
    public User getUser() {
        SharedPreferences sharedPreferences = ctx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        return new User(
               sharedPreferences.getString(KEY_ID, null),
               sharedPreferences.getString(KEY_CAT_ID, null),
                sharedPreferences.getString(KEY_NAME, null),
                sharedPreferences.getString(KEY_EMAIL, null),
                sharedPreferences.getString(KEY_MOBILE, null),
                sharedPreferences.getString(KEY_ADDRESS, null),
                sharedPreferences.getString(KEY_BUSINESS_NAME, null),
                sharedPreferences.getString(KEY_BUSINESS_DESCRIPTION, null),
                sharedPreferences.getString(KEY_ABOUT, null),
                sharedPreferences.getString(KEY_GSTIN, null),
                sharedPreferences.getString(KEY_IMAGE, null),
                sharedPreferences.getString(KEY_IMAGEBG, null),
                sharedPreferences.getString(KEY_CREATED_AT, null),
                sharedPreferences.getString(KEY_IS_APP, null),
                sharedPreferences.getString(KEY_IS_MOBILE_STATUS, null)
        );
    }

    //this method will logout the user
    public void logout() {
        SharedPreferences sharedPreferences = ctx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
       // ctx.startActivity(new Intent(ctx, Login.class));
    }
}
