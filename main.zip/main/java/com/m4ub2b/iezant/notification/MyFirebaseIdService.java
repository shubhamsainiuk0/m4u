package com.m4ub2b.iezant.notification;

import com.m4ub2b.iezant.model.User;
import com.m4ub2b.iezant.simpleclasses.SharedPrefManager;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;

public class MyFirebaseIdService extends FirebaseInstanceIdService {

    String user_id;
    @Override
    public void onTokenRefresh(){
        super.onTokenRefresh();
        if(SharedPrefManager.getInstance(getApplicationContext()).isLoggedIn()){

            User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();
            user_id=user.getId();
        }


        String refreshToken= FirebaseInstanceId.getInstance().getToken();
        if(user_id!=null){
            updateToken(refreshToken);
        }
    }

    private void updateToken(String refreshToken) {

        DatabaseReference reference= FirebaseDatabase.getInstance().getReference("Tokens");
        Token token=new Token(refreshToken);
        reference.child(user_id).setValue(token);
    }
}
