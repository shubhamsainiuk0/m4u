package com.m4ub2b.iezant.Chat;

public interface DownloadImage {
}
