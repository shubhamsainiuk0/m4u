package com.m4ub2b.iezant.model;

public class MyOrdesModel {
    String name,order_status,amount,order_id;

    public MyOrdesModel(String name, String order_status, String amount, String order_id) {
        this.name = name;
        this.order_status = order_status;
        this.amount = amount;
        this.order_id = order_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOrder_status() {
        return order_status;
    }

    public void setOrder_status(String order_status) {
        this.order_status = order_status;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }
}
