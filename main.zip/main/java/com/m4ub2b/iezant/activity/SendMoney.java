package com.m4ub2b.iezant.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.delivery.DeliveryOrderDetails;
import com.m4ub2b.iezant.delivery.DeliveryPayment;
import com.m4ub2b.iezant.model.ApiResponse;
import com.m4ub2b.iezant.model.User;
import com.m4ub2b.iezant.model.WalletBalance;
import com.m4ub2b.iezant.simpleclasses.RetrofitClient;
import com.m4ub2b.iezant.simpleclasses.SharedPrefManager;
import com.m4ub2b.iezant.simpleclasses.URLs;
import com.m4ub2b.iezant.utils.Tools;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SendMoney extends AppCompatActivity {

    private TextView walletTextview,pay_to;
    private EditText amount,remarks;
    private String user_id,send_to,uname,amount_,remarks_,token;
    private Button btn_submit;
    private double wallet,transfer_amount;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_money);
        initToolbar();
        initComponent();
        getBalance();
    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(null);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Tools.setSystemBarColor(this, android.R.color.white);
        Tools.setSystemBarLight(this);
    }
    private void initComponent() {
        token= URLs.TOKEN;
        send_to=getIntent().getExtras().getString("send_to");
        uname=getIntent().getExtras().getString("uname");

        if(SharedPrefManager.getInstance(getApplicationContext()).isLoggedIn()){
            User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();
            user_id=user.getId();
        }

        walletTextview=findViewById(R.id.wallet);
        btn_submit=findViewById(R.id.btn_submit);
        amount=findViewById(R.id.amount);
        remarks=findViewById(R.id.remarks);
        pay_to=findViewById(R.id.pay_to);

        //walletTextview.setText((int) wallet);
        pay_to.setText("Pay to "+uname);

        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkData();
            }
        });
    }

    private void checkData() {
        amount_ = amount.getText().toString();
        remarks_ = remarks.getText().toString();
        if (TextUtils.isEmpty(amount_)) {
            amount.setError("Please enter");
            amount.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(remarks_)) {
            remarks.setError("Please enter");
            remarks.requestFocus();
            return;
        }
        transfer_amount=Double.parseDouble(amount_);
        if (wallet<=transfer_amount){
            Toast.makeText(SendMoney.this, "Insufficient wallet balance, TOP UP your wallet", Toast.LENGTH_LONG).show();
        }
        else{
            sendMoney();
        }
    }

    private void sendMoney() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();
        Call<ApiResponse> call = RetrofitClient.getInstance().getApi().transferMoney(token,user_id,send_to,transfer_amount,remarks_);
        call.enqueue(new Callback<ApiResponse>() {
            @Override
            public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                progressDialog.dismiss();
                if (response.body().isApistatus()) {
                    Toast.makeText(SendMoney.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(SendMoney.this,UserWallet.class));
                    finish();
                }
                else{
                    Toast.makeText(SendMoney.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onFailure(Call<ApiResponse> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

    }

    private void getBalance() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();
        Call<WalletBalance> call = RetrofitClient.getInstance().getApi().walletbalance(user_id);
        call.enqueue(new Callback<WalletBalance>() {
            @Override
            public void onResponse(Call<WalletBalance> call, Response<WalletBalance> response) {
                progressDialog.dismiss();
                if (response.body().isStatus()) {
                    wallet=Double.parseDouble(response.body().getWallet_balance());
                    walletTextview.setText("₹ "+response.body().getWallet_balance()+".0");
                    walletTextview.setText("₹ "+response.body().getWallet_balance()+".0");
                }
                else{
                    wallet=0;
                    walletTextview.setText("₹ 0");
                }
            }
            @Override
            public void onFailure(Call<WalletBalance> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        } else {
            Toast.makeText(getApplicationContext(), item.getTitle(), Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }
}