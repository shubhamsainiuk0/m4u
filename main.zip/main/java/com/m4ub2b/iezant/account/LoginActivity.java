package com.m4ub2b.iezant.account;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.m4ub2b.iezant.MainActivity;
import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.model.User;
import com.m4ub2b.iezant.simpleclasses.RetrofitClient;
import com.m4ub2b.iezant.simpleclasses.SharedPrefManager;
import com.google.android.material.textfield.TextInputEditText;
import com.m4ub2b.iezant.utils.MyReceiver;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    private TextInputEditText etEmail, etPassword;
    TextView sign_up,forget_pwd;
    private Button btn_login;
    private BroadcastReceiver MyReceiver = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        sign_up=findViewById(R.id.sign_up);

        if (SharedPrefManager.getInstance(LoginActivity.this).isLoggedIn()) {
            startActivity(new Intent(LoginActivity.this, MainActivity.class));
            finish();
        }
        MyReceiver = new MyReceiver();
        broadcastIntent();

        initComponent();

    }

    private void initComponent() {
        sign_up=findViewById(R.id.sign_up);
        forget_pwd=findViewById(R.id.forget_pwd);
        btn_login=findViewById(R.id.btn_login);
        etEmail=findViewById(R.id.email);
        etPassword=findViewById(R.id.password);

        sign_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),SignupActivity.class);
                startActivity(intent);
                finish();
            }
        });
        forget_pwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(), ForgetPasswordActivity.class);
                startActivity(intent);
            }
        });
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                userLogin();
            }
        });
    }
    private void userLogin() {

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();

        //first getting the values
        final String username = etEmail.getText().toString();
        final String password = etPassword.getText().toString();
        //validating inputs
        if (TextUtils.isEmpty(username)) {
            etEmail.setError("Please enter your Email Id");
            etEmail.requestFocus();
            progressDialog.dismiss();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            etPassword.setError("Please enter your password");
            progressDialog.dismiss();
            etPassword.requestFocus();
            return;
        }

        Call<User> call = RetrofitClient.getInstance().getApi().login(username,password);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                progressDialog.dismiss();

                Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                if (response.body().isStatus()) {

                    SharedPrefManager.getInstance(getApplicationContext()).userLogin(response.body());

                    startActivity(new Intent(LoginActivity.this, MainActivity.class));
                    finish();
                }
                else{
                    Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    public void broadcastIntent() {
        registerReceiver(MyReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(MyReceiver);
    }

}