package com.m4ub2b.iezant.Chat;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.balysv.materialripple.MaterialRippleLayout;
import com.bumptech.glide.Glide;
import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.model.User;
import com.m4ub2b.iezant.simpleclasses.SharedPrefManager;
import com.m4ub2b.iezant.simpleclasses.URLs;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;


    public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.ViewHolder> {

    private List<ChatList> chatLists;
    private Context context;
    private boolean isChatt;

    String theLastMessage,user_id,timee;
    static int msgCount=0;

    public HistoryAdapter(List<ChatList> chatLists,Context context,Boolean isChatt){
        this.chatLists=chatLists;
        this.context=context;
        this.isChatt=isChatt;
        if(SharedPrefManager.getInstance(context).isLoggedIn()){

            User user = SharedPrefManager.getInstance(context).getUser();
            user_id=user.getId();
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.item_chat_history, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {


        final ChatList user=chatLists.get(position);
        holder.username.setText(user.getName());
        holder.msgIconType.setVisibility(View.GONE);
        holder.sent.setVisibility(View.GONE);
        Log.d("userIdMsg",user.getId());
        lastMessage(user.getId(),holder.lastMsg,holder.time,holder.countMsg,holder.msgIconType,holder.sent);
        Glide.with(context).load(URLs.IMAGE_URL+user.getImage()).error(Glide.with(context).load(R.drawable.user_1)).into(holder.userImage);

        holder.materialChatItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(context, MessageActivity.class);
                intent.putExtra("uid",user.getId());
                intent.putExtra("namee",user.getName());
                intent.putExtra("image",user.getImage());
                intent.putExtra("enquiry","false");
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return chatLists.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public CircleImageView userImage;
        public TextView username,lastMsg,time,countMsg;
        public MaterialRippleLayout materialChatItem;
        public ImageView msgIconType,sent;
       // public CardView chatOn,chatOff;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            this.userImage=itemView.findViewById(R.id.image);
            this.sent=itemView.findViewById(R.id.sent);
            this.msgIconType=itemView.findViewById(R.id.msgiconType);
            this.username=itemView.findViewById(R.id.name);
            this.time=itemView.findViewById(R.id.time);
            this.countMsg=itemView.findViewById(R.id.countMsg);
            this.lastMsg=itemView.findViewById(R.id.last_msg);
            this.materialChatItem=itemView.findViewById(R.id.materialChatItem);
           /* this.chatOff=itemView.findViewById(R.id.chatOff);
            this.chatOn=itemView.findViewById(R.id.chatOn);
*/
        }
    }
    private void lastMessage(final String receiver_id, final TextView lastMsg,final TextView time,final TextView countMsg, final ImageView msgIconType,final ImageView sent){
       theLastMessage="default";
       msgCount=0;
        DatabaseReference reference= FirebaseDatabase.getInstance().getReference("Chats");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot dataSnapshot:snapshot.getChildren()){
                    //msgCount++;
                    ChatModel chat=dataSnapshot.getValue(ChatModel.class);
                    if(chat.getReceiver().equals(user_id)&&chat.getSender().equals(receiver_id)||
                            chat.getReceiver().equals(receiver_id)&&chat.getSender().equals(user_id)){
                        msgIconType.setVisibility(View.GONE);
                        sent.setVisibility(View.GONE);
                        timee=chat.getTime();

                        if(chat.getSender().equals(receiver_id)){
                           if (chat.isIsseen()==false){
                            msgCount++; }
                        }
                        if(chat.getSender().equals(user_id)){
                            if (chat.isIsseen()){
                                sent.setImageResource(R.drawable.ic_done_all);
                                sent.setColorFilter(ContextCompat.getColor(context,R.color.blue_500));
                                sent.setVisibility(View.VISIBLE);
                            }
                            else {
                                sent.setImageResource(R.drawable.ic_done);
                                sent.setColorFilter(ContextCompat.getColor(context,R.color.grey_80));
                                sent.setVisibility(View.VISIBLE);
                            }
                        }
                        if(chat.getType().equals("text")){

                           theLastMessage=chat.getMessage();
                        }
                        else if(chat.getType().equals("image")){

                            theLastMessage="Photo";
                            msgIconType.setImageResource(R.drawable.ic_photo);
                            msgIconType.setVisibility(View.VISIBLE);
                        }
                        else{

                            theLastMessage="Document File";
                            msgIconType.setImageResource(R.drawable.ic_document);
                            msgIconType.setVisibility(View.VISIBLE);
                        }
                    }
                    //String
                    time.setText(timee);

                    lastMsg.setText(theLastMessage);

                }
                if (msgCount>0){
                    countMsg.setVisibility(View.VISIBLE);
                    countMsg.setText(String.valueOf(msgCount));
                }
                msgCount=0;
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}
