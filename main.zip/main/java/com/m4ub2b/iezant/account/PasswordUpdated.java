package com.m4ub2b.iezant.account;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.Toolbar;

import com.m4ub2b.iezant.MainActivity;
import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.simpleclasses.SharedPrefManager;
import com.m4ub2b.iezant.utils.Tools;
import com.google.android.material.textfield.TextInputEditText;

public class PasswordUpdated extends AppCompatActivity {

    private TextInputEditText etEmail, etPassword;
    TextView sign_in;
    private AppCompatButton btn_submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password_updated);

         if (SharedPrefManager.getInstance(PasswordUpdated.this).isLoggedIn()) {
            startActivity(new Intent(PasswordUpdated.this, MainActivity.class));
            finish();
        }
        initToolbar();
        initComponent();

    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(null);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Tools.setSystemBarColor(this, android.R.color.white);
        Tools.setSystemBarLight(this);
    }

    private void initComponent() {
        btn_submit=findViewById(R.id.btn_submit);

        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               startActivity(new Intent(PasswordUpdated.this, LoginActivity.class));
               finish();
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        } else {
            Toast.makeText(getApplicationContext(), item.getTitle(), Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }

}