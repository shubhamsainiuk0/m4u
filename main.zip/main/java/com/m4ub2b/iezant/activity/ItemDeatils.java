package com.m4ub2b.iezant.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import android.Manifest;
import android.app.Dialog;
import android.app.DownloadManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.m4ub2b.iezant.Chat.MessageActivity;
import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.adapter.AdapterPostImageSlider;
import com.m4ub2b.iezant.adapter.AdapterUserPosts;
import com.m4ub2b.iezant.maps.MapsActivity;
import com.m4ub2b.iezant.model.PostDataResponse;
import com.m4ub2b.iezant.model.PostImageSlider;
import com.m4ub2b.iezant.model.SellerPostResponse;
import com.m4ub2b.iezant.model.User;
import com.m4ub2b.iezant.simpleclasses.RetrofitClient;
import com.m4ub2b.iezant.simpleclasses.URLs;
import com.github.chrisbanes.photoview.PhotoView;
import com.mikhaellopez.circularimageview.CircularImageView;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ItemDeatils extends AppCompatActivity {

    TextView name,address,orderNow,bName,bDesc,about,nameU,user_name,bank_name,ifsc_code,acc_number,phonepe,googlepay,paytm;
    ImageView imagebg;
    View bank_details_view;
    CircularImageView image;
    LinearLayout callNow,userLocation;
    String mobile,cat_id, uid,uname,imagee,imagebgg,bNamee,bDescc,aboutt;
    Double   latitude,longitude;
    ViewPager2 viewPager2;
    AdapterPostImageSlider adapter;
    private Runnable runnable = null;
    private Handler handler = new Handler();
    private static int currentPage = 0;
    private static int NUM_PAGES = 3;
    LinearLayout indicatorlay,bank_details_ll;
    private RecyclerView recyclerView;
    private AdapterUserPosts mAdapter;
    List<SellerPostResponse> userList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_deatils);
        initToolbar();
        initComponent();
       // initSlider();
        //sliderTimeHandler();

    }


    private void initToolbar() {
        androidx.appcompat.widget.Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_chevron_left_white);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(null);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }
    private void initComponent() {
        name=findViewById(R.id.name);
        bName=findViewById(R.id.bName);
        nameU=findViewById(R.id.nameU);
        bDesc=findViewById(R.id.bDesc);
        about=findViewById(R.id.about);
        address=findViewById(R.id.address);
        orderNow=findViewById(R.id.orderNow);
        image=findViewById(R.id.image);
        imagebg=findViewById(R.id.imagebg);
        callNow=findViewById(R.id.callNow);
        userLocation=findViewById(R.id.userLocation);
        indicatorlay=(LinearLayout) findViewById(R.id.layout_dots);

        bank_details_ll=(LinearLayout) findViewById(R.id.hidebank_details_ll);
        bank_details_view=findViewById(R.id.hidebank_detailsView);
        user_name=findViewById(R.id.user_name);
        bank_name=findViewById(R.id.bank_name);
        ifsc_code=findViewById(R.id.ifsc_code);
        acc_number=findViewById(R.id.acc_number);
        phonepe=findViewById(R.id.phonepe);
        googlepay=findViewById(R.id.googlepay);
        paytm=findViewById(R.id.paytm);

        //viewPager2 = (ViewPager2) findViewById(R.id.post_slider);
        uid=getIntent().getExtras().getString("uid");
        userdata();


        recyclerView = (RecyclerView) findViewById(R.id.recyclerViewPost);
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(getApplicationContext());
        linearLayoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(linearLayoutManager);

        recyclerView.setHasFixedSize(true);
        recyclerView.setNestedScrollingEnabled(false);
        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                zoomProfile(imagee);
            }

        });
        imagebg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                zoomProfileBG(imagebgg);
            }

        });
        orderNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(), MessageActivity.class);

                intent.putExtra("namee",uname);
                intent.putExtra("uid",uid);
                intent.putExtra("image",imagee);
                intent.putExtra("enquiry","false");
                startActivity(intent);
            }
        });
        callNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               callPhoneNumber();
            }
        });
        userLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(latitude==null){
                    Toast.makeText(ItemDeatils.this, "User not updated his location", Toast.LENGTH_SHORT).show();
                }
                else{
                    Intent intent=new Intent(ItemDeatils.this, MapsActivity.class);
                    intent.putExtra("latitude",latitude);
                    intent.putExtra("longitude",longitude);
                    intent.putExtra("name",uname);
                    startActivity(intent);

                    }
            }
        });

    }

    private void zoomProfile(String imagee)  {
        final Dialog dialog = new Dialog(ItemDeatils.this,R.style.DialogTheme);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
        dialog.setContentView(R.layout.activity_chat_image_view);
        PhotoView imageView=dialog.findViewById(R.id.imageViewChat);
        ImageButton imageButton=dialog.findViewById(R.id.bt_close);
        dialog.setCancelable(true);
        dialog.show();
        Button bt_save=dialog.findViewById(R.id.bt_save);
        Glide.with(ItemDeatils.this).load(URLs.IMAGE_URL+imagee).into(imageView);

        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        bt_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try{
                    DownloadManager dm = (DownloadManager) getApplicationContext().getSystemService(Context.DOWNLOAD_SERVICE);
                    Uri downloadUri = Uri.parse(URLs.IMAGE_URL+imagee);
                    DownloadManager.Request request = new DownloadManager.Request(downloadUri);
                    request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI | DownloadManager.Request.NETWORK_MOBILE)
                            .setAllowedOverRoaming(false)
                            .setTitle("Image Downloading")
                            .setMimeType("image/jpeg") // Your file type. You can use this code to download other file types also.
                            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                            .setDestinationInExternalPublicDir(Environment.DIRECTORY_PICTURES, File.separator +  "profile_"+uid + ".jpg");
                    dm.enqueue(request);
                    Toast.makeText(getApplicationContext(), "Image download started.", Toast.LENGTH_SHORT).show();
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(), "Image download failed.", Toast.LENGTH_SHORT).show();
                }

            }
        });

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.BLACK));

        dialog.setCancelable(true);
        dialog.show();
    }
    private void zoomProfileBG(String imageebg)  {
        final Dialog dialog = new Dialog(ItemDeatils.this,R.style.DialogTheme);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
        dialog.setContentView(R.layout.activity_chat_image_view);
        PhotoView imageView=dialog.findViewById(R.id.imageViewChat);
        ImageButton imageButton=dialog.findViewById(R.id.bt_close);
        dialog.setCancelable(true);
        dialog.show();
        Button bt_save=dialog.findViewById(R.id.bt_save);
        Glide.with(ItemDeatils.this).load(URLs.IMAGE_URL+imageebg).into(imageView);

        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        bt_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try{
                    DownloadManager dm = (DownloadManager) getApplicationContext().getSystemService(Context.DOWNLOAD_SERVICE);
                    Uri downloadUri = Uri.parse(URLs.IMAGE_URL+imageebg);
                    DownloadManager.Request request = new DownloadManager.Request(downloadUri);
                    request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI | DownloadManager.Request.NETWORK_MOBILE)
                            .setAllowedOverRoaming(false)
                            .setTitle("Image Downloading")
                            .setMimeType("image/jpeg") // Your file type. You can use this code to download other file types also.
                            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                            .setDestinationInExternalPublicDir(Environment.DIRECTORY_PICTURES, File.separator + "bgimage_"+uid + ".jpg");
                    dm.enqueue(request);
                    Toast.makeText(getApplicationContext(), "Image download started.", Toast.LENGTH_SHORT).show();
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(), "Image download failed.", Toast.LENGTH_SHORT).show();
                }

            }
        });

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.BLACK));

        dialog.setCancelable(true);
        dialog.show();
    }
    private void userdata() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();
        Call<User> call = RetrofitClient.getInstance().getApi().userbyid(uid);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                progressDialog.dismiss();

                User user= response.body();
                if(user.isStatus()) {
                    uname=user.getName();
                    cat_id=user.getCategory_id();
                    setAdapter(cat_id);
                    imagee=user.getImage();
                    imagebgg=user.getImagebg();
                    bNamee=user.getBusiness_name();
                    bDescc=user.getBusiness_description();
                    aboutt=user.getAbout();
                    mobile=user.getMobile();
                    address.setText(user.getAddress());
                    latitude=user.getLatitude();
                    longitude=user.getLongitude();

                    bank_name.setText("Bank Name : "+user.getBank_name());
                    user_name.setText("User Name : "+user.getUser_bank_name());
                    ifsc_code.setText("IFSC Code : "+user.getIfsc_code());
                    acc_number.setText("Account Number : "+user.getAcc_number());
                    phonepe.setText("PhonePe Number : "+user.getPhonepe());
                    googlepay.setText("GooglePay Number : "+user.getGooglepay());
                    paytm.setText("PayTm Number : "+user.getPaytm());

                    if(user.getUser_bank_name()!=null ){
                        bank_details_ll.setVisibility(View.VISIBLE);
                        bank_details_view.setVisibility(View.VISIBLE);
                    }else{
                        bank_details_ll.setVisibility(View.GONE);
                        bank_details_view.setVisibility(View.GONE);
                    }
                    if(user.getPhonepe()!=null ){
                        phonepe.setVisibility(View.VISIBLE);
                    }
                    if(user.getGooglepay()!=null ){
                        googlepay.setVisibility(View.VISIBLE);
                    }
                    if(user.getPaytm()!=null ){
                        paytm.setVisibility(View.VISIBLE);

                    }

                    if(bNamee==null){bName.setText("Not Updated"); }
                    else {bName.setText(bNamee);
                    }

                    if (bDescc==null){bDesc.setText("Not Updated");}
                    else {bDesc.setText(bDescc);}

                    if (aboutt==null){about.setText("Not Updated");}
                    else {about.setText(aboutt);}
                    Glide.with(getApplicationContext()).load(URLs.IMAGE_URL+imagee).into(image);
                    Glide.with(getApplicationContext()).load(URLs.IMAGE_URL+imagebgg).into(imagebg);
                }

            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });


    }

    private void setAdapter(String cat_id) {

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();
        Log.d("myidcat",uid+","+cat_id);
        Call<PostDataResponse> call = RetrofitClient.getInstance().getApi().userposts(uid,cat_id);
        call.enqueue(new Callback<PostDataResponse>() {
            @Override
            public void onResponse(Call<PostDataResponse> call, Response<PostDataResponse> response) {
                progressDialog.dismiss();

                PostDataResponse userDataResponse= response.body();
                if(userDataResponse.isApistatus()){
                    userList=new ArrayList<>(Arrays.asList(userDataResponse.getPost()));
                    mAdapter = new AdapterUserPosts(ItemDeatils.this, userList,uname,imagee,"123321");
                    recyclerView.setAdapter(mAdapter);
                }
            }

            @Override
            public void onFailure(Call<PostDataResponse> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

    }

    public void callPhoneNumber()
    {
        try
        {
            if(Build.VERSION.SDK_INT > 22)
            {
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    ActivityCompat.requestPermissions(ItemDeatils.this, new String[]{Manifest.permission.CALL_PHONE}, 101);

                    return;
                }

                Intent callIntent = new Intent(Intent.ACTION_CALL);
                callIntent.setData(Uri.parse("tel:" + mobile));
                startActivity(callIntent);

            }
            else {
                Intent callIntent = new Intent(Intent.ACTION_CALL);
                callIntent.setData(Uri.parse("tel:" + mobile));
                startActivity(callIntent);
            }
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults)
    {
        if(requestCode == 101)
        {
            if(grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                callPhoneNumber();
            }
            else
            {
                Log.e("callpermission", "Permission not Granted");
            }
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.share_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        } else {
            Toast.makeText(getApplicationContext(), item.getTitle(), Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }

    private void initSlider() {
        PostImageSlider[] imageSlider=new PostImageSlider[]{
                new PostImageSlider(R.drawable.banner_1),
                new PostImageSlider(R.drawable.shopping_banner),
                new PostImageSlider(R.drawable.banner_1),
        };
        adapter = new AdapterPostImageSlider(ItemDeatils.this,imageSlider);

        viewPager2.setAdapter(adapter);
        setupIndicator();
        setupCurrentIndicator(0);

        viewPager2.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                setupCurrentIndicator(position);
            }
        });

    }
    private void sliderTimeHandler() {

        runnable = new Runnable() {
            @Override
            public void run() {
                int pos = viewPager2.getCurrentItem();
                pos = pos + 1;
                if (pos >= NUM_PAGES) pos = 0;
                viewPager2.setCurrentItem(pos);
                handler.postDelayed(runnable, 3000);
            }
        };
        handler.postDelayed(runnable, 3000);

    }

    private void setupIndicator() {
        ImageView[] indicator=new ImageView[adapter.getItemCount()];
        LinearLayout.LayoutParams layoutParams=new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        );
        layoutParams.setMargins(4,0,4,0);
        for (int i=0; i<indicator.length; i++){
            indicator[i]=new ImageView(ItemDeatils.this);
            indicator[i].setImageDrawable(ContextCompat.getDrawable(ItemDeatils.this,R.drawable.inactive_indicator));
            indicator[i].setLayoutParams(layoutParams);
            indicatorlay.addView(indicator[i]);
        }

    }
    private void setupCurrentIndicator(int index) {
        int itemcildcount=indicatorlay.getChildCount();
        for (int i=0; i<itemcildcount; i++){
            ImageView imageView=(ImageView)indicatorlay.getChildAt(i);
            if (i==index){
                imageView.setImageDrawable(ContextCompat.getDrawable(ItemDeatils.this,R.drawable.active_indicator));
            }else {
                imageView.setImageDrawable(ContextCompat.getDrawable(ItemDeatils.this,R.drawable.inactive_indicator));
            }
        }
    }

}
