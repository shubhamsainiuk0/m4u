package com.m4ub2b.iezant.model;

public class SavedAddresses {
    private boolean apistatus;
    private String message;
    private SavedAddress[] addressList;

    private SavedAddress savedAddress;

    public boolean isApistatus() {
        return apistatus;
    }
     public SavedAddress getSavedAddress() {
        return savedAddress;
    }

    public String getMessage() {
        return message;
    }

    public SavedAddress[] getAddressList() {
        return addressList;
    }
}

