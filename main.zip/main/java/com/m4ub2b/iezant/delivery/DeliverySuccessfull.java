package com.m4ub2b.iezant.delivery;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.model.User;
import com.m4ub2b.iezant.simpleclasses.SharedPrefManager;


public class DeliverySuccessfull extends AppCompatActivity {

    Button btn_save;
    TextView orderid,user_name;
    String user_name_;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery_successfull);
        initToolbar();
        initComponent();
    }
    private void initToolbar() {
        androidx.appcompat.widget.Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_chevron_left);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Order Successfull");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    private void initComponent() {
     orderid=findViewById(R.id.orderid);
     user_name=findViewById(R.id.user_name);
     btn_save=findViewById(R.id.btn_save);
        if (SharedPrefManager.getInstance(DeliverySuccessfull.this).isLoggedIn()) {
            User customer = SharedPrefManager.getInstance(getApplicationContext().getApplicationContext()).getUser();
            user_name_=customer.getName();
        }
     user_name.setText("Thank you " +user_name_+" for choosing us!");
     orderid.setText("Your shipment is confirmed. Your ORDER ID is # "+getIntent().getExtras().getString("orderid"));
    btn_save.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent=new Intent(DeliverySuccessfull.this, PackagingSlip.class);
            intent.putExtra("order_id",getIntent().getExtras().getString("orderid"));
            startActivity(intent);
            finish();
        }
    });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        } else {
            Toast.makeText(getApplicationContext(), item.getTitle(), Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }

}