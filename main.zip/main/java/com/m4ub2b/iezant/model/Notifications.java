package com.m4ub2b.iezant.model;

import android.graphics.drawable.Drawable;

public class Notifications {

    public int image;
    public Drawable imageDrw;
    public String name;
    public String email;
    public boolean section = false;

    public Notifications() {
    }

    public Notifications(int image,  String name, String email, boolean section) {
        this.image = image;
       // this.imageDrw = imageDrw;
        this.name = name;
        this.email = email;
        this.section = section;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public Drawable getImageDrw() {
        return imageDrw;
    }

    public void setImageDrw(Drawable imageDrw) {
        this.imageDrw = imageDrw;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isSection() {
        return section;
    }

    public void setSection(boolean section) {
        this.section = section;
    }
}