package com.m4ub2b.iezant.ui.home;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.m4ub2b.iezant.Chat.ChatModel;
import com.m4ub2b.iezant.account.AddLocation;
import com.m4ub2b.iezant.account.LoginActivity;
import com.m4ub2b.iezant.MainActivity;
import com.m4ub2b.iezant.account.ProfileActivity;
import com.m4ub2b.iezant.activity.Categories;
import com.m4ub2b.iezant.activity.ChatHistory;
import com.m4ub2b.iezant.activity.MyMapTest;
import com.m4ub2b.iezant.delivery.EasyShipping;
import com.m4ub2b.iezant.account.ProfileDeatils;
import com.m4ub2b.iezant.activity.NewPost;
import com.m4ub2b.iezant.account.UpdateProfileActivity;
import com.m4ub2b.iezant.activity.UserWallet;
import com.m4ub2b.iezant.delivery.MyOrders;
import com.m4ub2b.iezant.model.PostDataResponse;
import com.m4ub2b.iezant.model.SellerPostResponse;
import com.m4ub2b.iezant.model.User;
import com.m4ub2b.iezant.model.UserDataResponse;
import com.m4ub2b.iezant.notification.Token;
import com.m4ub2b.iezant.seller.SellerChatHistory;
import com.m4ub2b.iezant.simpleclasses.RetrofitClient;
import com.m4ub2b.iezant.simpleclasses.SharedPrefManager;
import com.m4ub2b.iezant.simpleclasses.URLs;
import com.google.android.material.navigation.NavigationView;
import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.adapter.*;
import com.m4ub2b.iezant.utils.Tools;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;
import com.mikhaellopez.circularimageview.CircularImageView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel;
    private View root;
    TextView name,email;
    CircularImageView avatar;
    DatabaseReference databaseReference;
    private Menu menu;
    private RecyclerView recyclerView;
    private AdapterCategoryItemList mAdapter;
    private AdapterHomePosts mAdapterr;
    List<User> userList;
    String category_id,user_id;
    private String isappp="0";
    private ActionBar actionBar;
    private Toolbar toolbar;
    private NavigationView  navigationView ;
    private DrawerLayout drawer;
    List<SellerPostResponse> postList;

    int page_no=0,page_size=8;
    LinearLayoutManager layoutManager;
    private boolean isLoading=true;
    private int pastVisibleItems,visibleItemCount,totalItemCount,previous_total=0;
    private int viewThreshHold=0;
    ProgressDialog progressDialog;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);
        root = inflater.inflate(R.layout.fragment_home, container, false);
        initToolbar();
        initComponent();
        initNavigationMenu();

        setHasOptionsMenu(true);
        return root;
    }

    private void initToolbar() {

        toolbar = (Toolbar) root.findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_apps);
        toolbar.getNavigationIcon().setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_ATOP);
         //nav_view = (NavigationView) root.findViewById(R.id.nav_view);
        drawer = (DrawerLayout) root.findViewById(R.id.drawer_layout);
        ((AppCompatActivity)getActivity()).setSupportActionBar(toolbar);
        ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("");
        ((AppCompatActivity)getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Tools.setSystemBarColor((Activity) mContext, android.R.color.white);
        Tools.setSystemBarLight((Activity) mContext);

        navigationView = (NavigationView) root.findViewById(R.id.nav_vieww);
        View headerView = navigationView.getHeaderView(0);
        name=(TextView) headerView.findViewById(R.id.userName);
        email=(TextView) headerView.findViewById(R.id.userEmail);
        avatar=(CircularImageView) headerView.findViewById(R.id.avatar);

        if(SharedPrefManager.getInstance(mContext).isLoggedIn()){

            User user = SharedPrefManager.getInstance(mContext).getUser();
            //Toast.makeText(mContext, "Wow :"+user.getOwnerName()+ "" +user.getUserEmail(), Toast.LENGTH_SHORT).show();
            name.setText(user.getName());
            email.setText(user.getEmail());

            Glide.with(mContext).load(URLs.IMAGE_URL+user.getImage()).into(avatar);
            user_id=user.getId();
            isappp=user.getIsapp();

           // Log.d("mobiles_mainhome",user.getMobilestatus());

            //Toast.makeText(mContext, "myisaapp:"+user.isIsapp(), Toast.LENGTH_SHORT).show();
            category_id=user.getCategory_id();
        }

    }
    private void initComponent() {

        recyclerView = (RecyclerView) root.findViewById(R.id.recyclerView);
        layoutManager=new LinearLayoutManager(mContext);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.setNestedScrollingEnabled(false);

        setPosts();

        updateToken(FirebaseInstanceId.getInstance().getToken());
        updateToken2(FirebaseInstanceId.getInstance().getToken());
    }

    private void setPosts() {
        progressDialog = new ProgressDialog(mContext);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();

        Call<PostDataResponse> call = RetrofitClient.getInstance().getApi().categorypostspagination(user_id,category_id,page_no,page_size);
        call.enqueue(new Callback<PostDataResponse>() {
            @Override
            public void onResponse(Call<PostDataResponse> call, Response<PostDataResponse> response) {
                progressDialog.dismiss();
                PostDataResponse userDataResponse= response.body();
                if(userDataResponse.isApistatus()){
                    List<SellerPostResponse> postList=new ArrayList<>(Arrays.asList(userDataResponse.getPost()));
                    mAdapterr = new AdapterHomePosts(mContext, postList,user_id);
                    recyclerView.setAdapter(mAdapterr);
                }
                else {
                    Toast.makeText(mContext, "No Posts", Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onFailure(Call<PostDataResponse> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(mContext, "Server Error", Toast.LENGTH_LONG).show();
            }
        });
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                visibleItemCount=layoutManager.getChildCount();
                totalItemCount=layoutManager.getItemCount();
                pastVisibleItems=layoutManager.findFirstVisibleItemPosition();
                if(dy>0){
                    if(isLoading){
                        if(totalItemCount>previous_total){
                            isLoading=false;
                            previous_total=totalItemCount;
                        }
                    }
                    if(!isLoading&&(totalItemCount-visibleItemCount)<=(pastVisibleItems+viewThreshHold)){
                        page_no++;
                        performPagination();
                        isLoading=true;
                    }
                }
            }
        });

    }
    private void performPagination() {
        progressDialog.show();
        Call<PostDataResponse> call = RetrofitClient.getInstance().getApi().categorypostspagination(user_id,category_id,page_no,page_size);
        call.enqueue(new Callback<PostDataResponse>() {
            @Override
            public void onResponse(Call<PostDataResponse> call, Response<PostDataResponse> response) {
                progressDialog.dismiss();
                PostDataResponse userDataResponse= response.body();
                if(userDataResponse.isApistatus()){
                    List<SellerPostResponse> postList=new ArrayList<>(Arrays.asList(userDataResponse.getPost()));
                    mAdapterr.addCustomer(postList);
                }
                else {
                    Toast.makeText(mContext, "No More Posts", Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onFailure(Call<PostDataResponse> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(mContext, "Server Error", Toast.LENGTH_LONG).show();
            }
        });

    }

    private void updateToken(String refreshToken) {
        // String user_id="1";
        DatabaseReference reference= FirebaseDatabase.getInstance().getReference("Tokens");
        Token token1=new Token(refreshToken);
        reference.child(user_id).setValue(token1);
    }
    private void updateToken2(String refreshToken) {
        // String user_id="1";
        DatabaseReference reference= FirebaseDatabase.getInstance().getReference("SellerTokens");
        Token token2=new Token(refreshToken);
        reference.child(user_id).setValue(token2);
    }


    private void setAdapterr() {

        final ProgressDialog progressDialog = new ProgressDialog(mContext);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();

        Call<UserDataResponse> call = RetrofitClient.getInstance().getApi().usersBycategory(user_id,category_id);
        call.enqueue(new Callback<UserDataResponse>() {
            @Override
            public void onResponse(Call<UserDataResponse> call, Response<UserDataResponse> response) {
                progressDialog.dismiss();

                UserDataResponse userDataResponse= response.body();


                if(userDataResponse.isApistatus()){
                    userList=new ArrayList<>(Arrays.asList(userDataResponse.getUser()));
                    mAdapter = new AdapterCategoryItemList(mContext, userList,category_id);
                    recyclerView.setAdapter(mAdapter);
                }else{
                    Toast.makeText(mContext, "No Data Found", Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(Call<UserDataResponse> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(mContext, t.getMessage(), Toast.LENGTH_LONG).show();


            }
        });

    }

    private void setAdapter() {

        final ProgressDialog progressDialog = new ProgressDialog(mContext);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();

        Call<UserDataResponse> call = RetrofitClient.getInstance().getApi().usersBycategory(user_id,category_id);
        call.enqueue(new Callback<UserDataResponse>() {
            @Override
            public void onResponse(Call<UserDataResponse> call, Response<UserDataResponse> response) {
                progressDialog.dismiss();

                UserDataResponse userDataResponse= response.body();


                if(userDataResponse.isApistatus()){
                    userList=new ArrayList<>(Arrays.asList(userDataResponse.getUser()));
                    mAdapter = new AdapterCategoryItemList(mContext, userList,category_id);
                    recyclerView.setAdapter(mAdapter);
                }else{
                    Toast.makeText(mContext, "No Data Found", Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(Call<UserDataResponse> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(mContext, t.getMessage(), Toast.LENGTH_LONG).show();


            }
        });

    }

    private Context mContext;
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mContext=context;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        this.menu=menu;
        inflater.inflate(R.menu.notification_menu, menu);
        databaseReference=FirebaseDatabase.getInstance().getReference("Chats");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int unread=0;
                for (DataSnapshot dataSnapshot:snapshot.getChildren()){
                    ChatModel chatModel=dataSnapshot.getValue(ChatModel.class);
                    if(chatModel.getReceiver().equals(user_id)&&!chatModel.isIsseen()){
                        unread++;
                    }
                }
                Drawable drawable;
                if(unread==0){
                    menu.getItem(0).setIcon(ContextCompat.getDrawable(mContext,R.drawable.ic_notifications));
                     menu.getItem(0).setVisible(true);

                }
                else {
                    menu.getItem(0).setIcon(ContextCompat.getDrawable(mContext,R.drawable.notification_new));
                    menu.getItem(0).setVisible(true);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.navigation_notification) {

            return true;
        } return super.onOptionsItemSelected(item);
    }

    private void initNavigationMenu() {

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle((Activity) mContext, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close) {
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
            }
        };
        if (isappp.equals("0")) {
            Menu nav_Menu = navigationView.getMenu();
            nav_Menu.findItem(R.id.nav_seller_order).setVisible(false);
            //nav_Menu.findItem(R.id.nav_seller_post).setVisible(false);
        }
        drawer.setDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(final MenuItem item) {


                int id = item.getItemId();
                if (id == R.id.nav_settings) {
                    startActivity(new Intent(mContext, ProfileActivity.class));
                    drawer.closeDrawers();
                    return true;
                }
                else if (id == R.id.nav_all_categories) {
                    startActivity(new Intent(mContext, Categories.class));
                    drawer.closeDrawers();
                    return true;
                }
                else if (id == R.id.nav_chat_history) {
                    startActivity(new Intent(mContext, ChatHistory.class));
                    drawer.closeDrawers();
                    return true;
                }
               /* else if (id == R.id.nav_seller_post) {
                    startActivity(new Intent(mContext, NewPost.class));
                    drawer.closeDrawers();
                    return true;
                }*/
                else if (id == R.id.nav_seller_order) {
                    if (isappp.equals("1")){
                    startActivity(new Intent(mContext, SellerChatHistory.class));}
                    else {
                        Toast.makeText(mContext, "You haven't any app", Toast.LENGTH_SHORT).show();
                    }
                    drawer.closeDrawers();
                    return true;
                }
                else if (id == R.id.nav_create_delivery) {
                    startActivity(new Intent(mContext, EasyShipping.class));
                    drawer.closeDrawers();
                    return true;
                }
                else if (id == R.id.nav_my_orders) {
                    startActivity(new Intent(mContext, MyOrders.class));
                    drawer.closeDrawers();
                    return true;
                }
                else if (id == R.id.nav_my_wallet) {
                    startActivity(new Intent(mContext, UserWallet.class));
                    drawer.closeDrawers();
                    return true;
                }
                else if (id == R.id.nav_my_profile) {
                    Intent intent=new Intent(mContext, ProfileDeatils.class);
                    intent.putExtra("myposts","1234");
                    startActivity(intent);
                    drawer.closeDrawers();
                    return true;
                }
               /* else if (id == R.id.new_loc) {
                    startActivity(new Intent(mContext, MyMapTest.class));
                    drawer.closeDrawers();
                    return true;
                }*/

                /*else if (id == R.id.nav_logout) {
                    if(SharedPrefManager.getInstance(mContext).isLoggedIn()){
                        SharedPrefManager.getInstance(mContext).logout();
                        Intent intent = new Intent(mContext, LoginActivity.class);
                        startActivity(intent);
                        ((MainActivity)mContext).finish();
                    }

                    drawer.closeDrawers();
                    return true;
                }*/
                else {
                    startActivity(new Intent(mContext, LoginActivity.class));
                    drawer.closeDrawers();
                    return true;
                }
            }
        });

        // open drawer at start
        //drawer.openDrawer(GravityCompat.START);
    }
}
