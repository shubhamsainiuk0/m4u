package com.m4ub2b.iezant.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.activity.CategoryItemList;
import com.m4ub2b.iezant.model.CategoryList;
import com.m4ub2b.iezant.model.Wallet;
import com.m4ub2b.iezant.model.WalletHistory;
import com.m4ub2b.iezant.simpleclasses.URLs;

import java.util.List;

public class AdapterWalletHistory extends RecyclerView.Adapter<AdapterWalletHistory.ViewHolder> {
    private List<Wallet> walletList;
    private Context context;


    public AdapterWalletHistory(Context context, List<Wallet> walletList) {
        this.walletList = walletList;
        this.context=context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater=LayoutInflater.from(parent.getContext());
        View listItem=layoutInflater.inflate(R.layout.item_wallet_history,parent,false);
        AdapterWalletHistory.ViewHolder viewHolder=new AdapterWalletHistory.ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Wallet walletHistory=walletList.get(position);
        if(walletHistory.getDebit().equals("1")){
        holder.type.setText("Debit");
            holder.type.setTextColor(ContextCompat.getColor(context,R.color.red_700));
            holder.image.setImageResource(R.drawable.ic_arrow_upward);
            holder.transaction_amount.setTextColor(ContextCompat.getColor(context,R.color.red_700));
            holder.transaction_amount.setText("- ₹ "+walletHistory.getTransaction_amount());
        }
        else {
            holder.type.setText("Credit");
            holder.type.setTextColor(ContextCompat.getColor(context,R.color.green_700));
            holder.transaction_amount.setTextColor(ContextCompat.getColor(context,R.color.green_700));
            holder.image.setImageResource(R.drawable.ic_arrow_downward);
            holder.transaction_amount.setText("+ ₹ "+walletHistory.getTransaction_amount());
        }
        holder.wallet.setText("₹ "+walletHistory.getWallet());

        holder.date.setText(walletHistory.getCreated_at());
        holder.remarks.setText(walletHistory.getRemarks());

    }

    @Override
    public int getItemCount() {
        return walletList.size();
    }

    public  static  class ViewHolder extends RecyclerView.ViewHolder{

        ImageView image;
        TextView type,transaction_amount,wallet,date,remarks;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            image=(ImageView) itemView.findViewById(R.id.image);
            type=(TextView) itemView.findViewById(R.id.type);
            transaction_amount=(TextView) itemView.findViewById(R.id.transaction_amount);
            wallet=(TextView) itemView.findViewById(R.id.wallet);
            date=(TextView) itemView.findViewById(R.id.date);
            remarks=(TextView) itemView.findViewById(R.id.remarks);

        }
    }
    public void addCustomer(List<Wallet> walletHistoryList){
        for(Wallet wallet: walletHistoryList){
            walletList.add(wallet);
        }
        notifyDataSetChanged();
    }
}
