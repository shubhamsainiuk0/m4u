package com.m4ub2b.iezant.model;

import java.io.Serializable;

public class Order implements Serializable {
    private String id,area_manager_id,user_id,category_id,delivery_charge,weight,item_name,item_value,senderlatitude,
            senderlongitude,receiverlatitude,receiverlongitude,sender_name,sender_mobile,sender_address
            ,receiver_name,receiver_mobile,receiver_alternate_mobile,receiver_address,pick_image,deliver_image,
            pick_time,deliver_time,created_at,updated,order_status, status;

    public Order(String id, String area_manager_id, String user_id, String category_id, String delivery_charge, String weight,
                 String item_name, String item_value, String senderlatitude, String senderlongitude,
                 String receiverlatitude, String receiverlongitude, String sender_name, String sender_mobile,String receiver_alternate_mobile, String sender_address, String receiver_name, String receiver_mobile, String receiver_address, String pick_image, String deliver_image,
                 String pick_time, String deliver_time, String created_at, String updated, String order_status, String status) {
        this.id = id;
        this.area_manager_id = area_manager_id;
        this.user_id = user_id;
        this.category_id = category_id;
        this.delivery_charge = delivery_charge;
        this.weight = weight;
        this.item_name = item_name;
        this.item_value = item_value;
        this.senderlatitude = senderlatitude;
        this.senderlongitude = senderlongitude;
        this.receiverlatitude = receiverlatitude;
        this.receiverlongitude = receiverlongitude;
        this.sender_name = sender_name;
        this.sender_mobile = sender_mobile;
        this.sender_address = sender_address;
        this.receiver_name = receiver_name;
        this.receiver_mobile = receiver_mobile;
        this.receiver_alternate_mobile = receiver_alternate_mobile;
        this.receiver_address = receiver_address;
        this.pick_image = pick_image;
        this.deliver_image = deliver_image;
        this.pick_time = pick_time;
        this.deliver_time = deliver_time;
        this.created_at = created_at;
        this.updated = updated;
        this.order_status = order_status;
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getArea_manager_id() {
        return area_manager_id;
    }

    public void setArea_manager_id(String area_manager_id) {
        this.area_manager_id = area_manager_id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getCategory_id() {
        return category_id;
    }

    public void setCategory_id(String category_id) {
        this.category_id = category_id;
    }

    public String getDelivery_charge() {
        return delivery_charge;
    }

    public void setDelivery_charge(String delivery_charge) {
        this.delivery_charge = delivery_charge;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getItem_name() {
        return item_name;
    }

    public void setItem_name(String item_name) {
        this.item_name = item_name;
    }

    public String getItem_value() {
        return item_value;
    }

    public void setItem_value(String item_value) {
        this.item_value = item_value;
    }

    public String getSenderlatitude() {
        return senderlatitude;
    }

    public void setSenderlatitude(String senderlatitude) {
        this.senderlatitude = senderlatitude;
    }

    public String getSenderlongitude() {
        return senderlongitude;
    }

    public void setSenderlongitude(String senderlongitude) {
        this.senderlongitude = senderlongitude;
    }

    public String getReceiverlatitude() {
        return receiverlatitude;
    }

    public void setReceiverlatitude(String receiverlatitude) {
        this.receiverlatitude = receiverlatitude;
    }

    public String getReceiverlongitude() {
        return receiverlongitude;
    }

    public void setReceiverlongitude(String receiverlongitude) {
        this.receiverlongitude = receiverlongitude;
    }

    public String getSender_name() {
        return sender_name;
    }

    public void setSender_name(String sender_name) {
        this.sender_name = sender_name;
    }

    public String getSender_mobile() {
        return sender_mobile;
    }

    public void setSender_mobile(String sender_mobile) {
        this.sender_mobile = sender_mobile;
    }

    public String getSender_address() {
        return sender_address;
    }

    public void setSender_address(String sender_address) {
        this.sender_address = sender_address;
    }

    public String getReceiver_name() {
        return receiver_name;
    }

    public void setReceiver_name(String receiver_name) {
        this.receiver_name = receiver_name;
    }

    public String getReceiver_mobile() {
        return receiver_mobile;
    }

    public void setReceiver_mobile(String receiver_mobile) {
        this.receiver_mobile = receiver_mobile;
    }

    public String getReceiver_alternate_mobile() {
        return receiver_alternate_mobile;
    }

    public void setReceiver_alternate_mobile(String receiver_alternate_mobile) {
        this.receiver_alternate_mobile = receiver_alternate_mobile;
    }

    public String getReceiver_address() {
        return receiver_address;
    }

    public void setReceiver_address(String receiver_address) {
        this.receiver_address = receiver_address;
    }

    public String getPick_image() {
        return pick_image;
    }

    public void setPick_image(String pick_image) {
        this.pick_image = pick_image;
    }

    public String getDeliver_image() {
        return deliver_image;
    }

    public void setDeliver_image(String deliver_image) {
        this.deliver_image = deliver_image;
    }

    public String getPick_time() {
        return pick_time;
    }

    public void setPick_time(String pick_time) {
        this.pick_time = pick_time;
    }

    public String getDeliver_time() {
        return deliver_time;
    }

    public void setDeliver_time(String deliver_time) {
        this.deliver_time = deliver_time;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public String getUpdated() {
        return updated;
    }

    public void setUpdated(String updated) {
        this.updated = updated;
    }

    public String getOrder_status() {
        return order_status;
    }

    public void setOrder_status(String order_status) {
        this.order_status = order_status;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}


