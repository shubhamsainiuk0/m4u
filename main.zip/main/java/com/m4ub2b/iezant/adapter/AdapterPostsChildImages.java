package com.m4ub2b.iezant.adapter;

import android.app.Dialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.model.SellerPostResponse;
import com.m4ub2b.iezant.simpleclasses.URLs;
import com.github.chrisbanes.photoview.PhotoView;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

public class AdapterPostsChildImages extends RecyclerView.Adapter<AdapterPostsChildImages.ViewHolder> {
    private List<String> postResponseList;
    private Context context;
    private SellerPostResponse p;


    public AdapterPostsChildImages(Context context, List<String> postResponseList, SellerPostResponse p) {
        this.postResponseList = postResponseList;
        this.context=context;
        this.p=p;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater=LayoutInflater.from(parent.getContext());
        View listItem=layoutInflater.inflate(R.layout.row_post_child,parent,false);
        AdapterPostsChildImages.ViewHolder viewHolder=new AdapterPostsChildImages.ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String categoryList=postResponseList.get(position);
        Glide.with(context).load(URLs.IMAGE_URL+categoryList).into(holder.imageView);
        int count=position+1;
        if (postResponseList.size()>1){
            holder.countImg.setVisibility(View.VISIBLE);
            holder.imagesCount.setText(count+"/"+postResponseList.size());
        }
        else{
            holder.countImg.setVisibility(View.GONE);
        }
        holder.imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Dialog dialog = new Dialog(context,R.style.DialogTheme);
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
                dialog.setContentView(R.layout.activity_chat_image_view);
                PhotoView imageView=dialog.findViewById(R.id.imageViewChat);
                ImageButton imageButton=dialog.findViewById(R.id.bt_close);
                dialog.setCancelable(true);
                dialog.show();
                Button bt_save=dialog.findViewById(R.id.bt_save);
                Glide.with(context).load(URLs.IMAGE_URL+categoryList).into(imageView);

                imageButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
                bt_save.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        try{
                            DownloadManager dm = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
                            Uri downloadUri = Uri.parse(URLs.IMAGE_URL+categoryList);
                            DownloadManager.Request request = new DownloadManager.Request(downloadUri);
                            request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI | DownloadManager.Request.NETWORK_MOBILE)
                                    .setAllowedOverRoaming(false)
                                    .setTitle("Image Downloading")
                                    .setMimeType("image/jpeg") // Your file type. You can use this code to download other file types also.
                                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_PICTURES, File.separator + categoryList + ".jpg");
                            dm.enqueue(request);
                            Toast.makeText(context, "Image download started.", Toast.LENGTH_SHORT).show();
                        }catch (Exception e){
                            Toast.makeText(context, "Image download failed.", Toast.LENGTH_SHORT).show();
                        }

                    }
                });

                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.BLACK));

                dialog.setCancelable(true);
                dialog.show();
            }
        });

    }

    @Override
    public int getItemCount() {
        return postResponseList.size();
    }

    public  static  class ViewHolder extends RecyclerView.ViewHolder{

        ImageView imageView;
        TextView imagesCount;
        LinearLayout countImg;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView=itemView.findViewById(R.id.post_sliderimage);
            imagesCount=itemView.findViewById(R.id.imagesCount);
            countImg=itemView.findViewById(R.id.countImg);


        }
    }
}

