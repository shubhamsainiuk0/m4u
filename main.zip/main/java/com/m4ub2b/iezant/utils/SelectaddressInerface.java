package com.m4ub2b.iezant.utils;

import com.m4ub2b.iezant.model.SavedAddress;

public interface SelectaddressInerface {

     void getAddress(SavedAddress item);

}
