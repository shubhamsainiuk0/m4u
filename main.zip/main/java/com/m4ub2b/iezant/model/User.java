package com.m4ub2b.iezant.model;

public class User {
    private String isapp,id,category_id,name,email,mobile,address,business_name,business_description,
            about,gstin,created_at,updated_at,message,image,imagebg, mobilestatus,user_bank_name,bank_name,acc_number,ifsc_code,paytm,phonepe,googlepay;
   private boolean status,apistatus;
   public Double latitude,longitude;

    public User() {
    }

    public User(String id, String category_id, String name, String email, String mobile, String address, String created_at, String updated_at, String message, boolean status, String isapp) {
        this.id = id;
        this.category_id = category_id;
        this.name = name;
        this.email = email;
        this.mobile = mobile;
        this.address = address;
        this.created_at = created_at;
        this.updated_at = updated_at;
        this.message = message;
        this.status = status;
    }

    public User(String id, String category_id, String name, String email, String mobile, String address,String business_name,String business_description,String about,String gstin, String image,String imagebg, String created_at,String isapp,String mobilestatus) {
        this.id = id;
        this.category_id = category_id;
        this.name = name;
        this.email = email;
        this.mobile = mobile;
        this.address = address;
        this.business_name = business_name;
        this.business_description = business_description;
        this.about = about;
        this.gstin = gstin;
        this.image = image;
        this.imagebg = imagebg;
        this.created_at = created_at;
        this.isapp=isapp;
        this.mobilestatus =mobilestatus;
    }

    public User(String isapp, String id, String category_id, String name, String email, String mobile, String address, String business_name, String business_description, String about, String gstin, String created_at, String updated_at, String message, String image, String imagebg, String mobilestatus, String user_bank_name, String bank_name, String acc_number, String ifsc_code, String paytm,
                String phonepe, String googlepay, boolean status, boolean apistatus, Double latitude, Double longitude) {
        this.isapp = isapp;
        this.id = id;
        this.category_id = category_id;
        this.name = name;
        this.email = email;
        this.mobile = mobile;
        this.address = address;
        this.business_name = business_name;
        this.business_description = business_description;
        this.about = about;
        this.gstin = gstin;
        this.created_at = created_at;
        this.updated_at = updated_at;
        this.message = message;
        this.image = image;
        this.imagebg = imagebg;
        this.mobilestatus = mobilestatus;
        this.user_bank_name = user_bank_name;
        this.bank_name = bank_name;
        this.acc_number = acc_number;
        this.ifsc_code = ifsc_code;
        this.paytm = paytm;
        this.phonepe = phonepe;
        this.googlepay = googlepay;
        this.status = status;
        this.apistatus = apistatus;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public String getUser_bank_name() {
        return user_bank_name;
    }

    public void setUser_bank_name(String user_bank_name) {
        this.user_bank_name = user_bank_name;
    }

    public String getBank_name() {
        return bank_name;
    }

    public void setBank_name(String bank_name) {
        this.bank_name = bank_name;
    }

    public String getAcc_number() {
        return acc_number;
    }

    public void setAcc_number(String acc_number) {
        this.acc_number = acc_number;
    }

    public String getIfsc_code() {
        return ifsc_code;
    }

    public void setIfsc_code(String ifsc_code) {
        this.ifsc_code = ifsc_code;
    }

    public String getPaytm() {
        return paytm;
    }

    public void setPaytm(String paytm) {
        this.paytm = paytm;
    }

    public String getPhonepe() {
        return phonepe;
    }

    public void setPhonepe(String phonepe) {
        this.phonepe = phonepe;
    }

    public String getGooglepay() {
        return googlepay;
    }

    public void setGooglepay(String googlepay) {
        this.googlepay = googlepay;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCategory_id() {
        return category_id;
    }

    public void setCategory_id(String category_id) {
        this.category_id = category_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getAddress() {
        return address;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getImagebg() {
        return imagebg;
    }

    public void setImagebg(String imagebg) {
        this.imagebg = imagebg;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getBusinessName() {
        return business_name;
    }

    public void setBusinessName(String business_name) {
        this.business_name = business_name;
    }

    public String getBusiness_description() {
        return business_description;
    }

    public void setBusiness_description(String business_description) {
        this.business_description = business_description;
    }

    public String getAbout() {
        return about;
    }

    public void setAbout(String about) {
        this.about = about;
    }

    public String getGstin() {
        return gstin;
    }

    public void setGstin(String gstin) {
        this.gstin = gstin;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public String getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(String updated_at) {
        this.updated_at = updated_at;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public boolean isApistatus() {
        return apistatus;
    }

    public void setApistatus(boolean apistatus) {
        this.apistatus = apistatus;
    }

    public String getIsapp() {
        return isapp;
    }

    public void setIsapp(String isapp) {
        this.isapp = isapp;
    }

    public String getBusiness_name() {
        return business_name;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public String getMobilestatus() {
        return mobilestatus;
    }

    public void setMobilestatus(String mobilestatus) {
        this.mobilestatus = mobilestatus;
    }

    public void setBusiness_name(String business_name) {
        this.business_name = business_name;
    }
}
