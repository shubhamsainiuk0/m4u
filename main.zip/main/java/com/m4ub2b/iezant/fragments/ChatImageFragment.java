package com.m4ub2b.iezant.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

import androidx.fragment.app.DialogFragment;

import com.m4ub2b.iezant.R;

public class ChatImageFragment extends DialogFragment {

    public CallbackResult callbackResult;
    private int request_code = 0;
    private View root_view;
    public ImageView imageView;

    public void setOnCallbackResult(final CallbackResult callbackResult) {
        this.callbackResult = callbackResult;
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        root_view = inflater.inflate(R.layout.activity_chat_image_view, container, false);

        imageView=root_view.findViewById(R.id.imageViewChat);

        ((ImageButton) root_view.findViewById(R.id.bt_close)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
        ((Button) root_view.findViewById(R.id.bt_save)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //sendDataResult();
                dismiss();
            }
        });



        return root_view;
    }

    public void setRequestCode(int request_code) {
        this.request_code = request_code;
    }
    public interface CallbackResult {
        void sendResult(int requestCode, Object obj);
    }

}
