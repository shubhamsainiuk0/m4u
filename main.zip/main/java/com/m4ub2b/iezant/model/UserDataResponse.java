package com.m4ub2b.iezant.model;

public class UserDataResponse {
    private boolean apistatus;
    private User[] user;

    public boolean isApistatus() {
        return apistatus;
    }

    public User[] getUser() {
        return user;
    }
}
