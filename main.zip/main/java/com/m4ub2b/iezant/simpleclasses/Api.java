package com.m4ub2b.iezant.simpleclasses;



import com.m4ub2b.iezant.model.ApiResponse;
import com.m4ub2b.iezant.model.CategoryList;
import com.m4ub2b.iezant.model.Customer;
import com.m4ub2b.iezant.model.Orders;
import com.m4ub2b.iezant.model.PostDataResponse;
import com.m4ub2b.iezant.model.SavedAddresses;
import com.m4ub2b.iezant.model.SellerPostResponse;
import com.m4ub2b.iezant.model.User;
import com.m4ub2b.iezant.model.UserDataResponse;
import com.m4ub2b.iezant.model.Wallet;
import com.m4ub2b.iezant.model.WalletBalance;
import com.m4ub2b.iezant.model.WalletHistory;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface Api {

    @FormUrlEncoded
    @POST("auth/login")
    Call<User> login(
            @Field("username") String username,
            @Field("password") String password
    );
    @FormUrlEncoded
    @POST("auth/signup")
    Call<User> register(
            @Field("category_id") String category_id,
            @Field("name") String name,
            @Field("email") String email,
            @Field("password") String password
    );


    //@FormUrlEncoded
    @POST("auth/category")
    Call<List<CategoryList>> getCategory( );

    @FormUrlEncoded
    @POST("auth/usersBycategory")
    Call<UserDataResponse> usersBycategory(
            @Field("user_id") String user_id,
            @Field("category_id") String category_id
    );
    @FormUrlEncoded
    @POST("auth/usersBycategory")
    Call<List<User>> usersBycategoryHome(
            @Field("user_id") String user_id,
            @Field("category_id") String category_id

    );

    @FormUrlEncoded
    @POST("auth/updateprofile")
    Call<User> updateProfile(
            @Field("id") String id,
            @Field("name") String name,
            @Field("email") String email,
            @Field("address") String address,
            @Field("business_name") String business_name,
            @Field("business_description") String business_description,
            @Field("about") String about,
            @Field("gstin") String gstin,
            @Field("mobile") String mobile
    );

    @FormUrlEncoded
    @POST("auth/updateprofilephoto")
    Call<User> updateprofilephoto(
            @Field("uimage") String uimage,
            @Field("id") String id
    );
    @FormUrlEncoded
    @POST("auth/updateprofilebg")
    Call<User> updateProfileBG(

            @Field("uimage") String uimage,
            @Field("id") String id
    );
    @FormUrlEncoded
    @POST("customer/userbyid")
    Call<Customer> userByidCustomer(
            @Field("user_id") String user_id
    );

    @FormUrlEncoded
    @POST("auth/userbyid")
    Call<User> userbyid(
            @Field("user_id") String user_id
    );
    @FormUrlEncoded
    @POST("auth/searchuser")
    Call<User> searchuser(
            @Field("user_id") String user_id,
            @Field("email_mobile") String email_mobile
    );
    @FormUrlEncoded
    @POST("auth/postdata")
    Call<SellerPostResponse> postdata(
            @Field("user_id") String user_id,
            @Field("category_id") String category_id,
            @Field("title") String title,
            @Field("price") String price,
            @Field("description") String description,
            @Field("multimage[]") List<String> multimage
            );

    @FormUrlEncoded
    @POST("auth/userposts")
    Call<PostDataResponse> userposts(
            @Field("user_id") String user_id,
            @Field("category_id") String category_id
    );
    @FormUrlEncoded
    @POST("auth/categoryposts")
    Call<PostDataResponse> categoryposts(
            @Field("user_id") String user_id,
            @Field("category_id") String category_id
    );
    @FormUrlEncoded
    @POST("auth/categorypostspagination")
    Call<PostDataResponse> categorypostspagination(
            @Field("user_id") String user_id,
            @Field("category_id") String category_id,
            @Field("page_no") int page_no,
            @Field("page_size") int page_size
    );
    @FormUrlEncoded
    @POST("auth/updatepost")
    Call<SellerPostResponse> updatepost(
            @Field("id") String id,
            @Field("user_id") String user_id,
            @Field("title") String title,
            @Field("price") String price,
            @Field("description") String description
    );
    @FormUrlEncoded
    @POST("auth/deletepost")
    Call<SellerPostResponse> deletepost(
            @Field("id") String id,
            @Field("user_id") String user_id
    );
    @FormUrlEncoded
    @POST("auth/sendotp")
    Call<ApiResponse> sendotp(
            @Field("email") String email
    );
    @FormUrlEncoded
    @POST("auth/checkotp")
    Call<ApiResponse> checkotp(
            @Field("email") String email,
            @Field("otp") String otp
    );
    @FormUrlEncoded
    @POST("auth/changepassword")
    Call<ApiResponse> changepassword(
            @Field("email") String email,
            @Field("password") String password,
            @Field("otp") String otp
    );
    @FormUrlEncoded
    @POST("auth/walletbalance")
    Call<WalletBalance> walletbalance(
            @Field("user_id") String user_id
    );
    @FormUrlEncoded
    @POST("auth/cordinates")
    Call<ApiResponse> cordinates(
            @Field("id") String id,
            @Field("email") String email,
            @Field("latitude") Double latitude,
            @Field("longitude") Double longitude
    );
    @FormUrlEncoded
    @POST("auth/checkdeliveryprice")
    Call<ApiResponse> checkDeliveryPrice(
            @Field("id") String id,
            @Field("senderlatitude") Double senderlatitude,
            @Field("senderlongitude") Double senderlongitude,
            @Field("deliverlatitude") Double deliverlatitude,
            @Field("deliverlongitude") Double deliverlongitude,
            @Field("category_id") String category_id,
            @Field("weight") String weight
    );

    @FormUrlEncoded
    @POST("auth/createorder")
    Call<ApiResponse> createorder(
            @Field("area_manager_id") String area_manager_id,
            @Field("user_id") String user_id,
            @Field("category_id") String category_id,
            @Field("weight") String weight,
            @Field("item_name") String item_name,
            @Field("item_value") String item_value,
            @Field("delivery_charge") Double delivery_charge,
            @Field("senderlatitude") Double senderlatitude,
            @Field("senderlongitude") Double senderlongitude,
            @Field("receiverlatitude") Double receiverlatitude,
            @Field("receiverlongitude") Double receiverlongitude,
            @Field("sender_name") String sender_name,
            @Field("sender_mobile") String sender_mobile,
            @Field("sender_address") String sender_address,
            @Field("receiver_name") String receiver_name,
            @Field("receiver_mobile") String receiver_mobile,
            @Field("receiver_alternate_mobile") String receiver_alternate_mobile,
            @Field("receiver_address") String receiver_address
    );
    @FormUrlEncoded
    @POST("auth/ordersbyuser")
    Call<Orders> ordersbyuser(
            @Field("user_id") String user_id
    );
    @FormUrlEncoded
    @POST("auth/ordersbyuserbystatus")
    Call<Orders> ordersbyuserstatus(
            @Field("user_id") String user_id,
            @Field("order_status") String order_status
    );
    @FormUrlEncoded
    @POST("auth/orderbyid")
    Call<Orders> orderbyid(
            @Field("id") String order_id
    );
    @FormUrlEncoded
    @POST("auth/wallethistorybyuser")
    Call<WalletHistory> wallethistorybyuser(
            @Field("user_id") String user_id,
            @Field("page_no") int page_no,
            @Field("page_size") int page_size
    );
    @FormUrlEncoded
    @POST("auth/transferMoney")
    Call<ApiResponse> transferMoney(
            @Field("token") String token,
            @Field("user_id") String user_id,
            @Field("send_to") String send_to,
            @Field("transfer_amount") Double transfer_amount,
            @Field("remarks") String remarks
    );
    @FormUrlEncoded
    @POST("auth/saveAddress")
    Call<ApiResponse> saveAddress(
            @Field("token") String token,
            @Field("user_id") String user_id,
            @Field("name") String name,
            @Field("mobile") String mobile,
            @Field("alternate_mobile") String alternate_mobile,
            @Field("address") String address,
            @Field("latitude") Double latitude,
            @Field("longitude") Double longitude
    );
    @FormUrlEncoded
    @POST("auth/usersDeliveryAddress")
    Call<SavedAddresses> usersDeliveryAddress(
            @Field("token") String token,
            @Field("user_id") String user_id
    );
    @FormUrlEncoded
    @POST("auth/verifymobile")
    Call<User> verifymobile(
            @Field("token") String token,
            @Field("id") String id,
            @Field("email") String email,
            @Field("mobile") String mobile
    );
    @FormUrlEncoded
    @POST("auth/updatecategory")
    Call<User> updatecategory(
            @Field("token") String token,
            @Field("user_id") String id,
            @Field("cat_id") String cat_id
    );
    // user_bank_name,bank_name,acc_number,ifsc_code,paytm,phonepe,googlepay
    @FormUrlEncoded
    @POST("auth/getpaymentoption")
    Call<User> getpaymentoption(
            @Field("token") String token,
            @Field("user_id") String id
    );
    @FormUrlEncoded
    @POST("auth/updatepaymentoption")
    Call<User> updatepaymentoption(
            @Field("token") String token,
            @Field("user_id") String id,
            @Field("user_bank_name") String user_bank_name,
            @Field("bank_name") String bank_name,
            @Field("acc_number") String acc_number,
            @Field("ifsc_code") String ifsc_code,
            @Field("phonepe") String phonepe,
            @Field("googlepay") String googlepay,
            @Field("paytm") String paytm
    );
}
