package com.m4ub2b.iezant.model;

public class PostDataResponse {
    private boolean apistatus;
    private SellerPostResponse[] post;

    public boolean isApistatus() {
        return apistatus;
    }

    public SellerPostResponse[] getPost() {
        return post;
    }
}
