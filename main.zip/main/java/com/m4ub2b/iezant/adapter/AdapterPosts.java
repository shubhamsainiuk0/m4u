package com.m4ub2b.iezant.adapter;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.PopupMenu;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.account.ProfileDeatils;
import com.m4ub2b.iezant.activity.UpdatePost;
import com.m4ub2b.iezant.model.SellerPostResponse;
import com.m4ub2b.iezant.simpleclasses.RetrofitClient;
import com.m4ub2b.iezant.simpleclasses.URLs;
import com.m4ub2b.iezant.utils.StartSnapHelper;
import com.mikhaellopez.circularimageview.CircularImageView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AdapterPosts extends RecyclerView.Adapter<AdapterPosts.ViewHolder> {
    private List<SellerPostResponse> postResponseList;
    private Context context;
    private OnMoreButtonClickListener onMoreButtonClickListener;
    private String uname,imagee,myposts;

    public AdapterPosts(Context context, List<SellerPostResponse> postResponseList,String uname,String imagee,String myposts) {
        this.postResponseList = postResponseList;
        this.context=context;
        this.uname=uname;
        this.imagee=imagee;
        this.myposts=myposts;
    }
    public void setOnMoreButtonClickListener(final OnMoreButtonClickListener onMoreButtonClickListener) {
        this.onMoreButtonClickListener = onMoreButtonClickListener;
    }
    private RecyclerView.RecycledViewPool
            viewPool
            = new RecyclerView
            .RecycledViewPool();
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater=LayoutInflater.from(parent.getContext());
        View listItem=layoutInflater.inflate(R.layout.row_post_parent,parent,false);
        AdapterPosts.ViewHolder viewHolder=new AdapterPosts.ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        SellerPostResponse sellerPostResponse=postResponseList.get(position);
        holder.nameu.setText(sellerPostResponse.getName());
        holder.ptitle.setText(sellerPostResponse.getTitle());
        holder.datetime.setText(sellerPostResponse.getCreated_at());
        if(sellerPostResponse.getPrice()!=null){
            holder.pprice.setText("  ₹ "+sellerPostResponse.getPrice());}
        if (sellerPostResponse.getDescription()==null||sellerPostResponse.getDescription().equals("")){
            holder.priceL.setVisibility(View.GONE);
        }else{
            String description=sellerPostResponse.getDescription().trim().replaceAll(" +", " ");
           // description = description.substring(0,1).toUpperCase() + description.substring(1).toLowerCase();
            holder.pdescription.setText(description);

        }
        Glide.with(context).load(URLs.IMAGE_URL+imagee).into(holder.imageView);

        String images=sellerPostResponse.getMultimage();
        String[] myImagesArray=images.split(", ");
        Log.d("myimages", String.valueOf(myImagesArray));
        List<String> postChildList= Arrays.asList(myImagesArray);

         LinearLayoutManager layoutManager= new LinearLayoutManager(
                holder.recyclerView.getContext(),LinearLayoutManager.HORIZONTAL,false);
        layoutManager.setInitialPrefetchItemCount(postChildList.size());

        AdapterPostsChildImages childItemAdapter= new AdapterPostsChildImages(context,postChildList,sellerPostResponse);
        holder.recyclerView.setLayoutManager(layoutManager);
        holder.recyclerView.setAdapter(childItemAdapter);
        holder.recyclerView.setRecycledViewPool(viewPool);
        holder.recyclerView.setOnFlingListener(null);

        holder.more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onMoreButtonClick(view, sellerPostResponse);
            }
        });
        holder.btn_share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                shareContent(myImagesArray[0],sellerPostResponse);
            }
        });
        bottomProgressDots(holder.dotsLayout, postChildList.size(), 0);
        StartSnapHelper startSnapHelper2 = new StartSnapHelper();
        startSnapHelper2.attachToRecyclerView(holder.recyclerView);
        startSnapHelper2.setSnapPositionListener(new StartSnapHelper.SnapPositionListener() {
            @Override
            public void position(View view, int position) {
                bottomProgressDots(holder.dotsLayout,postChildList.size(), position--);
            }
        });

    }

    @Override
    public int getItemCount() {
        return postResponseList.size();
    }

    public  static  class ViewHolder extends RecyclerView.ViewHolder{

        RecyclerView recyclerView;
        CircularImageView imageView;
        ImageButton more,enquiryNow;;
        TextView ptitle,pprice,pdescription,nameu,datetime;
        LinearLayout titleL,priceL,descriptionL,dotsLayout;
        ImageButton btn_share;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            titleL=itemView.findViewById(R.id.titleL);
            imageView=itemView.findViewById(R.id.uimage);
            datetime=itemView.findViewById(R.id.datetime);
            btn_share=itemView.findViewById(R.id.btn_share);
            dotsLayout=itemView.findViewById(R.id.layoutDots);
            nameu=itemView.findViewById(R.id.nameU);
            priceL=itemView.findViewById(R.id.priceL);
            more=itemView.findViewById(R.id.more);
           // descriptionL=itemView.findViewById(R.id.descriptionL);
            ptitle=itemView.findViewById(R.id.ptitle);
            pprice=itemView.findViewById(R.id.pprice);
            pdescription=itemView.findViewById(R.id.pdescription);
            recyclerView= itemView.findViewById(R.id.recyclerView);
            enquiryNow= itemView.findViewById(R.id.enquiryNow);

        }
    }

    private void onMoreButtonClick(final View view, final SellerPostResponse p) {
        PopupMenu popupMenu = new PopupMenu(context, view);

        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.action_update) {
                    Intent intent=new Intent(context, UpdatePost.class);
                    intent.putExtra("uid",p.getUser_id());
                    intent.putExtra("pid",p.getId());
                    intent.putExtra("title",p.getTitle());
                    intent.putExtra("price",p.getPrice());
                    intent.putExtra("description",p.getDescription());
                    intent.putExtra("myposts","1234");
                    context.startActivity(intent);
                    return true;
                }
                else if(id == R.id.action_delete){
                deletePost(p.getId(),p.getUser_id());
                return true;
                }
                else {
                    Toast.makeText(context, "Reported", Toast.LENGTH_SHORT).show();
                      return true;
                }
            }
        });
        popupMenu.inflate(R.menu.menu_post_more);
        popupMenu.show();
    }

    private void deletePost(String id, String user_id) {
        final ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();
        Call<SellerPostResponse> call = RetrofitClient.getInstance().getApi().deletepost(id,user_id);
        call.enqueue(new Callback<SellerPostResponse>() {
            @Override
            public void onResponse(Call<SellerPostResponse> call, Response<SellerPostResponse> response) {
                progressDialog.dismiss();
                if(response.body().isApistatus()){
                    Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_LONG).show();
                    //context.recreate();
                    ( (ProfileDeatils)context).recreate();
                }
                else{
                    Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<SellerPostResponse> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(context, t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    public interface OnMoreButtonClickListener {
        void onItemClick(View view, SellerPostResponse obj, MenuItem item);
    }
    private void bottomProgressDots(LinearLayout dotsLayout, int max, int current_index) {
        if (current_index < 0 || current_index > max - 1) return;

        ImageView[] dots = new ImageView[max];

        dotsLayout.removeAllViews();
        for (int i = 0; i < dots.length; i++) {
            dots[i] = new ImageView(context);
            int width_height = 20;
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(new ViewGroup.LayoutParams(width_height, width_height));
            params.setMargins(5, 5, 5, 5);
            dots[i].setLayoutParams(params);
            dots[i].setImageResource(R.drawable.shape_circle);
            dots[i].setColorFilter(context.getResources().getColor(R.color.grey_20), PorterDuff.Mode.SRC_IN);
            dotsLayout.addView(dots[i]);
        }

        if (dots.length > 0) {
            dots[current_index].setImageResource(R.drawable.shape_circle);
            dots[current_index].setColorFilter(context.getResources().getColor(R.color.colorPrimary), PorterDuff.Mode.SRC_IN);
        }
    }
    private void shareContent(String postImage,SellerPostResponse p){

        Bitmap bitmap =getBitmapFromUrl(postImage);
        try {
            File file = new File(context.getExternalCacheDir(),"logicchip.png");
            FileOutputStream fOut = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fOut);
            fOut.flush();
            fOut.close();
            file.setReadable(true, false);
            Uri photoURI = FileProvider.getUriForFile(context, context.getApplicationContext().getPackageName() + ".provider", file);
            Intent share = new Intent(android.content.Intent.ACTION_SEND);
            share.setType("image/png");
            share.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            share.putExtra(Intent.EXTRA_SUBJECT, p.getTitle());
            share.putExtra(Intent.EXTRA_TEXT, " ₹ "+p.getPrice()+" "+p.getTitle()+"\n"+p.getDescription()+"\nhttps://play.google.com/store/apps/details?id=com.m4ub2b.iezant");
            share.putExtra(Intent.EXTRA_STREAM, photoURI);
            context.startActivity(Intent.createChooser(share, "Share Post!"));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    private Bitmap getBitmapFromUrl(String src) {
        try{
            URL url=new URL(src);
            HttpURLConnection connection=(HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream inputStream=connection.getInputStream();
            Bitmap bitmapImg= BitmapFactory.decodeStream(inputStream);
            return bitmapImg;
        }
        catch (IOException e){
            return null;
        }
       }

}
