package com.m4ub2b.iezant.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.model.Notifications;
import com.m4ub2b.iezant.utils.ItemAnimation;

public class AdapterNotifications extends RecyclerView.Adapter<AdapterNotifications.ViewHolder> {
    private Notifications[] notifications;
    private Context context;
    private int animation_type = 0;

    public AdapterNotifications(Context context, Notifications[] notifications,int animation_type) {
        this.notifications=notifications;
        this.context=context;
        this.animation_type = animation_type;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        AdapterNotifications.ViewHolder viewHolder;
             LayoutInflater layoutInflater=LayoutInflater.from(parent.getContext());
            View listItem=layoutInflater.inflate(R.layout.item_notification_list,parent,false);
            viewHolder=new AdapterNotifications.ViewHolder(listItem);


        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.name.setText(notifications[position].getName());
        holder.description.setText(notifications[position].getEmail());
        holder.image.setImageResource(notifications[position].getImage());
        holder.lyt_parent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                /*Intent intent=new Intent(context, LoginActivity.class);
                context.startActivity(intent);*/

            }
        });
        setAnimation(holder.itemView, position);
    }

    @Override
    public int getItemCount() {
        return notifications.length;
    }


    public  static  class ViewHolder extends RecyclerView.ViewHolder{

         ImageView image;
         TextView name,description;
         LinearLayout lyt_parent;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            image=(ImageView) itemView.findViewById(R.id.image);
            name=(TextView) itemView.findViewById(R.id.name);
            description=(TextView) itemView.findViewById(R.id.description);
            lyt_parent=itemView.findViewById(R.id.lyt_parent);
        }
    }

    private int lastPosition = -1;
    private boolean on_attach = true;

    private void setAnimation(View view, int position) {
        if (position > lastPosition) {
            ItemAnimation.animate(view, on_attach ? position : -1, animation_type);
            lastPosition = position;
        }
    }
}
