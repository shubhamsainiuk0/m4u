package com.m4ub2b.iezant.activity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.m4ub2b.iezant.MainActivity;
import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.adapter.AdapterSelectImage;
import com.m4ub2b.iezant.adapter.RecyclerTouchListener;
import com.m4ub2b.iezant.model.SellerPostResponse;
import com.m4ub2b.iezant.model.User;
import com.m4ub2b.iezant.simpleclasses.RetrofitClient;
import com.m4ub2b.iezant.simpleclasses.SharedPrefManager;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NewPost extends AppCompatActivity {

    private RecyclerView recyclerView;
    private AdapterSelectImage mAdapter;
    List<String> imagesList;
    List<Bitmap> bitmaps;
    EditText titleName,price,description;
    Button bt_save;
    ImageView addimages;
    final int REQUEST_EXTERNAL_STORAGE = 100;
    private String user_id,category_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_post);
        initToolbar();
        initComponent();
    }
    private void initToolbar() {
        androidx.appcompat.widget.Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_chevron_left);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("New Post");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private void initComponent() {
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        titleName=findViewById(R.id.titleName);
        price=findViewById(R.id.price);
        description=findViewById(R.id.description);
        bt_save=findViewById(R.id.btn_save);

        if(SharedPrefManager.getInstance(getApplicationContext()).isLoggedIn()){

            User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();
            user_id=user.getId();
            category_id=user.getCategory_id();
         }

        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext(),LinearLayoutManager.HORIZONTAL,false));

        recyclerView.setHasFixedSize(true);
        recyclerView.setNestedScrollingEnabled(false);
        bitmaps = new ArrayList<>();
        imagesList = new ArrayList<>();
        mAdapter = new AdapterSelectImage(NewPost.this, bitmaps);
        recyclerView.setAdapter(mAdapter);
        recyclerView.addOnItemTouchListener(new RecyclerTouchListener(NewPost.this, recyclerView, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                imagesList.remove(position);
                bitmaps.remove(position);
                mAdapter.notifyDataSetChanged();
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));

        addimages = findViewById(R.id.image);

        addimages.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ActivityCompat.checkSelfPermission(NewPost.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(NewPost.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_EXTERNAL_STORAGE);
//                    return;
                } else {
                    launchGalleryIntent();

                }
            }
        });
        bt_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                postdata();
            }
        });
    }
    public void launchGalleryIntent() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.putExtra(Intent.ACTION_GET_CONTENT, true);
        intent.setType("image/*");
        startActivityForResult(intent, REQUEST_EXTERNAL_STORAGE);
    }
    @Override
    public void onRequestPermissionsResult(int requestCode,String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case REQUEST_EXTERNAL_STORAGE: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    launchGalleryIntent();
                } else {
                }
                return;
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_EXTERNAL_STORAGE && resultCode == RESULT_OK) {

            ClipData clipData = data.getClipData();

                    Uri imageUri = data.getData();
                    Log.d("URIImages1", imageUri.toString());
                  /*  bitmaps.clear();
                    imagesList.clear();*/
                    try {
                        InputStream inputStream = getContentResolver().openInputStream(imageUri);
                        Bitmap bitmap = BitmapFactory.decodeStream(inputStream);

                        setImage(bitmap,convertbitmaptostring(bitmap));

                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }

            }

    }

    private void setImage(Bitmap bitmap, String convertbitmaptostring) {

        if (bitmaps.size()>=4){
            Toast.makeText(this, "Image Limit Reached", Toast.LENGTH_SHORT).show();
        }
        else{
            bitmaps.add(bitmap);
            imagesList.add(convertbitmaptostring);

        }
        mAdapter.notifyDataSetChanged();
    }

    public String convertbitmaptostring(Bitmap bitmap){

        ByteArrayOutputStream byteArrayOutputStreamObject  = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 40, byteArrayOutputStreamObject);

        byte[] byteArrayVar = byteArrayOutputStreamObject.toByteArray();
        final String ConvertImage = Base64.encodeToString(byteArrayVar, Base64.DEFAULT);
        return ConvertImage;
    }
    private void postdata() {

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();

        //first getting the values
        final String title = titleName.getText().toString();
        final String pricee = price.getText().toString();
        final String descriptionn = description.getText().toString();
        //validating inputs
        if (TextUtils.isEmpty(title)) {
            titleName.setError("Please enter Title");
            titleName.requestFocus();
            progressDialog.dismiss();
            return;
        }
        //Log.d("mypostdata",pricee+","+descriptionn+","+title+","+imagesList);
        Call<SellerPostResponse> call = RetrofitClient.getInstance().getApi().postdata(user_id,category_id,title,pricee,descriptionn,imagesList);
        call.enqueue(new Callback<SellerPostResponse>() {
            @Override
            public void onResponse(Call<SellerPostResponse> call, Response<SellerPostResponse> response) {
                progressDialog.dismiss();
                if(response.body().isApistatus()){
                 Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                 startActivity(new Intent(NewPost.this,MainActivity.class));
                 finish();
                }
                else{
                    Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<SellerPostResponse> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();


            }
        });
    }


    /*@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.c, menu);
        return true;
    }*/

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        } else {
            Toast.makeText(getApplicationContext(), item.getTitle(), Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }

}