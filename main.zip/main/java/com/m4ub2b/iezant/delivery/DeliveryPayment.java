package com.m4ub2b.iezant.delivery;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.model.User;
import com.m4ub2b.iezant.model.WalletBalance;
import com.m4ub2b.iezant.simpleclasses.RetrofitClient;
import com.m4ub2b.iezant.simpleclasses.SharedPrefManager;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DeliveryPayment extends AppCompatActivity {
    private String user_id;
    private double wallet,delivery_charge_;
    private TextView wallet_balance,delivery_charge;

    private ImageButton add_balance;
    RadioGroup rg_wallet;
    RadioButton selectedRadioButton;
    Button btn_pay;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery_payment);
        initToolbar();
        initComponent();
    }

    private void initToolbar() {
        androidx.appcompat.widget.Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_chevron_left);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Complete Payment");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    private void initComponent() {
        btn_pay=findViewById(R.id.btn_pay);
        delivery_charge=findViewById(R.id.delivery_charge);
        rg_wallet=findViewById(R.id.rg_wallet);
        wallet_balance=findViewById(R.id.wallet_balance);
        if(SharedPrefManager.getInstance(getApplicationContext()).isLoggedIn()){

            User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();
            user_id=user.getId();
        }
        delivery_charge_=Double.parseDouble(getIntent().getExtras().getString("delivery_charge"));
        delivery_charge.setText("₹ "+getIntent().getExtras().getString("delivery_charge")+".0");
        getBalance();


        btn_pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedId = rg_wallet.getCheckedRadioButtonId();
                if(selectedId == R.id.rb_wallet_balance){
                    if (wallet<=delivery_charge_){
                        Toast.makeText(DeliveryPayment.this, "Insufficient wallet balance, TOP UP your wallet", Toast.LENGTH_LONG).show();
                    }
                    else{
                        Intent intent=new Intent(DeliveryPayment.this, DeliveryOrderDetails.class);
                        intent.putExtra("delivery_charge",delivery_charge_);
                        intent.putExtra("category_name",getIntent().getExtras().getString("category_name"));
                        intent.putExtra("weight",getIntent().getExtras().getString("weight"));
                        intent.putExtra("senderLatitude",getIntent().getExtras().getDouble("senderLatitude"));
                        intent.putExtra("senderLongitude",getIntent().getExtras().getDouble("senderLongitude"));
                        intent.putExtra("deliverLatitude",getIntent().getExtras().getDouble("deliverLatitude"));
                        intent.putExtra("deliverLongitude",getIntent().getExtras().getDouble("deliverLongitude"));
                        intent.putExtra("area_manager_id",getIntent().getExtras().getString("area_manager_id"));
                        intent.putExtra("category_id",getIntent().getExtras().getString("category_id"));
                        intent.putExtra("deliverAddress",getIntent().getExtras().getString("deliverAddress"));
                        startActivity(intent);
                        finish();
                    }
                }
                else
                {
                    Toast.makeText(DeliveryPayment.this, "Please select wallet", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    private void getBalance() {

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();

        Call<WalletBalance> call = RetrofitClient.getInstance().getApi().walletbalance(user_id);
        call.enqueue(new Callback<WalletBalance>() {
            @Override
            public void onResponse(Call<WalletBalance> call, Response<WalletBalance> response) {
                progressDialog.dismiss();

                //Toast.makeText(getApplicationContext(), response.body().getUser_id(), Toast.LENGTH_LONG).show();
                if (response.body().isStatus()) {
                    wallet=Double.parseDouble(response.body().getWallet_balance());
                    wallet_balance.setText("₹ "+response.body().getWallet_balance()+".0");
                }
                else{
                    wallet=Double.parseDouble("0");
                    wallet_balance.setText("₹ 0");
                }
            }

            @Override
            public void onFailure(Call<WalletBalance> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        } else {
            Toast.makeText(getApplicationContext(), item.getTitle(), Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }
}