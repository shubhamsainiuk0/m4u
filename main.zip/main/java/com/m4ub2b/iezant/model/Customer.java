package com.m4ub2b.iezant.model;

public class Customer {
    private String id,seller_id,name,email,mobile,address,about,created_at,updated_at,message,image;
   private boolean status,apistatus;


    public Customer(String id, String seller_id, String name, String email, String mobile, String address, String created_at, String updated_at, String message, boolean status) {
        this.id = id;
        this.seller_id = seller_id;
        this.name = name;
        this.email = email;
        this.mobile = mobile;
        this.address = address;
        this.created_at = created_at;
        this.updated_at = updated_at;
        this.message = message;
        this.status = status;
    }

    public Customer(String id, String seller_id, String name, String email, String mobile, String address, String about, String image, String created_at) {
        this.id = id;
        this.seller_id = seller_id;
        this.name = name;
        this.email = email;
        this.mobile = mobile;
        this.address = address;
        this.about = about;
        this.image = image;
        this.created_at = created_at;
    }

    public String getId() {
        return id;
    }

    public String getSeller_id() {
        return seller_id;
    }

    public void setSeller_id(String seller_id) {
        this.seller_id = seller_id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getAddress() {
        return address;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAbout() {
        return about;
    }

    public void setAbout(String about) {
        this.about = about;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public String getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(String updated_at) {
        this.updated_at = updated_at;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public boolean isApistatus() {
        return apistatus;
    }

    public void setApistatus(boolean apistatus) {
        this.apistatus = apistatus;
    }
}
