package com.m4ub2b.iezant.model;


public class CategoryList {


    public String id,cat_name,description,cat_image;
    private boolean status;
    int cat_image2;

    public CategoryList(int cat_image2, String cat_name) {
        this.cat_image2 = cat_image2;
        this.cat_name = cat_name;
    }

    public CategoryList(String id, String cat_name, String description, String cat_image, boolean status) {
        this.id = id;
        this.cat_name = cat_name;
        this.description = description;
        this.cat_image = cat_image;
        this.status = status;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCat_image() {
        return cat_image;
    }

    public void setCat_image(String cat_image) {
        this.cat_image = cat_image;
    }

    public String getCat_name() {
        return cat_name;
    }

    public void setCat_name(String cat_name) {
        this.cat_name = cat_name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getCat_image2() {
        return cat_image2;
    }

    public void setCat_image2(int cat_image2) {
        this.cat_image2 = cat_image2;
    }
}
