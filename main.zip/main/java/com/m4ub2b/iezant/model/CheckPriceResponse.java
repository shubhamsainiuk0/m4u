package com.m4ub2b.iezant.model;

public class CheckPriceResponse {
    private boolean apistatus;
    private String message,totalamount;

    public CheckPriceResponse(boolean apistatus, String message, String totalamount) {
        this.apistatus = apistatus;
        this.message = message;
        this.totalamount = totalamount;
    }

    public String getTotalamount() {
        return totalamount;
    }

    public void setTotalamount(String totalamount) {
        this.totalamount = totalamount;
    }

    public boolean isApistatus() {
        return apistatus;
    }

    public void setApistatus(boolean apistatus) {
        this.apistatus = apistatus;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
