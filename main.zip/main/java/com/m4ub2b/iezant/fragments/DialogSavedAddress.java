package com.m4ub2b.iezant.fragments;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.adapter.AdapterSavedAddress;
import com.m4ub2b.iezant.model.SavedAddress;
import com.m4ub2b.iezant.model.SavedAddresses;
import com.m4ub2b.iezant.utils.SelectaddressInerface;
import com.m4ub2b.iezant.model.User;
import com.m4ub2b.iezant.simpleclasses.RetrofitClient;
import com.m4ub2b.iezant.simpleclasses.SharedPrefManager;
import com.m4ub2b.iezant.simpleclasses.URLs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DialogSavedAddress extends DialogFragment implements SelectaddressInerface{

    public CallbackResult callbackResult;
   // private SelectaddressInerface SelectaddressInerface;

    public void setOnCallbackResult(final CallbackResult callbackResult) {
        this.callbackResult = callbackResult;
    }

    private int request_code = 0;
    private View root_view;
    SearchView searchView;
    String user_id;
    AdapterSavedAddress mAdapter;
    List<SavedAddress> savedAddresses;
    RecyclerView recyclerView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        root_view = inflater.inflate(R.layout.fragment_dialog_savedaddress, container, false);
        searchView=root_view.findViewById(R.id.searchView);
        searchView.setQueryHint("Search here..");
        searchView.setIconified(false);

        ((ImageButton) root_view.findViewById(R.id.bt_close)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
        recyclerView= root_view.findViewById(R.id.recyclerView);
        if (SharedPrefManager.getInstance(mContext).isLoggedIn()) {
            User customer = SharedPrefManager.getInstance(getActivity().getApplicationContext()).getUser();
            user_id=customer.getId();
        }
        recyclerView.setLayoutManager(new LinearLayoutManager(mContext));
        recyclerView.setHasFixedSize(true);
        recyclerView.setNestedScrollingEnabled(false);
        setAddress();
        searchData();
        return root_view;
    }

    private void setAddress() {
        final ProgressDialog progressDialog = new ProgressDialog(mContext);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();
        Call<SavedAddresses> call = RetrofitClient.getInstance().getApi().usersDeliveryAddress(URLs.TOKEN,user_id);
        call.enqueue(new Callback<SavedAddresses>() {
            @Override
            public void onResponse(Call<SavedAddresses> call, Response<SavedAddresses> response) {
                progressDialog.dismiss();

                SavedAddresses userDataResponse= response.body();
                if(userDataResponse.isApistatus()){

                    savedAddresses=new ArrayList<>(Arrays.asList(userDataResponse.getAddressList()));
                    mAdapter = new AdapterSavedAddress(mContext, savedAddresses, DialogSavedAddress.this);
                    recyclerView.setAdapter(mAdapter);
                }
                else {
                    Toast.makeText(mContext, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(Call<SavedAddresses> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(mContext, t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

    }
    private void searchData() {
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filter(newText);
                return false;
            }
        });
    }
    private void filter(String text) {

        List<SavedAddress> filteredlist = new ArrayList<>();
        for (SavedAddress item : savedAddresses) {
            if (item.getName().toLowerCase().contains(text.toLowerCase()) ||item.getMobile().toLowerCase().contains(text.toLowerCase())) {
                filteredlist.add(item);
            }
        }
        mAdapter.filterList(filteredlist);

    }

    private void sendDataResult(SavedAddress savedAddress) {

        if (callbackResult != null) {
            callbackResult.sendResult(request_code, savedAddress);
        }
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Dialog dialog = super.onCreateDialog(savedInstanceState);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        return dialog;
    }

    public void setRequestCode(int request_code) {
        this.request_code = request_code;
    }

    @Override
    public void getAddress(SavedAddress item) {
        sendDataResult(item);
        dismiss();
        //Toast.makeText(mContext, "Hello "+item.getAddress(), Toast.LENGTH_SHORT).show();
    }

    public interface CallbackResult {
        void sendResult(int requestCode, Object obj);
    }

    private Context mContext;
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mContext=context;
    }
}