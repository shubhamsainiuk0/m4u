package com.m4ub2b.iezant.simpleclasses;



import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClient {
    private static RetrofitClient mInstance;
    private Retrofit retrofit;
    private static final OkHttpClient httpClient = new OkHttpClient.Builder()
            .connectTimeout(300, TimeUnit.SECONDS)
            .writeTimeout(300, TimeUnit.SECONDS)
            .readTimeout(300, TimeUnit.SECONDS)
            .build();

    private  RetrofitClient(){

        retrofit=new Retrofit.Builder()
                .baseUrl(URLs.ROOT_URL)
                .addConverterFactory(GsonConverterFactory.create())
                //.client(httpClient)
                .build();

    }

    public static synchronized RetrofitClient getInstance(){
        if(mInstance==null){
            mInstance=new RetrofitClient();
        }
        return mInstance;
    }

    public  Api getApi(){
        return retrofit.create(Api.class);
    }

}
