package com.m4ub2b.iezant.ui.history;
        import android.app.ProgressDialog;
        import android.content.Context;
        import android.os.Bundle;
        import android.view.LayoutInflater;
        import android.view.Menu;
        import android.view.MenuInflater;
        import android.view.MenuItem;
        import android.view.View;
        import android.view.ViewGroup;

        import androidx.annotation.NonNull;
        import androidx.appcompat.app.AppCompatActivity;
        import androidx.appcompat.widget.Toolbar;
        import androidx.fragment.app.Fragment;
        import androidx.recyclerview.widget.LinearLayoutManager;
        import androidx.recyclerview.widget.RecyclerView;

        import com.m4ub2b.iezant.Chat.ChatList;
        import com.m4ub2b.iezant.Chat.HistoryAdapter;
        import com.m4ub2b.iezant.R;
        import com.m4ub2b.iezant.model.User;
        import com.m4ub2b.iezant.simpleclasses.SharedPrefManager;
        import com.google.firebase.database.DataSnapshot;
        import com.google.firebase.database.DatabaseError;
        import com.google.firebase.database.DatabaseReference;
        import com.google.firebase.database.FirebaseDatabase;
        import com.google.firebase.database.ValueEventListener;

        import java.util.ArrayList;
        import java.util.List;

    public class FragmentHistory extends Fragment {


    private View root;
    private Toolbar toolbar;
    private RecyclerView recyclerView;
    private HistoryAdapter mAdapter;

    private  List<ChatList> chatLists;

    String user_id,msgCount;
    DatabaseReference reference;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        root = inflater.inflate(R.layout.fragment_history, container, false);

        initToolbar();
        initComponent();

        setHasOptionsMenu(true);
        return root;
    }
    private void initToolbar() {
        toolbar = (Toolbar) root.findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_chevron_left);
        // nav_view = (NavigationView) root.findViewById(R.id.nav_view);
        //drawer = (DrawerLayout) root.findViewById(R.id.drawer_layout);
        ((AppCompatActivity)getActivity()).setSupportActionBar(toolbar);
        ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("Order History");
        ((AppCompatActivity)getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    private void initComponent() {
        if(SharedPrefManager.getInstance(mContext).isLoggedIn()){

            User user = SharedPrefManager.getInstance(mContext).getUser();
            user_id=user.getId();
        }

        recyclerView = (RecyclerView) root.findViewById(R.id.recyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(mContext));

        recyclerView.setHasFixedSize(true);
        recyclerView.setNestedScrollingEnabled(false);

        //set data and list adapter
        setAdapter();

    }

    private void setAdapter() {
        final ProgressDialog progressDialog = new ProgressDialog(mContext);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();
        chatLists=new ArrayList<>();

        reference= FirebaseDatabase.getInstance().getReference("Chatlist").child(user_id);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                chatLists.clear();
                for(DataSnapshot dataSnapshot:snapshot.getChildren()){
                    ChatList chat=dataSnapshot.getValue(ChatList.class);
                    chatLists.add(chat);
                    mAdapter=new HistoryAdapter(chatLists, mContext,true);
                    recyclerView.setAdapter(mAdapter);
                    progressDialog.dismiss();
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressDialog.dismiss();
            }
        });


    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.notifications_menu, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.navigation_notifications_refresh) {

            return true;
        } return super.onOptionsItemSelected(item);
    }



    private Context mContext;
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mContext=context;
    }
}