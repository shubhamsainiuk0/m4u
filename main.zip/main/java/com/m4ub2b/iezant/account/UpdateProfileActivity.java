package com.m4ub2b.iezant.account;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Base64;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.model.User;
import com.m4ub2b.iezant.simpleclasses.RetrofitClient;
import com.m4ub2b.iezant.simpleclasses.SharedPrefManager;
import com.m4ub2b.iezant.simpleclasses.URLs;
import com.m4ub2b.iezant.utils.Tools;
import com.mikhaellopez.circularimageview.CircularImageView;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UpdateProfileActivity extends AppCompatActivity {


    Button btn_submit;
    EditText name,email,address,mobile,gstin,business_name,business_description,about;
    ImageView edit_img_btn,edit_img_bg_btn;
    CircularImageView image;
    ImageView imagebg;
    List<User> userList;
    String user_id;
    Bitmap bitmapProfile,bitmapBg;
    String profileImage,bgImage,checker ="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_profile);

        initToolbar();
        initComponent();

    }

    private void initToolbar() {
        androidx.appcompat.widget.Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_chevron_left_white);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Update Profile");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Tools.setSystemBarColor(this, R.color.blue_600);
    }


    private void initComponent() {

        name=findViewById(R.id.name);
        email=findViewById(R.id.email);
        btn_submit=findViewById(R.id.btn_submit);
        address=findViewById(R.id.address);
        business_name=findViewById(R.id.businessName);
        business_description=findViewById(R.id.businessDescription);
        about=findViewById(R.id.aboutUs);
        gstin=findViewById(R.id.gstinNumber);
        mobile=findViewById(R.id.mobile);
        image=findViewById(R.id.image);
        imagebg=findViewById(R.id.imagebg);
        edit_img_btn=findViewById(R.id.edit_img_btn);
        edit_img_bg_btn=findViewById(R.id.edit_img_bg_btn);


        if(SharedPrefManager.getInstance(getApplicationContext()).isLoggedIn()){

            User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();
            //Toast.makeText(this, ""+ URLs.IMAGE_URL+user.getImage(), Toast.LENGTH_SHORT).show();
            name.setText(user.getName());
            email.setText(user.getEmail());
            address.setText(user.getAddress());
            business_name.setText(user.getBusinessName());
            business_description.setText(user.getBusiness_description());
            about.setText(user.getAbout());
            gstin.setText(user.getGstin());
            mobile.setText(user.getMobile());
            user_id=user.getId();

            Picasso.get().load(URLs.IMAGE_URL+user.getImage()).into(image);
            Picasso.get().load(URLs.IMAGE_URL+user.getImagebg()).into(imagebg);


            /*Glide.with(getApplicationContext()).load(URLs.IMAGE_URL+user.getImage())
                    .signature(new ObjectKey(String.valueOf(System.currentTimeMillis()))).into(image);
            Glide.with(getApplicationContext()).load(URLs.IMAGE_URL+user.getImagebg())
                    .signature(new ObjectKey(String.valueOf(System.currentTimeMillis()))).into(imagebg);*/
            }
        edit_img_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getImage();
            }
        });
        edit_img_bg_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getImageBg();

            }
        });
        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                updateProfileData();


               //recreate();

               /* User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();
                //Toast.makeText(this, ""+ URLs.IMAGE_URL+user.getImage(), Toast.LENGTH_SHORT).show();
                name.setText(user.getName());
                email.setText(user.getEmail());
                address.setText(user.getAddress());
                mobile.setText(user.getMobile());
                user_id=user.getId();
                Glide.with(getApplicationContext()).load(URLs.IMAGE_URL+user.getImage()).into(image);*/
              //  super.();
            }
        });


    }

    private void getImage() {
        checker="imageP";
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Image From Gallery"), 1);
    }
    private void getImageBg() {
        checker="imageBg";
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Image From Gallery"), 1);
    }
    @Override
    protected void onActivityResult(int RC, int RQC, Intent I) {
        super.onActivityResult(RC, RQC, I);
        if (RC == 1 && RQC == RESULT_OK && I != null && I.getData() != null) {
            Uri uri = I.getData();
            if(checker.equals("imageP")){
                try {
                    bitmapProfile = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                    image.setImageBitmap(bitmapProfile);
                    updateProfilePhoto();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }else {
                try {
                    bitmapBg = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                    imagebg.setImageBitmap(bitmapBg);
                     updateProfilebg();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    public String convertbitmaptostring(){

        ByteArrayOutputStream byteArrayOutputStreamObject  = new ByteArrayOutputStream();
        if(checker.equals("imageP")){
            bitmapProfile.compress(Bitmap.CompressFormat.JPEG, 40, byteArrayOutputStreamObject);
        }else{
            bitmapBg.compress(Bitmap.CompressFormat.JPEG, 40, byteArrayOutputStreamObject);
        }

        byte[] byteArrayVar = byteArrayOutputStreamObject.toByteArray();
         final String ConvertImage = Base64.encodeToString(byteArrayVar, Base64.DEFAULT);
        return ConvertImage;
    }

    private void updateProfilebg() {
        if(bitmapBg != null){
            bgImage=convertbitmaptostring();
        }

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();
         Call<User> call = RetrofitClient.getInstance().getApi().updateProfileBG(bgImage,user_id);
         call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                if (response.body().isApistatus()) {
                    User user=response.body();
                    Picasso.get().load(URLs.IMAGE_URL+user.getImagebg()).into(imagebg);
                    SharedPrefManager.getInstance(getApplicationContext()).userLogin(response.body());
                    progressDialog.dismiss();
                    Toast.makeText(getApplicationContext(), user.getMessage(), Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                }


            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();


            }
        });

    }
    private void updateProfilePhoto() {
        if(bitmapProfile != null){
            profileImage=convertbitmaptostring();
        }

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();

        Call<User> call = RetrofitClient.getInstance().getApi().updateprofilephoto(profileImage,user_id);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                progressDialog.dismiss();
                assert response.body() != null;
                if (response.body().isApistatus()) {
                    User user=response.body();
                    Picasso.get().load(URLs.IMAGE_URL+user.getImage()).into(image);
                    SharedPrefManager.getInstance(getApplicationContext()).userLogin(response.body());
                    progressDialog.dismiss();
                    Toast.makeText(getApplicationContext(), user.getMessage(), Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                }
            }
            @Override
            public void onFailure(Call<User> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

    }
    private void updateProfileData() {

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();

        //first getting the values
        final String name1 = name.getText().toString();
        final String email1 = email.getText().toString();
        final String mobile1 = mobile.getText().toString();
        final String address1 = address.getText().toString();
        final String businessName1 = business_name.getText().toString();
        final String businessDescription1 = business_description.getText().toString();
        final String aboutUs1 = about.getText().toString();
        final String gstinNumber1 = gstin.getText().toString();
        //validating inputs
        if (TextUtils.isEmpty(name1)) {
            name.setError("Please enter your Name");
            name.requestFocus();
            progressDialog.dismiss();
            return;
        }
        if (TextUtils.isEmpty(businessName1)) {
            business_name.setError("Please enter your Business Name");
            business_name.requestFocus();
            progressDialog.dismiss();
            return;
        }
        if (TextUtils.isEmpty(businessDescription1)) {
            business_description.setError("Please enter your Business Description");
            business_description.requestFocus();
            progressDialog.dismiss();
            return;
        }
        if (TextUtils.isEmpty(aboutUs1)) {
            about.setError("Please enter About Us");
            about.requestFocus();
            progressDialog.dismiss();
            return;
        }
        if (TextUtils.isEmpty(email1)) {
            email.setError("Please enter your Email Id");
            email.requestFocus();
            progressDialog.dismiss();
            return;
        }

        if (TextUtils.isEmpty(address1)) {
            address.setError("Please enter your address");
            address.requestFocus();
            progressDialog.dismiss();
            return;
        }
        if (TextUtils.isEmpty(mobile1)) {
            mobile.setError("Please enter your mobile number");
            mobile.requestFocus();
            progressDialog.dismiss();
            return;
        }
        Call<User> call = RetrofitClient.getInstance().getApi().updateProfile(user_id,name1,email1,address1,businessName1,businessDescription1,aboutUs1,gstinNumber1,mobile1);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                if (response.body().isApistatus()) {
                    SharedPrefManager.getInstance(getApplicationContext()).userLogin(response.body());
                    startActivity(getIntent());
                    finish();
                }
                else{
                    Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                }
            }
            @Override
            public void onFailure(Call<User> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        } else {
            Toast.makeText(getApplicationContext(), item.getTitle(), Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }
}