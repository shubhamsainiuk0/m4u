package com.m4ub2b.iezant.simpleclasses;

public class URLs {

    public static final String ROOT_URL = "https://m4ub2b.com/api/";
    public static final String IMAGE_URL = "https://m4ub2b.com/";
    public static final String TOKEN = "Drmhze6EPcm4ub2bv0fN_81Bj";
}
