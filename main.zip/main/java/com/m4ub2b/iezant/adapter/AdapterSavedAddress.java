package com.m4ub2b.iezant.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.model.SavedAddress;
import com.m4ub2b.iezant.utils.SelectaddressInerface;

import java.util.List;


public class AdapterSavedAddress extends RecyclerView.Adapter<AdapterSavedAddress.ViewHolder> {
    private List<SavedAddress> savedAddresses;
    private Context context;
    public SelectaddressInerface selectaddressInerface;


    public AdapterSavedAddress(Context context, List<SavedAddress> savedAddresses, SelectaddressInerface selectaddressInerface) {
        this.savedAddresses = savedAddresses;
        this.context=context;
        this.selectaddressInerface=selectaddressInerface;
    }

    public void filterList(List<SavedAddress>  filterllist) {
        savedAddresses = filterllist;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater=LayoutInflater.from(parent.getContext());
        View listItem=layoutInflater.inflate(R.layout.item_saved_address,parent,false);
        AdapterSavedAddress.ViewHolder viewHolder=new AdapterSavedAddress.ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        SavedAddress savedAddress=savedAddresses.get(position);
        holder.name.setText("Name : "+savedAddress.getName());
        holder.mobile.setText("Mob : "+savedAddress.getMobile());
        holder.address.setText("Address : "+savedAddress.getAddress());
        holder.select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectaddressInerface.getAddress(savedAddress);
            }
        });
    }

    @Override
    public int getItemCount() {
        return savedAddresses.size();
    }

    public  static  class ViewHolder extends RecyclerView.ViewHolder{

        TextView name,mobile,address,select;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name=(TextView) itemView.findViewById(R.id.name);
            mobile=(TextView) itemView.findViewById(R.id.mobile);
            address=itemView.findViewById(R.id.address);
            select=itemView.findViewById(R.id.select);
        }
    }
}
