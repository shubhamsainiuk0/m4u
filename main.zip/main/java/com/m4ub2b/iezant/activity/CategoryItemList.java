package com.m4ub2b.iezant.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.adapter.AdapterCategoryItemList;
import com.m4ub2b.iezant.adapter.AdapterHomePosts;
import com.m4ub2b.iezant.model.PostDataResponse;
import com.m4ub2b.iezant.model.SellerPostResponse;
import com.m4ub2b.iezant.model.User;
import com.m4ub2b.iezant.model.UserDataResponse;
import com.m4ub2b.iezant.simpleclasses.RetrofitClient;
import com.m4ub2b.iezant.simpleclasses.SharedPrefManager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CategoryItemList extends AppCompatActivity {

    private RecyclerView recyclerView;
    private AdapterCategoryItemList mAdapter;
    List<User> userList;
    String category_id,user_id;
    List<SellerPostResponse> postList;
    private AdapterHomePosts mAdapterr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_item_list);

        initToolbar();
        initComponent();
    }

    private void initToolbar() {
        androidx.appcompat.widget.Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_chevron_left);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(getIntent().getExtras().getString("cat_name"));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

        private void initComponent() {

        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));

        recyclerView.setHasFixedSize(true);
        recyclerView.setNestedScrollingEnabled(false);

        //set data and list adapter
       // setAdapter();
            if(SharedPrefManager.getInstance(CategoryItemList.this).isLoggedIn()){

                User user = SharedPrefManager.getInstance(CategoryItemList.this).getUser();
                user_id=user.getId();
                category_id=getIntent().getExtras().getString("cat_id");

            }

            setPosts();

    }

    private void setPosts() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();

        Call<PostDataResponse> call = RetrofitClient.getInstance().getApi().categoryposts(user_id,category_id);
        call.enqueue(new Callback<PostDataResponse>() {
            @Override
            public void onResponse(Call<PostDataResponse> call, Response<PostDataResponse> response) {
                progressDialog.dismiss();

                PostDataResponse userDataResponse= response.body();

                if(userDataResponse.isApistatus()){
                    postList=new ArrayList<>(Arrays.asList(userDataResponse.getPost()));
                    Log.d("mydata", String.valueOf(response.body().getPost()));
                    mAdapterr = new AdapterHomePosts(CategoryItemList.this, postList,user_id);
                    recyclerView.setAdapter(mAdapterr);
                }

            }

            @Override
            public void onFailure(Call<PostDataResponse> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(CategoryItemList.this, t.getMessage(), Toast.LENGTH_LONG).show();


            }
        });


    }


    private void setAdapter() {

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();


        Call<UserDataResponse> call = RetrofitClient.getInstance().getApi().usersBycategory(user_id,category_id);
        call.enqueue(new Callback<UserDataResponse>() {
            @Override
            public void onResponse(Call<UserDataResponse> call, Response<UserDataResponse> response) {
                progressDialog.dismiss();

                UserDataResponse userDataResponse= response.body();


                if(userDataResponse.isApistatus()){
                    userList=new ArrayList<>(Arrays.asList(userDataResponse.getUser()));
                    mAdapter = new AdapterCategoryItemList(CategoryItemList.this, userList,category_id);
                    recyclerView.setAdapter(mAdapter);
                }else{
                    Toast.makeText(CategoryItemList.this, "No Data Found", Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(Call<UserDataResponse> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();


            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.search_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        } else {
            Toast.makeText(getApplicationContext(), item.getTitle(), Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }

}