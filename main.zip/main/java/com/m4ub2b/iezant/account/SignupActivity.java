package com.m4ub2b.iezant.account;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.m4ub2b.iezant.MainActivity;
import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.model.CategoryList;
import com.m4ub2b.iezant.model.User;
import com.m4ub2b.iezant.simpleclasses.RetrofitClient;
import com.m4ub2b.iezant.simpleclasses.SharedPrefManager;
import com.google.android.material.textfield.TextInputEditText;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignupActivity extends AppCompatActivity  {

    TextView sign_in;
    private TextInputEditText et_email,et_name, et_password;
    Button btn_submit;
    EditText et_category;
    List<CategoryList> categoryLists;
    String category_idd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        if (SharedPrefManager.getInstance(SignupActivity.this).isLoggedIn()) {
            startActivity(new Intent(SignupActivity.this, MainActivity.class));
            finish();
        }
        initComponent();

    }


    private void initComponent() {

        sign_in=findViewById(R.id.sign_in);
        et_name=findViewById(R.id.et_name);
        et_email=findViewById(R.id.et_email);
        btn_submit=findViewById(R.id.btn_submit);
        et_password=findViewById(R.id.et_password);
        et_category=findViewById(R.id.et_category);

        setCategory();

        sign_in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });

        (findViewById(R.id.et_category)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCategoryDialog(v);
            }
        });

        (findViewById(R.id.btn_submit)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userSignup();
            }
        });
    }

    private void setCategory() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();

        Call<List<CategoryList>> call = RetrofitClient.getInstance().getApi().getCategory();
        call.enqueue(new Callback<List<CategoryList>>() {
            @Override
            public void onResponse(Call<List<CategoryList>> call, Response<List<CategoryList>> response) {
                progressDialog.dismiss();
                categoryLists=response.body();

            }

            @Override
            public void onFailure(Call<List<CategoryList>> call, Throwable t) {
                progressDialog.dismiss();

                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void userSignup() {

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();

        //first getting the values
        final String name = et_name.getText().toString();
        final String email = et_email.getText().toString();
        final String password = et_password.getText().toString();
        //validating inputs
        if (TextUtils.isEmpty(name)) {
            et_name.setError("Please enter your Name");
            et_name.requestFocus();
            progressDialog.dismiss();
            return;
        }
        if (TextUtils.isEmpty(email)) {
            et_email.setError("Please enter your Email Id");
            et_email.requestFocus();
            progressDialog.dismiss();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            et_password.setError("Please enter your password");
            progressDialog.dismiss();
            et_password.requestFocus();
            return;
        }
        Call<User> call = RetrofitClient.getInstance().getApi().register(category_idd,name,email,password);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                progressDialog.dismiss();

                Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                if (response.body().isApistatus()) {

                    SharedPrefManager.getInstance(getApplicationContext()).userLogin(response.body());
                    startActivity(new Intent(SignupActivity.this, MainActivity.class));
                    finish();
                }
                else{
                    Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                }


            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();


            }
        });

    }


    private void showCategoryDialog(final View v) {
        String[] array = new String[categoryLists.size()];
        String[] arrayId = new String[categoryLists.size()];
        for (int i = 0; i < categoryLists.size(); i++) {
            array[i] = categoryLists.get(i).getCat_name();
            arrayId[i] = categoryLists.get(i).getId();
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select Category");
        builder.setSingleChoiceItems(array, -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                ((EditText) v).setText(array[i]);
                category_idd=arrayId[i];
                //Toast.makeText(SignupActivity.this, "Id is:"+arrayId[i], Toast.LENGTH_SHORT).show();
                dialogInterface.dismiss();
            }
        });
        builder.show();
    }

}