package com.m4ub2b.iezant.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.model.PostImageSlider;

public class AdapterPostImageSlider extends RecyclerView.Adapter<AdapterPostImageSlider.ViewHolder> {
    private PostImageSlider[] imageSlider;
    private Context context;

    public AdapterPostImageSlider(Context context, PostImageSlider[] imageSlider) {
        this.imageSlider = imageSlider;
        this.context=context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater=LayoutInflater.from(parent.getContext());
        View listItem=layoutInflater.inflate(R.layout.item_post_slider,parent,false);
        listItem.setLayoutParams(new ConstraintLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        ViewHolder viewHolder=new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.sliderImage.setImageResource(imageSlider[position].getImageView());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               /* Intent intent=new Intent(context, LocationItemView.class);
                context.startActivity(intent);*/

            }
        });
    }

    @Override
    public int getItemCount() {
        return imageSlider.length;
    }

    public  static  class ViewHolder extends RecyclerView.ViewHolder{

        ImageView sliderImage;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            sliderImage=(ImageView) itemView.findViewById(R.id.sliderImage);
        }
    }
}
