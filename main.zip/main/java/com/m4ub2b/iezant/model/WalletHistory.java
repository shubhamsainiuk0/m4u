package com.m4ub2b.iezant.model;

public class WalletHistory {
    private boolean apistatus;
    private Wallet[] wallets;

    public WalletHistory(boolean apistatus, Wallet[] wallets) {
        this.apistatus = apistatus;
        this.wallets = wallets;
    }

    public boolean isApistatus() {
        return apistatus;
    }

    public void setApistatus(boolean apistatus) {
        this.apistatus = apistatus;
    }

    public Wallet[] getWallets() {
        return wallets;
    }

    public void setWallets(Wallet[] wallets) {
        this.wallets = wallets;
    }
}

