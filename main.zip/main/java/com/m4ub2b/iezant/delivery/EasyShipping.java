package com.m4ub2b.iezant.delivery;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.fragments.DialogSavedAddress;
import com.m4ub2b.iezant.model.ApiResponse;
import com.m4ub2b.iezant.model.CategoryList;
import com.m4ub2b.iezant.model.SavedAddress;
import com.m4ub2b.iezant.model.User;
import com.m4ub2b.iezant.simpleclasses.LocationPicker;
import com.m4ub2b.iezant.simpleclasses.MapUtilityy;
import com.m4ub2b.iezant.simpleclasses.RetrofitClient;
import com.m4ub2b.iezant.simpleclasses.SharedPrefManager;
import com.shivtechs.maplocationpicker.MapUtility;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EasyShipping extends AppCompatActivity {

    EditText fromStore,deliverTo,category,weight;
    Button bt_save;
    String user_id,category_idd,storename,deliverAddress,deliverName,deliverMobile,deliverAlternate,addresstype;
    Toolbar toolbar;
    public static final int DIALOG_QUEST_CODE = 300;
    Double senderLatitude, senderLongitude,deliverLatitude,deliverLongitude;
    List<CategoryList> categoryLists;
    private static final int ADDRESS_PICKER_REQUEST = 1020;
    LinearLayout saved_address;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_easy_shipping);
       // MapUtility.apiKey = getResources().getString(R.string.google_maps_key);
         MapUtilityy.apiKey = getResources().getString(R.string.google_maps_key);

        initToolbar();
        initComponent();
    }
    private void initToolbar() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_chevron_left);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Easy Shipping");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    private void initComponent() {

        fromStore = findViewById(R.id.fromStore);
        deliverTo = findViewById(R.id.deliverTo);
        category = findViewById(R.id.packetType);
        weight = findViewById(R.id.weight);
        bt_save = findViewById(R.id.btn_save);
        saved_address = findViewById(R.id.saved_address);
        if (SharedPrefManager.getInstance(EasyShipping.this).isLoggedIn()) {
            User customer = SharedPrefManager.getInstance(getApplicationContext()).getUser();
            storename=customer.getAddress();
        }
        deliverName=null;
        deliverMobile=null;
        deliverAlternate=null;
        deliverAddress=null;
        senderLocation();
        setCategory();
        category.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showparcelTypeDialog(view);
            }
        });
        deliverTo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (deliverLatitude==null&&deliverLongitude==null) {
                    Intent intent = new Intent(EasyShipping.this, LocationPicker.class);
                    startActivityForResult(intent, ADDRESS_PICKER_REQUEST);
                }
                else {
                    Intent intent = new Intent(EasyShipping.this, LocationPicker.class);
                    intent.putExtra(MapUtilityy.LATITUDE,29.93923177645073);
                    intent.putExtra(MapUtilityy.LONGITUDE,77.95290380716324);
                    startActivityForResult(intent, ADDRESS_PICKER_REQUEST);
                }
            }
        });
        bt_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                postdata();
            }
        });
        saved_address.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialogFullscreen();
              }
        });

    }

    private void senderLocation() {
        if (SharedPrefManager.getInstance(EasyShipping.this).isLoggedIn()) {
            User customer = SharedPrefManager.getInstance(getApplicationContext()).getUser();
            user_id=customer.getId();
        }
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();
        Call<User> call = RetrofitClient.getInstance().getApi().userbyid(user_id);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                progressDialog.dismiss();

                User user= response.body();
                if(user.isStatus()) {
                    senderLatitude=user.getLatitude();
                    senderLongitude=user.getLongitude();
                    Toast.makeText(EasyShipping.this, "Your store location selected", Toast.LENGTH_SHORT).show();
                    fromStore.setText(storename);
                }
            }
            @Override
            public void onFailure(Call<User> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
    private void setCategory() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();

        Call<List<CategoryList>> call = RetrofitClient.getInstance().getApi().getCategory();
        call.enqueue(new Callback<List<CategoryList>>() {
            @Override
            public void onResponse(Call<List<CategoryList>> call, Response<List<CategoryList>> response) {
                progressDialog.dismiss();
                categoryLists=response.body();
            }

            @Override
            public void onFailure(Call<List<CategoryList>> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void postdata() {

        final String weight_ = weight.getText().toString();
        final String category_ = category.getText().toString();
        if (senderLatitude==null&&senderLongitude==null) {
            Toast.makeText(this, "First you need to update your store location on map", Toast.LENGTH_LONG).show();
            return;
        }
        if (deliverLatitude==null&&deliverLongitude==null) {
            Toast.makeText(this, "Delivery Location Not selected", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(category_)) {
            Toast.makeText(this, "Please select parcel type", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(weight_)) {
            weight.setError("Please enter");
            weight.requestFocus();
            return;
        }
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();
        Call<ApiResponse> call = RetrofitClient.getInstance().getApi().checkDeliveryPrice(user_id,senderLatitude,senderLongitude,deliverLatitude,deliverLongitude,category_idd,weight_);
        call.enqueue(new Callback<ApiResponse>() {
            @Override
            public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                progressDialog.dismiss();
                Toast.makeText(EasyShipping.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                if(response.body().isApistatus()){
                Intent intent=new Intent(EasyShipping.this, DeliveryCalculatePrice.class);
                intent.putExtra("totalAmount",response.body().getTotalamount());
                intent.putExtra("category_id",category_idd);
                intent.putExtra("senderLatitude",senderLatitude);
                intent.putExtra("senderLongitude",senderLongitude);
                intent.putExtra("deliverLatitude",deliverLatitude);
                intent.putExtra("deliverLongitude",deliverLongitude);
                intent.putExtra("area_manager_id",response.body().getArea_manager_id());
                intent.putExtra("category_name",category_);
                intent.putExtra("weight",weight_);
                intent.putExtra("distance",response.body().getDistance_km());
                intent.putExtra("name",deliverName);
                intent.putExtra("alternate_mobile",deliverAlternate);
                intent.putExtra("mobile",deliverMobile);
                intent.putExtra("deliverAddress",deliverAddress);
                intent.putExtra("addresstype",addresstype);
                startActivity(intent);}
            }

            @Override
            public void onFailure(Call<ApiResponse> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });


    }
    private void showparcelTypeDialog(View v) {
        String[] array = new String[categoryLists.size()];
        String[] arrayId = new String[categoryLists.size()];
        for (int i = 0; i < categoryLists.size(); i++) {
            array[i] = categoryLists.get(i).getCat_name();
            arrayId[i] = categoryLists.get(i).getId();
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select Category");
        builder.setSingleChoiceItems(array, -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                ((EditText) v).setText(array[i]);
                category_idd=arrayId[i];
                //Toast.makeText(SignupActivity.this, "Id is:"+arrayId[i], Toast.LENGTH_SHORT).show();
                dialogInterface.dismiss();
            }
        });
        builder.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ADDRESS_PICKER_REQUEST) {
            try {
                if (data != null && data.getStringExtra(MapUtility.ADDRESS) != null) {
                    // String address = data.getStringExtra(MapUtility.ADDRESS);
                    double currentLatitude = data.getDoubleExtra(MapUtility.LATITUDE, 0.0);
                    double currentLongitude = data.getDoubleExtra(MapUtility.LONGITUDE, 0.0);
                    Bundle completeAddress =data.getBundleExtra("fullAddress");
                    deliverAddress=new StringBuilder().append(completeAddress.getString("addressline2")).toString();
                    deliverTo.setText(deliverAddress);
                    deliverLatitude=currentLatitude;
                    deliverLongitude=currentLongitude;
                    deliverName=null;
                    deliverMobile=null;
                    deliverAlternate=null;
                    addresstype="new";
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        } else {
            Toast.makeText(getApplicationContext(), item.getTitle(), Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }
    private void showDialogFullscreen() {
        FragmentManager fragmentManager = getSupportFragmentManager();
        DialogSavedAddress newFragment = new DialogSavedAddress();
        newFragment.setRequestCode(DIALOG_QUEST_CODE);
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        transaction.add(android.R.id.content, newFragment).addToBackStack(null).commit();
        newFragment.setOnCallbackResult(new DialogSavedAddress.CallbackResult() {
            @Override
            public void sendResult(int requestCode, Object obj) {
                if (requestCode == DIALOG_QUEST_CODE) {
                    displayDataResult((SavedAddress) obj);
                }
            }
        });
    }

    private void displayDataResult(SavedAddress savedAddress) {
        deliverTo.setText(savedAddress.getAddress());
        deliverAddress=savedAddress.getAddress();
        deliverName=savedAddress.getName();
        deliverMobile=savedAddress.getMobile();
        deliverAlternate=savedAddress.getAlternate_mobile();
        deliverLatitude=Double.parseDouble(savedAddress.getLatitude());
        deliverLongitude=Double.parseDouble(savedAddress.getLongitude());
        addresstype="old";
    }


}