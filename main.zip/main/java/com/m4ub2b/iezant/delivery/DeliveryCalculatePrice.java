package com.m4ub2b.iezant.delivery;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.m4ub2b.iezant.R;

public class DeliveryCalculatePrice extends AppCompatActivity {

    Button btn_save;
    TextView totalAmount,distance;
    String totalAmount_,category_,weight_,distance_;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery_calculate_price);
        initToolbar();
        initComponent();
    }

    private void initToolbar() {
        androidx.appcompat.widget.Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_chevron_left);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Estimate Delivery Price");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    private void initComponent() {
        btn_save=findViewById(R.id.btn_save);
        distance=findViewById(R.id.distance);
        totalAmount_=getIntent().getExtras().getString("totalAmount");
        category_=getIntent().getExtras().getString("category_name");
        weight_=getIntent().getExtras().getString("weight");
        distance_=getIntent().getExtras().getString("distance");
        totalAmount=findViewById(R.id.totalAmount);
        totalAmount.setText("₹ "+totalAmount_);
        distance.setText("Distance in km "+distance_);
        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(DeliveryCalculatePrice.this, DeliveryOrderDetails.class);
                intent.putExtra("delivery_charge",Double.parseDouble(totalAmount_));
                intent.putExtra("category_name",category_);
                intent.putExtra("weight",weight_);
                intent.putExtra("senderLatitude",getIntent().getExtras().getDouble("senderLatitude"));
                intent.putExtra("senderLongitude",getIntent().getExtras().getDouble("senderLongitude"));
                intent.putExtra("deliverLatitude",getIntent().getExtras().getDouble("deliverLatitude"));
                intent.putExtra("deliverLongitude",getIntent().getExtras().getDouble("deliverLongitude"));
                intent.putExtra("area_manager_id",getIntent().getExtras().getString("area_manager_id"));
                intent.putExtra("category_id",getIntent().getExtras().getString("category_id"));
                intent.putExtra("deliverAddress",getIntent().getExtras().getString("deliverAddress"));
                intent.putExtra("name",getIntent().getExtras().getString("name"));
                intent.putExtra("alternate_mobile",getIntent().getExtras().getString("alternate_mobile"));
                intent.putExtra("mobile",getIntent().getExtras().getString("mobile"));
                intent.putExtra("addresstype",getIntent().getExtras().getString("addresstype"));

                startActivity(intent);
                finish();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        } else {
            Toast.makeText(getApplicationContext(), item.getTitle(), Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }
}