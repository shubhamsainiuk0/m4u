package com.m4ub2b.iezant.account;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.Toolbar;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.chaos.view.PinView;
import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.model.ApiResponse;
import com.m4ub2b.iezant.simpleclasses.RetrofitClient;
import com.m4ub2b.iezant.utils.Tools;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EmailVerificationCode extends AppCompatActivity {

    private AppCompatButton btn_verify;
    private PinView otp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email_verification_code);
        initToolbar();
        initComponent();
    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(null);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Tools.setSystemBarColor(this, android.R.color.white);
        Tools.setSystemBarLight(this);
   }

    private void initComponent() {
        btn_verify=findViewById(R.id.btn_verify);
        otp=findViewById(R.id.otp);

        btn_verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkEmail();
               // startActivity(new Intent(EmailVerificationCode.this,ChangePassword.class));
               // Toast.makeText(EmailVerificationCode.this, "My Email :"+email, Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void checkEmail() {

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();

        //first getting the values
        final String otpStr = otp.getText().toString();
        final String email=getIntent().getExtras().getString("uemail");
        //validating inputs
        if (otpStr.length()<6) {
            otp.setError("Please enter otp");
            otp.requestFocus();
            progressDialog.dismiss();
            return;
        }

        Call<ApiResponse> call = RetrofitClient.getInstance().getApi().checkotp(email,otpStr);
        call.enqueue(new Callback<ApiResponse>() {
            @Override
            public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                progressDialog.dismiss();

                Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                if (response.body().isApistatus()) {
                    Intent intent=new Intent(EmailVerificationCode.this, ChangePassword.class);
                    intent.putExtra("uemail",email);
                    intent.putExtra("otp",otpStr);
                    startActivity(intent);
                    finish();
                }
                else{
                    Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<ApiResponse> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        } else {
            Toast.makeText(getApplicationContext(), item.getTitle(), Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }
}