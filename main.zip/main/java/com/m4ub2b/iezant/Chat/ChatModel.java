package com.m4ub2b.iezant.Chat;

public class ChatModel {
    private String sender;
    private String receiver;
    private String message,messageID, time, date, name,type;
    private boolean isseen;

    public ChatModel() {
    }

    public ChatModel(String sender, String receiver, String message, boolean isseen, String messageID, String time, String date, String name,String type) {
        this.sender = sender;
        this.receiver = receiver;
        this.message = message;
        this.isseen=isseen;

        this.messageID = messageID;
        this.time = time;
        this.date = date;
        this.name = name;
        this.type = type;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isIsseen() {
        return isseen;
    }

    public void setIsseen(boolean isseen) {
        this.isseen = isseen;
    }

    public String getMessageID() {
        return messageID;
    }

    public void setMessageID(String messageID) {
        this.messageID = messageID;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
