package com.m4ub2b.iezant.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.simpleclasses.LocationPicker;
import com.m4ub2b.iezant.simpleclasses.MapUtilityy;

public class MyMapTest extends AppCompatActivity {

    private TextView txtLatLong,map_btn;
    private TextView txtAddress;

    private static final int ADDRESS_PICKER_REQUEST = 1020;
  // String address="Haridwar",latitude="29.8641178",longitude="77.8865376";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_map_test);
        map_btn=findViewById(R.id.map_btn);
        MapUtilityy.apiKey = getResources().getString(R.string.google_maps_key);

        txtLatLong = findViewById(R.id.txtLatLong);

        txtAddress = findViewById(R.id.txtAddress);
        findViewById(R.id.map_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MyMapTest.this, LocationPicker.class);
              /*  intent.putExtra(MapUtilityy.ADDRESS,address);
                intent.putExtra(MapUtilityy.LATITUDE, latitude);
                intent.putExtra(MapUtilityy.LONGITUDE, longitude);*/
                startActivityForResult(intent, ADDRESS_PICKER_REQUEST);
            }
        });

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ADDRESS_PICKER_REQUEST) {
            try {
                if (data != null && data.getStringExtra(MapUtilityy.ADDRESS) != null) {
                    // String address = data.getStringExtra(MapUtility.ADDRESS);
                    double currentLatitude = data.getDoubleExtra(MapUtilityy.LATITUDE, 0.0);
                    double currentLongitude = data.getDoubleExtra(MapUtilityy.LONGITUDE, 0.0);
                    Bundle completeAddress =data.getBundleExtra("fullAddress");
                    /* data in completeAddress bundle
                    "fulladdress"
                    "city"
                    "state"
                    "postalcode"
                    "country"
                    "addressline1"
                    "addressline2"
                     */

                  /*  txtAddress.setText(new StringBuilder().append("addressline: ").append
                            (completeAddress.getString("addressline2")).append("\ncity: ").append
                            (completeAddress.getString("city")).append("\npostalcode: ").append
                            (completeAddress.getString("postalcode")).append("\nstate: ").append
                            (completeAddress.getString("state")).toString());
*/
                    txtAddress.setText(new StringBuilder().append("addressline: ").append
                            (completeAddress.getString("addressline2")).toString());

                    txtLatLong.setText(new StringBuilder().append("Lat:").append(currentLatitude).append
                            ("  Long:").append(currentLongitude).toString());

                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}