package com.m4ub2b.iezant.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.fragments.FragmentBottomSheetDialogFullMyorders;
import com.m4ub2b.iezant.model.Order;

import java.util.List;

public class AdapterAllOrders extends RecyclerView.Adapter<AdapterAllOrders.ViewHolder> {
  //  private List<AllOrder> allOrderList;
  private List<Order> allOrderList;
    private Context context;
    private String type;


    public AdapterAllOrders(Context context, List<Order> allOrderList,String type) {
        this.allOrderList = allOrderList;
        this.context=context;
        this.type=type;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater=LayoutInflater.from(parent.getContext());
        View listItem=layoutInflater.inflate(R.layout.item_myorder_list,parent,false);
        AdapterAllOrders.ViewHolder viewHolder=new AdapterAllOrders.ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Order allOrder=allOrderList.get(position);
        holder.name.setText("Item Name : "+allOrder.getItem_name());
        holder.amount.setText("Delivery Charge : ₹ "+allOrder.getDelivery_charge());
        holder.order_id.setText("ORDER ID : #"+allOrder.getId());
        holder.order_status.setText("Order Status : "+allOrder.getOrder_status());
        if(type.equals("complete")){
            holder.cardView.setCardBackgroundColor(ContextCompat.getColor(context,R.color.light_green_50));}
        if(type.equals("cancel")){
            holder.cardView.setCardBackgroundColor(ContextCompat.getColor(context,R.color.red_50));}
        holder.lyt_details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                FragmentBottomSheetDialogFullMyorders fragment = new FragmentBottomSheetDialogFullMyorders();
                fragment.setData(allOrder);
                fragment.show(((FragmentActivity)context).getSupportFragmentManager(), fragment.getTag());
            }
        });

    }

    @Override
    public int getItemCount() {
        return allOrderList.size();
    }

    public  static  class ViewHolder extends RecyclerView.ViewHolder{


        TextView name,order_id,order_status,amount;
        CardView cardView;
        LinearLayout lyt_details,lyt_track;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name=(TextView) itemView.findViewById(R.id.order_name);
            order_id=(TextView) itemView.findViewById(R.id.order_id);
            amount=(TextView) itemView.findViewById(R.id.order_amount);
            order_status=(TextView) itemView.findViewById(R.id.order_status);
            cardView=(CardView) itemView.findViewById(R.id.myorderCard);
            // amount=(TextView) itemView.findViewById(R.id.amount);
            lyt_details=itemView.findViewById(R.id.lyt_details);
            lyt_track=itemView.findViewById(R.id.lyt_track);
        }
    }
}
