package com.m4ub2b.iezant.fragments;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.adapter.AdapterAllOrders;
import com.m4ub2b.iezant.model.Order;
import com.m4ub2b.iezant.model.Orders;
import com.m4ub2b.iezant.model.User;
import com.m4ub2b.iezant.simpleclasses.RetrofitClient;
import com.m4ub2b.iezant.simpleclasses.SharedPrefManager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MyorderActive extends Fragment {

    View root;
    private RecyclerView recyclerView;
    private AdapterAllOrders mAdapter;
    List<Order> allOrderList;
    private String user_id;
    public MyorderActive() {
        // Required empty public constructor
    }

    public static MyorderActive newInstance() {
        MyorderActive fragment = new MyorderActive();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        root= inflater.inflate(R.layout.fragment_myorder_active, container, false);
        if (SharedPrefManager.getInstance(mContext).isLoggedIn()) {
            User customer = SharedPrefManager.getInstance(getActivity().getApplicationContext()).getUser();
            user_id=customer.getId();
        }
        initComonent();

        return root;
    }

    private void initComonent() {
        recyclerView = (RecyclerView) root.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(mContext));
        recyclerView.setHasFixedSize(true);
        recyclerView.setNestedScrollingEnabled(false);
        setPosts();

    }

    private void setPosts() {
        final ProgressDialog progressDialog = new ProgressDialog(mContext);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();
        Call<Orders> call = RetrofitClient.getInstance().getApi().ordersbyuser(user_id);
        call.enqueue(new Callback<Orders>() {
            @Override
            public void onResponse(Call<Orders> call, Response<Orders> response) {
                progressDialog.dismiss();

                Orders userDataResponse= response.body();

                if(userDataResponse.isApistatus()){
                    allOrderList=new ArrayList<>(Arrays.asList(userDataResponse.getOreders()));
                    mAdapter = new AdapterAllOrders(mContext, allOrderList,"active");
                    recyclerView.setAdapter(mAdapter);
                }
                else {
                    Toast.makeText(mContext, "No orders", Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(Call<Orders> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(mContext, t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

    }

    private Context mContext;
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mContext=context;
    }
}