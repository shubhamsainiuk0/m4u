package com.m4ub2b.iezant.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.model.Customer;
import com.m4ub2b.iezant.simpleclasses.RetrofitClient;
import com.m4ub2b.iezant.simpleclasses.URLs;
import com.mikhaellopez.circularimageview.CircularImageView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CustomerDetails extends AppCompatActivity {

    TextView address,bName,about,mobile,email;
    CircularImageView image;

    String user_id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_details);
        initToolbar();
        initComponent();
    }


    private void initToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_chevron_left_white);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(null);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }
    private void initComponent() {
        bName=findViewById(R.id.bName);
        about=findViewById(R.id.about);
        mobile=findViewById(R.id.mobile);
        email=findViewById(R.id.email);
        address=findViewById(R.id.address);
        image=findViewById(R.id.image);

        user_id=getIntent().getExtras().getString("uid");


        setData();

    }

    private void setData() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();


        Call<Customer> call = RetrofitClient.getInstance().getApi().userByidCustomer(user_id);
        call.enqueue(new Callback<Customer>() {
            @Override
            public void onResponse(Call<Customer> call, Response<Customer> response) {
                progressDialog.dismiss();

                //Seller userDataResponse= response.body();


                bName.setText(response.body().getName());
                address.setText(response.body().getAddress());
                about.setText(response.body().getAbout());
                mobile.setText(response.body().getMobile());
                email.setText(response.body().getEmail());


                Glide.with(getApplicationContext()).load(URLs.IMAGE_URL+response.body().getImage()).into(image);


            }

            @Override
            public void onFailure(Call<Customer> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();


            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.share_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        } else {

        }
        return super.onOptionsItemSelected(item);
    }
}
