package com.m4ub2b.iezant.model;


public class CategoryItemListModel {

    public int image;
    public String name,ratings,drecription,distance;

    public CategoryItemListModel(int image, String name, String ratings, String drecription, String distance) {
        this.image = image;
        this.name = name;
        this.ratings = ratings;
        this.drecription = drecription;
        this.distance = distance;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRatings() {
        return ratings;
    }

    public void setRatings(String ratings) {
        this.ratings = ratings;
    }

    public String getDrecription() {
        return drecription;
    }

    public void setDrecription(String drecription) {
        this.drecription = drecription;
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }
}
