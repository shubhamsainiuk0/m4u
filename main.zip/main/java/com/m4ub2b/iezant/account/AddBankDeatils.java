package com.m4ub2b.iezant.account;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Base64;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.switchmaterial.SwitchMaterial;
import com.google.android.material.textfield.TextInputLayout;
import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.model.User;
import com.m4ub2b.iezant.simpleclasses.RetrofitClient;
import com.m4ub2b.iezant.simpleclasses.SharedPrefManager;
import com.m4ub2b.iezant.simpleclasses.URLs;
import com.m4ub2b.iezant.utils.Tools;
import com.mikhaellopez.circularimageview.CircularImageView;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddBankDeatils extends AppCompatActivity {


    Button btn_submit;
    TextInputLayout phonepe_lt,googlepay_lt,paytm_lt;
    SwitchMaterial phonepe_switch,googlepay_switch,paytm_switch;
    EditText user_name,bank_name,ifsc_code,account_number,paytm_number,phonepe_number,googlepay_number;
    String user_id, uname_,bank_name_,account_number_,ifsc_code_ , phonepe_,googlepe_ ,paytm_;
    boolean isPhonepe,isGooglepay,isPaytm=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_bank_details);

        initToolbar();
        initComponent();

    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_chevron_left_white);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Bank Details");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Tools.setSystemBarColor(this, R.color.blue_600);
    }


    private void initComponent() {

        phonepe_lt=findViewById(R.id.phonepe_lt);
        googlepay_lt=findViewById(R.id.googlepay_lt);
        paytm_lt=findViewById(R.id.paytm_lt);
        phonepe_switch=findViewById(R.id.phonepe_switch);
        googlepay_switch=findViewById(R.id.googlePay_switch);
        paytm_switch=findViewById(R.id.paytm_switch);
        user_name=findViewById(R.id.user_name);
        bank_name=findViewById(R.id.bank_name);
        ifsc_code=findViewById(R.id.ifsc_code);
        account_number=findViewById(R.id.account_number);
        paytm_number=findViewById(R.id.paytm_number);
        googlepay_number=findViewById(R.id.googlepay_number);
        phonepe_number=findViewById(R.id.phonepe_number);
        phonepe_number=findViewById(R.id.phonepe_number);
        btn_submit=findViewById(R.id.btn_submit);


        if(SharedPrefManager.getInstance(getApplicationContext()).isLoggedIn()){
            User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();
            user_id=user.getId();
        }

        phonepe_switch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(compoundButton.isChecked()){
                    phonepe_lt.setVisibility(View.VISIBLE);
                    isPhonepe=true;
                }
                else{
                    isPhonepe=false;
                    phonepe_lt.setVisibility(View.GONE);
                    phonepe_=null;
                }
            }
        });
        googlepay_switch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(compoundButton.isChecked()){
                    googlepay_lt.setVisibility(View.VISIBLE);
                    isGooglepay=true;
                }
                else{
                    isGooglepay=false;
                    googlepay_lt.setVisibility(View.GONE);
                    googlepe_=null;
                }
            }
        });
        paytm_switch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(compoundButton.isChecked()){
                    paytm_lt.setVisibility(View.VISIBLE);
                    isPaytm=true;
                }
                else{
                    isPaytm=false;
                    paytm_lt.setVisibility(View.GONE);
                    paytm_=null;
                }
            }
        });
        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validateInput();
            }
        });
        getPaymentOptions();
    }

    private void getPaymentOptions() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();

        Call<User> call = RetrofitClient.getInstance().getApi().getpaymentoption(URLs.TOKEN,user_id);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();

                if (response.body().isApistatus()) {
                    User user=response.body();
                    user_name.setText(user.getUser_bank_name());
                    bank_name.setText(user.getBank_name());
                    account_number.setText(user.getAcc_number());
                    ifsc_code.setText(user.getIfsc_code());
                    if (user.getPhonepe()!=null){
                        phonepe_switch.setChecked(true);
                        phonepe_lt.setVisibility(View.VISIBLE);
                        isPhonepe=true;
                        phonepe_number.setText(user.getPhonepe());
                    }
                    else{
                        phonepe_switch.setChecked(false);
                        phonepe_lt.setVisibility(View.GONE);
                        isPhonepe=false;
                    }
                    if (user.getGooglepay()!=null){
                        googlepay_switch.setChecked(true);
                        googlepay_lt.setVisibility(View.VISIBLE);
                        isGooglepay=true;
                        googlepay_number.setText(user.getGooglepay());
                    }
                    else{
                        googlepay_switch.setChecked(false);
                        googlepay_lt.setVisibility(View.GONE);
                        isGooglepay=false;
                    }
                    if (user.getGooglepay()!=null){
                        paytm_switch.setChecked(true);
                        paytm_lt.setVisibility(View.VISIBLE);
                        isPaytm=true;
                        paytm_number.setText(user.getPaytm());
                    }
                    else{
                        paytm_switch.setChecked(false);
                        paytm_lt.setVisibility(View.GONE);
                        isPaytm=false;
                    }

                }
            }
            @Override
            public void onFailure(Call<User> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

    }


    private void validateInput() {
        uname_ = user_name.getText().toString();
        bank_name_ = bank_name.getText().toString();
        account_number_ = account_number.getText().toString();
        ifsc_code_ = ifsc_code.getText().toString();
        phonepe_ = phonepe_number.getText().toString();
        googlepe_ = googlepay_number.getText().toString();
        paytm_ = paytm_number.getText().toString();
        if (TextUtils.isEmpty(uname_)) {
            user_name.setError("Please enter");
            user_name.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(bank_name_)) {
            bank_name.setError("Please enter");
            bank_name.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(account_number_)) {
            account_number.setError("Please enter");
            account_number.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(ifsc_code_)) {
            ifsc_code.setError("Please enter");
            ifsc_code.requestFocus();
            return;
        }

        if(isPhonepe){
            if (TextUtils.isEmpty(phonepe_)) {
                phonepe_number.setError("Please enter");
                phonepe_number.requestFocus();
                return;
            }
        }
        else{
            phonepe_=null;
        }
        if(isGooglepay){
            if (TextUtils.isEmpty(googlepe_)) {
                googlepay_number.setError("Please enter");
                googlepay_number.requestFocus();
                return;
            }
        }
        else{
            googlepe_=null;
        }
        if(isPaytm){
            if (TextUtils.isEmpty(paytm_)) {
                paytm_number.setError("Please enter");
                paytm_number.requestFocus();
                return;
            }
        }
        else{
            paytm_=null;
        }
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();

        Call<User> call = RetrofitClient.getInstance().getApi().updatepaymentoption(URLs.TOKEN,user_id,uname_,bank_name_,account_number_,ifsc_code_,phonepe_,googlepe_,paytm_);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                progressDialog.dismiss();

                if (response.body().isApistatus()) {
                    getPaymentOptions();
                }
                Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
            }
            @Override
            public void onFailure(Call<User> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

   /* private void updateProfileData() {

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();

        //first getting the values
        final String name1 = name.getText().toString();
        final String email1 = email.getText().toString();
        final String mobile1 = mobile.getText().toString();
        final String address1 = address.getText().toString();
        final String businessName1 = business_name.getText().toString();
        final String businessDescription1 = business_description.getText().toString();
        final String aboutUs1 = about.getText().toString();
        final String gstinNumber1 = gstin.getText().toString();
        //validating inputs
        if (TextUtils.isEmpty(name1)) {
            name.setError("Please enter your Name");
            name.requestFocus();
            progressDialog.dismiss();
            return;
        }
        if (TextUtils.isEmpty(businessName1)) {
            business_name.setError("Please enter your Business Name");
            business_name.requestFocus();
            progressDialog.dismiss();
            return;
        }
        if (TextUtils.isEmpty(businessDescription1)) {
            business_description.setError("Please enter your Business Description");
            business_description.requestFocus();
            progressDialog.dismiss();
            return;
        }
        if (TextUtils.isEmpty(aboutUs1)) {
            about.setError("Please enter About Us");
            about.requestFocus();
            progressDialog.dismiss();
            return;
        }
        if (TextUtils.isEmpty(email1)) {
            email.setError("Please enter your Email Id");
            email.requestFocus();
            progressDialog.dismiss();
            return;
        }

        if (TextUtils.isEmpty(address1)) {
            address.setError("Please enter your address");
            address.requestFocus();
            progressDialog.dismiss();
            return;
        }
        if (TextUtils.isEmpty(mobile1)) {
            mobile.setError("Please enter your mobile number");
            mobile.requestFocus();
            progressDialog.dismiss();
            return;
        }
        Call<User> call = RetrofitClient.getInstance().getApi().updateProfile(user_id,name1,email1,address1,businessName1,businessDescription1,aboutUs1,gstinNumber1,mobile1);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                if (response.body().isApistatus()) {
                    SharedPrefManager.getInstance(getApplicationContext()).userLogin(response.body());
                    startActivity(getIntent());
                    finish();
                }
                else{
                    Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                }
            }
            @Override
            public void onFailure(Call<User> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

    }
*/

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        } else {
            Toast.makeText(getApplicationContext(), item.getTitle(), Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }
}