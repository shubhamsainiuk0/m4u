package com.m4ub2b.iezant.account;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.Toolbar;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.chaos.view.PinView;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskExecutors;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.m4ub2b.iezant.MainActivity;
import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.model.User;
import com.m4ub2b.iezant.simpleclasses.RetrofitClient;
import com.m4ub2b.iezant.simpleclasses.SharedPrefManager;
import com.m4ub2b.iezant.simpleclasses.URLs;
import com.m4ub2b.iezant.utils.Tools;

import java.util.Locale;
import java.util.concurrent.TimeUnit;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PhoneAuthentication extends AppCompatActivity {

    private AppCompatButton btn_verify,sendOtp,resendCode;
    private PinView otp;
    private ImageButton sentIcon;
    private TextView tv_coundown;
    private CountDownTimer countDownTimer;
    private TextInputEditText mobile;
    private LinearLayout layoutSendBtn,layoutVerifyBtn;
    private int seconds;

    private FirebaseAuth mAuth;
    private String verificationId,user_id,email,mobilestatus,mobile_;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phone_authentication);
        initToolbar();
        initComponent();
    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(null);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Tools.setSystemBarColor(this, android.R.color.white);
        Tools.setSystemBarLight(this);
    }

    private void initComponent() {
        btn_verify=findViewById(R.id.btn_verify);
        sendOtp=findViewById(R.id.sendOtp);
        mobile=findViewById(R.id.mobile);
        sentIcon=findViewById(R.id.sentIcon);
        resendCode=findViewById(R.id.resentCode);
        layoutSendBtn=findViewById(R.id.layoutSendBtn);
        layoutVerifyBtn=findViewById(R.id.layoutVerifyBtn);
        otp=findViewById(R.id.otp);
        tv_coundown = (TextView) findViewById(R.id.tv_coundown);

        mAuth = FirebaseAuth.getInstance();

        if (SharedPrefManager.getInstance(getApplicationContext()).isLoggedIn()) {
            User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();
            email=user.getEmail();
            user_id = user.getId();
            mobilestatus = user.getMobilestatus();

            if(mobilestatus!=null){
            if(mobilestatus.equals("1")){
                startActivity(new Intent(PhoneAuthentication.this, MainActivity.class));
                finish();
            }
            }
        }

        sendOtp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 validateForm();
            }
        });
        btn_verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(otp.getText().toString())) {
                    Toast.makeText(PhoneAuthentication.this, "Please enter OTP", Toast.LENGTH_SHORT).show();
                } else {
                    verifyCode(otp.getText().toString());
                }
            }
        });
        resendCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mobile_ = mobile.getText().toString();
                if (TextUtils.isEmpty(mobile_)) {
                    mobile.setError("Please enter number");
                    mobile.requestFocus();
                    return;
                }
                String phone = "+91" + mobile_;
                sendVerificationCode(phone);
                otp.setText("");
                countDownTimer();
            }
        });
    }

    private void validateForm() {
        mobile_ = mobile.getText().toString();
        if (TextUtils.isEmpty(mobile_)) {
            mobile.setError("Please enter number");
            mobile.requestFocus();
            return;
        }


        String phone = "+91" + mobile_;
        sendVerificationCode(phone);

        layoutSendBtn.setVisibility(View.GONE);
        layoutVerifyBtn.setVisibility(View.VISIBLE);
        sentIcon.setVisibility(View.VISIBLE);
        countDownTimer();

    }
    private void signInWithCredential(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(PhoneAuthentication.this, "Successfull", Toast.LENGTH_SHORT).show();
                            upadatePhoneStatus();
                        } else {
                            Toast.makeText(PhoneAuthentication.this, task.getException().getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }


    private void upadatePhoneStatus() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();

        Call<User> call = RetrofitClient.getInstance().getApi().verifymobile(URLs.TOKEN,user_id,email,mobile_);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                progressDialog.dismiss();

                if (response.body().isStatus()) {
                    if(response.body().getMobilestatus().equals("1")) {
                        SharedPrefManager.getInstance(getApplicationContext()).userLogin(response.body());
                        startActivity(new Intent(PhoneAuthentication.this, AddLocation.class));
                        finish();
                    }
                    Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();

            }
        });
    }


    private void sendVerificationCode(String number) {

        PhoneAuthProvider.getInstance().verifyPhoneNumber(number, 60,TimeUnit.SECONDS, this, mCallBack  );
    }
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks
            mCallBack = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
        @Override
        public void onCodeSent(String s, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
            super.onCodeSent(s, forceResendingToken);
            verificationId = s;
            Log.d("123321oncodesent",s);
        }
        @Override
        public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {
            final String code = phoneAuthCredential.getSmsCode();
              if (code != null) {
                otp.setText(code);
                  Log.d("123321onveriComplete",code);
                verifyCode(code);

            }
        }
        @Override
        public void onVerificationFailed(FirebaseException e) {
            Toast.makeText(PhoneAuthentication.this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    };

    private void verifyCode(String code) {

        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationId, code);
        Log.d("123321verifyCode",verificationId+","+code);
        signInWithCredential(credential);
    }

    private void countDownTimer() {
        countDownTimer = new CountDownTimer(1000 * 60 * 2, 1000) {
            @Override
            public void onTick(long l) {
                String text = String.format(Locale.getDefault(), "%02d:%02d",
                        TimeUnit.MILLISECONDS.toMinutes(l) % 60,
                        TimeUnit.MILLISECONDS.toSeconds(l) % 60);
                tv_coundown.setText(text);
                //seconds=TimeUnit.MILLISECONDS.toSeconds(l) % 60;
                if(TimeUnit.MILLISECONDS.toSeconds(l) % 60==0){
                    resendCode.setVisibility(View.VISIBLE);
                }
                else{
                    resendCode.setVisibility(View.GONE);
                }
            }

            @Override
            public void onFinish() {
                tv_coundown.setText("00:00");
            }
        };
        countDownTimer.start();
    }

}