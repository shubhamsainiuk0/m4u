package com.m4ub2b.iezant.delivery;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.model.ApiResponse;
import com.m4ub2b.iezant.model.User;
import com.m4ub2b.iezant.model.WalletBalance;
import com.m4ub2b.iezant.simpleclasses.RetrofitClient;
import com.m4ub2b.iezant.simpleclasses.SharedPrefManager;
import com.m4ub2b.iezant.simpleclasses.URLs;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DeliveryOrderDetails extends AppCompatActivity {

    EditText category,item_name,item_value,weight;
    EditText sender_name,sender_mobile,sender_address;
    EditText receiver_name,receiver_mobile,receiver_address,receiver_alternate_mobile;

    String sender_name_,sender_mobile_,sender_address_,deliverAddress,addresstype;
    String receiver_name_,receiver_mobile_,receiver_address_,receiver_alternate_mobile_;
    private double wallet;
    private TextView wallet_balance,delivery_charge;
    RadioGroup rg_wallet;
    Button bt_save;
    double senderLatitude,senderLongitude,deliverLatitude,deliverLongitude, delivery_charge_;
    String weight_,category_name,area_manager_id,category_id,user_id,item_name_,item_value_;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery_order_details);
       initToolbar();
        initComponent();
    }
    private void initToolbar() {
        androidx.appcompat.widget.Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_chevron_left);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Order Details");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private void initComponent() {
        category = findViewById(R.id.category);
        weight = findViewById(R.id.weight);
        item_name = findViewById(R.id.item_name);
        item_value = findViewById(R.id.item_value);
        bt_save = findViewById(R.id.btn_save);

        sender_name=findViewById(R.id.sender_name);
        sender_mobile=findViewById(R.id.sender_mobile);
        sender_address=findViewById(R.id.sender_address);

        receiver_name=findViewById(R.id.receiver_name);
        receiver_alternate_mobile=findViewById(R.id.receiver_alternate_mobile);
        receiver_mobile=findViewById(R.id.receiver_mobile);
        receiver_address=findViewById(R.id.receiver_address);
        delivery_charge=findViewById(R.id.delivery_charge);
        rg_wallet=findViewById(R.id.rg_wallet);
        wallet_balance=findViewById(R.id.wallet_balance);
        if (SharedPrefManager.getInstance(DeliveryOrderDetails.this).isLoggedIn()) {
            User customer = SharedPrefManager.getInstance(getApplicationContext()).getUser();
            user_id=customer.getId();
            sender_name.setText(customer.getName());
            sender_mobile.setText(customer.getMobile());
            sender_address.setText(customer.getAddress());
        }

        //getIntent data
        weight_ =getIntent().getExtras().getString("weight");
        category_name =getIntent().getExtras().getString("category_name");
        senderLatitude =getIntent().getExtras().getDouble("senderLongitude");
        senderLongitude =getIntent().getExtras().getDouble("senderLongitude");
        deliverLatitude =getIntent().getExtras().getDouble("deliverLatitude");
        deliverLongitude =getIntent().getExtras().getDouble("deliverLongitude");
        delivery_charge_ =getIntent().getExtras().getDouble("delivery_charge");
        area_manager_id=getIntent().getExtras().getString("area_manager_id");
        category_id=getIntent().getExtras().getString("category_id");
        deliverAddress=getIntent().getExtras().getString("deliverAddress");
        receiver_name_=getIntent().getExtras().getString("name");
        receiver_mobile_=getIntent().getExtras().getString("mobile");
        receiver_alternate_mobile_=getIntent().getExtras().getString("alternate_mobile");
        addresstype=getIntent().getExtras().getString("addresstype");


        //validating inputs
        category.setText(category_name);
        receiver_address.setText(deliverAddress);
        if(receiver_name_!=null&&receiver_mobile_!=null&&receiver_alternate_mobile_!=null){
            receiver_name.setText(receiver_name_);
            receiver_mobile.setText(receiver_mobile_);
            receiver_alternate_mobile.setText(receiver_alternate_mobile_);
        }
        weight.setText("Weight : "+weight_+" kg");

        getBalance();
        bt_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                int selectedId = rg_wallet.getCheckedRadioButtonId();
                if(selectedId==-1) {
                    Toast.makeText(DeliveryOrderDetails.this, "Please Select Wallet", Toast.LENGTH_SHORT).show();
                }
                else{
                    if (selectedId == R.id.rb_wallet_balance) {
                        if (wallet <= delivery_charge_) {
                            Toast.makeText(DeliveryOrderDetails.this, "Insufficient wallet balance, TOP UP your wallet", Toast.LENGTH_LONG).show();
                        } else {
                            validateForm();
                        }
                    }
                }
            }
        });
    }

    private void validateForm() {
        item_name_ = item_name.getText().toString();
        item_value_ = item_value.getText().toString();

        //get sender addresss
        sender_name_=sender_name.getText().toString();
        sender_mobile_=sender_mobile.getText().toString();
        sender_address_=sender_address.getText().toString();

        //get receiver address
        receiver_name_=receiver_name.getText().toString();
        receiver_mobile_=receiver_mobile.getText().toString();
        receiver_alternate_mobile_=receiver_alternate_mobile.getText().toString();
        receiver_address_=receiver_address.getText().toString();

        if (TextUtils.isEmpty(item_name_)) {
            item_name.setError("Please enter");
            item_name.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(item_value_)) {
            item_value.setError("Please enter");
            item_value.requestFocus();
            return;
        }
        //sender validation
        if (TextUtils.isEmpty(sender_name_)) {
            sender_name.setError("Please enter");
            sender_name.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(sender_mobile_)) {
            sender_mobile.setError("Please enter");
            sender_mobile.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(sender_address_)) {
            sender_address.setError("Please enter");
            sender_address.requestFocus();
            return;
        }

        //receiver validation
        if (TextUtils.isEmpty(receiver_name_)) {
            receiver_name.setError("Please enter");
            receiver_name.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(receiver_mobile_)) {
            receiver_mobile.setError("Please enter");
            receiver_mobile.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(receiver_address_)) {
            receiver_address.setError("Please enter");
            receiver_address.requestFocus();
            return;
        } if (TextUtils.isEmpty(receiver_alternate_mobile_)) {
            receiver_alternate_mobile.setError("Please enter");
            receiver_alternate_mobile.requestFocus();
            return;
        }
        if(addresstype.equals("new")){
             saveAddress();}
        else{
            submitOrder();
        }
    }

    private void submitOrder() {
       // Log.d("deliveryorder",area_manager_id+","+delivery_charge_);
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();
        Call<ApiResponse> call = RetrofitClient.getInstance().getApi().createorder(area_manager_id,user_id,category_id,weight_,item_name_,
                item_value_, delivery_charge_,senderLatitude,senderLongitude,
                deliverLatitude,deliverLongitude,sender_name_,sender_mobile_,sender_address_,receiver_name_
                ,receiver_mobile_,receiver_alternate_mobile_,receiver_address_);
        call.enqueue(new Callback<ApiResponse>() {
            @Override
            public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                progressDialog.dismiss();
                Toast.makeText(DeliveryOrderDetails.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                if(response.body().isApistatus()){
                    Intent intent=new Intent(DeliveryOrderDetails.this, DeliverySuccessfull.class);
                    intent.putExtra("orderid",response.body().getOrderid());
                    startActivity(intent);
                    finish();
                }
            }

            @Override
            public void onFailure(Call<ApiResponse> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
    private void saveAddress() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();
        Call<ApiResponse> call = RetrofitClient.getInstance().getApi().saveAddress(URLs.TOKEN,user_id,receiver_name_,receiver_mobile_,receiver_alternate_mobile_,receiver_address_,deliverLatitude,deliverLongitude);
        call.enqueue(new Callback<ApiResponse>() {
            @Override
            public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                progressDialog.dismiss();
                Toast.makeText(DeliveryOrderDetails.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                if(response.body().isApistatus()){
                    submitOrder();
                }
            }

            @Override
            public void onFailure(Call<ApiResponse> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
    private void getBalance() {

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();

        Call<WalletBalance> call = RetrofitClient.getInstance().getApi().walletbalance(user_id);
        call.enqueue(new Callback<WalletBalance>() {
            @Override
            public void onResponse(Call<WalletBalance> call, Response<WalletBalance> response) {
                progressDialog.dismiss();

                //Toast.makeText(getApplicationContext(), response.body().getUser_id(), Toast.LENGTH_LONG).show();
                if (response.body().isStatus()) {
                    wallet=Double.parseDouble(response.body().getWallet_balance());
                    wallet_balance.setText("₹ "+response.body().getWallet_balance()+".0");
                }
                else{
                    wallet=Double.parseDouble("0");
                    wallet_balance.setText("₹ 0");
                }
            }

            @Override
            public void onFailure(Call<WalletBalance> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        } else {
            Toast.makeText(getApplicationContext(), item.getTitle(), Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }

}