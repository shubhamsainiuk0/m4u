package com.m4ub2b.iezant.account;

import android.Manifest;
import android.app.Dialog;
import android.app.DownloadManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.adapter.AdapterPosts;
import com.m4ub2b.iezant.model.PostDataResponse;
import com.m4ub2b.iezant.model.SellerPostResponse;
import com.m4ub2b.iezant.model.User;
import com.m4ub2b.iezant.simpleclasses.RetrofitClient;
import com.m4ub2b.iezant.simpleclasses.SharedPrefManager;
import com.m4ub2b.iezant.simpleclasses.URLs;
import com.github.chrisbanes.photoview.PhotoView;
import com.mikhaellopez.circularimageview.CircularImageView;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProfileDeatils extends AppCompatActivity {

    TextView name,address,editProfile,bName,bDesc,about,nameU;
    ImageView imagebg;
    CircularImageView image;
    LinearLayout callNow;
    String mobile,cat_id, uid,uname,imagee,imagebgg,bNamee,bDescc,aboutt;
    LinearLayout indicatorlay;
    private RecyclerView recyclerView;
    private AdapterPosts mAdapter;
    List<SellerPostResponse> userList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_deatils);
        initToolbar();
        initComponent();

    }


    private void initToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_chevron_left_white);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(null);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }
    private void initComponent() {
        name=findViewById(R.id.name);
        bName=findViewById(R.id.bName);
        nameU=findViewById(R.id.nameU);
        bDesc=findViewById(R.id.bDesc);
        about=findViewById(R.id.about);
        address=findViewById(R.id.address);
        editProfile=findViewById(R.id.editProfile);
        image=findViewById(R.id.image);
        imagebg=findViewById(R.id.imagebg);
        callNow=findViewById(R.id.callNow);
        indicatorlay=(LinearLayout) findViewById(R.id.layout_dots);

        if(SharedPrefManager.getInstance(getApplicationContext()).isLoggedIn()){

            User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();
            uid=user.getId();
        }
        userdata();


        recyclerView = (RecyclerView) findViewById(R.id.recyclerViewPost);
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(getApplicationContext());
        linearLayoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(linearLayoutManager);

        recyclerView.setHasFixedSize(true);
        recyclerView.setNestedScrollingEnabled(false);
        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                zoomProfile(imagee);
            }

        });
        imagebg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                zoomProfileBG(imagebgg);
            }

        });
        editProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(), UpdateProfileActivity.class);
                startActivity(intent);
            }
        });
        callNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               callPhoneNumber();
            }
        });

    }

    private void zoomProfile(String imagee)  {
        final Dialog dialog = new Dialog(ProfileDeatils.this,R.style.DialogTheme);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
        dialog.setContentView(R.layout.activity_chat_image_view);
        PhotoView imageView=dialog.findViewById(R.id.imageViewChat);
        ImageButton imageButton=dialog.findViewById(R.id.bt_close);
        dialog.setCancelable(true);
        dialog.show();
        Button bt_save=dialog.findViewById(R.id.bt_save);
        Glide.with(ProfileDeatils.this).load(URLs.IMAGE_URL+imagee).into(imageView);

        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        bt_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try{
                    DownloadManager dm = (DownloadManager) getApplicationContext().getSystemService(Context.DOWNLOAD_SERVICE);
                    Uri downloadUri = Uri.parse(URLs.IMAGE_URL+imagee);
                    DownloadManager.Request request = new DownloadManager.Request(downloadUri);
                    request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI | DownloadManager.Request.NETWORK_MOBILE)
                            .setAllowedOverRoaming(false)
                            .setTitle("Image Downloading")
                            .setMimeType("image/jpeg") // Your file type. You can use this code to download other file types also.
                            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                            .setDestinationInExternalPublicDir(Environment.DIRECTORY_PICTURES, File.separator +  "profile_"+uid + ".jpg");
                    dm.enqueue(request);
                    Toast.makeText(getApplicationContext(), "Image download started.", Toast.LENGTH_SHORT).show();
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(), "Image download failed.", Toast.LENGTH_SHORT).show();
                }

            }
        });

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.BLACK));

        dialog.setCancelable(true);
        dialog.show();
    }
    private void zoomProfileBG(String imageebg)  {
        final Dialog dialog = new Dialog(ProfileDeatils.this,R.style.DialogTheme);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
        dialog.setContentView(R.layout.activity_chat_image_view);
        PhotoView imageView=dialog.findViewById(R.id.imageViewChat);
        ImageButton imageButton=dialog.findViewById(R.id.bt_close);
        dialog.setCancelable(true);
        dialog.show();
        Button bt_save=dialog.findViewById(R.id.bt_save);
        Glide.with(ProfileDeatils.this).load(URLs.IMAGE_URL+imageebg).into(imageView);

        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        bt_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try{
                    DownloadManager dm = (DownloadManager) getApplicationContext().getSystemService(Context.DOWNLOAD_SERVICE);
                    Uri downloadUri = Uri.parse(URLs.IMAGE_URL+imageebg);
                    DownloadManager.Request request = new DownloadManager.Request(downloadUri);
                    request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI | DownloadManager.Request.NETWORK_MOBILE)
                            .setAllowedOverRoaming(false)
                            .setTitle("Image Downloading")
                            .setMimeType("image/jpeg") // Your file type. You can use this code to download other file types also.
                            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                            .setDestinationInExternalPublicDir(Environment.DIRECTORY_PICTURES, File.separator + "bgimage_"+uid + ".jpg");
                    dm.enqueue(request);
                    Toast.makeText(getApplicationContext(), "Image download started.", Toast.LENGTH_SHORT).show();
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(), "Image download failed.", Toast.LENGTH_SHORT).show();
                }

            }
        });

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.BLACK));

        dialog.setCancelable(true);
        dialog.show();
    }
    private void userdata() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();
        Call<User> call = RetrofitClient.getInstance().getApi().userbyid(uid);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                progressDialog.dismiss();

                User user= response.body();
                if(user.isStatus()) {
                    uname=user.getName();
                    cat_id=user.getCategory_id();
                    setAdapter(cat_id);
                    imagee=user.getImage();
                    imagebgg=user.getImagebg();
                    bNamee=user.getBusiness_name();
                    bDescc=user.getBusiness_description();
                    aboutt=user.getAbout();
                    mobile=user.getMobile();
                    address.setText(user.getAddress());

                    name.setText(uname);

                    if(bNamee==null){bName.setText("Not Updated"); }
                    else {bName.setText(bNamee);
                    }

                    if (bDescc==null){bDesc.setText("Not Updated");}
                    else {bDesc.setText(bDescc);}

                    if (aboutt==null){about.setText("Not Updated");}
                    else {about.setText(aboutt);}
                    Glide.with(getApplicationContext()).load(URLs.IMAGE_URL+imagee).into(image);
                    Glide.with(getApplicationContext()).load(URLs.IMAGE_URL+imagebgg).into(imagebg);
                }

            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });


    }

    private void setAdapter(String cat_id) {

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();
        String myposts=getIntent().getExtras().getString("myposts");
        Call<PostDataResponse> call = RetrofitClient.getInstance().getApi().userposts(uid,cat_id);
        call.enqueue(new Callback<PostDataResponse>() {
            @Override
            public void onResponse(Call<PostDataResponse> call, Response<PostDataResponse> response) {
                progressDialog.dismiss();

                PostDataResponse userDataResponse= response.body();
                if(userDataResponse.isApistatus()){
                    userList=new ArrayList<>(Arrays.asList(userDataResponse.getPost()));
                    mAdapter = new AdapterPosts(ProfileDeatils.this, userList,uname,imagee,myposts);
                    recyclerView.setAdapter(mAdapter);
                }
            }

            @Override
            public void onFailure(Call<PostDataResponse> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

    }

    public void callPhoneNumber()
    {
        try
        {
            if(Build.VERSION.SDK_INT > 22)
            {
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    ActivityCompat.requestPermissions(ProfileDeatils.this, new String[]{Manifest.permission.CALL_PHONE}, 101);

                    return;
                }

                Intent callIntent = new Intent(Intent.ACTION_CALL);
                callIntent.setData(Uri.parse("tel:" + mobile));
                startActivity(callIntent);

            }
            else {
                Intent callIntent = new Intent(Intent.ACTION_CALL);
                callIntent.setData(Uri.parse("tel:" + mobile));
                startActivity(callIntent);
            }
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults)
    {
        if(requestCode == 101)
        {
            if(grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                callPhoneNumber();
            }
            else
            {
                Log.e("callpermission", "Permission not Granted");
            }
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.share_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        } else {
            Toast.makeText(getApplicationContext(), item.getTitle(), Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }
  /*  @Override
    public void onResume() {
        super.onResume();
        this.recreate();
        //When BACK BUTTON is pressed, the activity on the stack is restarted
        //Do what you want on the refresh procedure here
    }*/
    @Override
    public void onRestart() {
        super.onRestart();
        this.recreate();
        //When BACK BUTTON is pressed, the activity on the stack is restarted
        //Do what you want on the refresh procedure here
    }

}
