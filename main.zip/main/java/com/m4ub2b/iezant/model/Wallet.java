package com.m4ub2b.iezant.model;

public class Wallet {
    private String id,user_id,wallet,transaction_amount,debit,remarks,created_at;

    public Wallet(String id, String user_id, String wallet, String transaction_amount, String debit, String remarks, String created_at) {
        this.id = id;
        this.user_id = user_id;
        this.wallet = wallet;
        this.transaction_amount = transaction_amount;
        this.debit = debit;
        this.remarks = remarks;
        this.created_at = created_at;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getWallet() {
        return wallet;
    }

    public void setWallet(String wallet) {
        this.wallet = wallet;
    }

    public String getTransaction_amount() {
        return transaction_amount;
    }

    public void setTransaction_amount(String transaction_amount) {
        this.transaction_amount = transaction_amount;
    }

    public String getDebit() {
        return debit;
    }

    public void setDebit(String debit) {
        this.debit = debit;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }
}
