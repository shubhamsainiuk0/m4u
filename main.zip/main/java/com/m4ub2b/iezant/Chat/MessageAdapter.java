package com.m4ub2b.iezant.Chat;

import android.app.Dialog;
import android.app.DownloadManager;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

/*import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;*/
import com.balysv.materialripple.MaterialRippleLayout;
import com.bumptech.glide.Glide;
import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.model.User;
import com.m4ub2b.iezant.simpleclasses.SharedPrefManager;
import com.github.chrisbanes.photoview.PhotoView;

import java.io.File;
import java.util.List;

public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.ViewHolder> {
    private List<ChatModel> chatList;
    private Context context;
    String user_id;
    ProgressDialog mProgressDialog;
    public static final int MSG_TYPE_LEFT=0;
    public static final int MSG_TYPE_RIGHT=1;

   // FirebaseUser fuser;

    public MessageAdapter(List<ChatModel> chatList, Context context){
        this.chatList=chatList;
        this.context=context;
    }

    @NonNull
    @Override
    public MessageAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        if (viewType==MSG_TYPE_RIGHT){
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.item_message_sent, parent, false);

        return new MessageAdapter.ViewHolder(listItem);
        }else {
            LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
            View listItem= layoutInflater.inflate(R.layout.item_message_received, parent, false);

            return new MessageAdapter.ViewHolder(listItem);
        }

    }

    public void deleteItem(int position){
        final ChatModel chat=chatList.get(position);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        final ChatModel chat=chatList.get(position);
        //holder.chatImage.setVisibility(View.GONE);
      //  holder.textTypeLayout.setVisibility(View.GONE);
        //holder.fileTypeLayout.setVisibility(View.GONE);
        holder.materialRippleLayout1.setVisibility(View.GONE);
        holder.materialRippleLayout2.setVisibility(View.GONE);
        holder.materialRippleLayout3.setVisibility(View.GONE);

        if(chat.isIsseen()){
            holder.seen1.setImageResource(R.drawable.ic_done_all);
            holder.seen1.setColorFilter(ContextCompat.getColor(context,R.color.blue_500));
            holder.seen2.setImageResource(R.drawable.ic_done_all);
            holder.seen2.setColorFilter(ContextCompat.getColor(context,R.color.blue_500));
            holder.seen3.setImageResource(R.drawable.ic_done_all);
            holder.seen3.setColorFilter(ContextCompat.getColor(context,R.color.blue_500));
        }else {
            holder.seen1.setImageResource(R.drawable.ic_done);
            holder.seen1.setColorFilter(ContextCompat.getColor(context,R.color.grey_80));
            holder.seen2.setImageResource(R.drawable.ic_done);
            holder.seen2.setColorFilter(ContextCompat.getColor(context,R.color.grey_80));
            holder.seen3.setImageResource(R.drawable.ic_done);
            holder.seen3.setColorFilter(ContextCompat.getColor(context,R.color.grey_80));
        }

        if(chat.getType().equals("text")){
           // holder.textTypeLayout.setVisibility(View.VISIBLE);
            holder.materialRippleLayout1.setVisibility(View.VISIBLE);
            holder.time1.setText(chat.getTime());
            holder.show_message.setText(chat.getMessage());
            holder.materialRippleLayout1.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    ClipboardManager clipboardManager=(ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
                    ClipData clipData=ClipData.newPlainText("TextView",chat.getMessage());
                    clipboardManager.setPrimaryClip(clipData);
                    Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show();
                    holder.materialRippleLayout1.setClickable(true);
                    return false;
                }
            });
        }else if(chat.getType().equals("image")){
            //holder.chatImage.setVisibility(View.VISIBLE);
            holder.materialRippleLayout2.setVisibility(View.VISIBLE);
            holder.time2.setText(chat.getTime());
            Glide.with(context).load(chat.getMessage()).into(holder.image);
             holder.image.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final Dialog dialog = new Dialog(context,R.style.DialogTheme);
                    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
                    dialog.setContentView(R.layout.activity_chat_image_view);
                    PhotoView imageView=dialog.findViewById(R.id.imageViewChat);
                    ImageButton imageButton=dialog.findViewById(R.id.bt_close);
                    dialog.setCancelable(true);
                    dialog.show();

                    Button bt_save=dialog.findViewById(R.id.bt_save);
                    //ImageButton imageButton=dialog.findViewById(R.id.bt_close);
                    Glide.with(context).load(chat.getMessage()).into(imageView);
                    //ZoomInImageViewAttacher mIvAttacterr = new ZoomInImageViewAttacher(imageView);

                    imageButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                        }
                    });
                    bt_save.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            try{
                                DownloadManager dm = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
                                Uri downloadUri = Uri.parse(chat.getMessage());
                                DownloadManager.Request request = new DownloadManager.Request(downloadUri);
                                request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI | DownloadManager.Request.NETWORK_MOBILE)
                                        .setAllowedOverRoaming(false)
                                        .setTitle(chat.getName())
                                        .setMimeType("image/jpeg") // Your file type. You can use this code to download other file types also.
                                        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                        .setDestinationInExternalPublicDir(Environment.DIRECTORY_PICTURES, File.separator + chat.getName() + ".jpg");
                                dm.enqueue(request);
                                Toast.makeText(context, "Image download started.", Toast.LENGTH_SHORT).show();
                            }catch (Exception e){
                                Toast.makeText(context, "Image download failed.", Toast.LENGTH_SHORT).show();
                            }

                        }
                    });

                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.BLACK));

                    dialog.setCancelable(true);
                    dialog.show();
                }
            });
        }else /*if(chat.getType().equals("image"))*/{
           // holder.fileTypeLayout.setVisibility(View.VISIBLE);
            holder.materialRippleLayout3.setVisibility(View.VISIBLE);
            holder.time3.setText(chat.getTime());
            holder.fileType.setImageResource(R.drawable.ic_file_type);
            String filename="";
            if(chat.getType().equals("pdf")){
                filename="Pdf File";
            }else{
                filename="Docx File";
            }
            holder.fileTypeName.setText(filename);
            holder.fileTypeLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent=new Intent(Intent.ACTION_VIEW, Uri.parse(chat.getMessage()));
                    holder.fileTypeLayout.getContext().startActivity(intent);
                }
            });


        }

    }

    @Override
    public int getItemCount() {
        return chatList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        //public CircleImageView userImage;
        public TextView show_message,fileTypeName,time1,time2,time3;
        public ImageView image,fileType,seen1,seen2,seen3;
        public CardView chatImage,materialRippleLayout1;
        public LinearLayout fileTypeLayout,textTypeLayout;
        MaterialRippleLayout materialRippleLayout2,materialRippleLayout3;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            this.show_message=itemView.findViewById(R.id.show_message);
            this.image=itemView.findViewById(R.id.imageChat);
            this.seen1=itemView.findViewById(R.id.seen1);
            this.seen2=itemView.findViewById(R.id.seen2);
            this.seen3=itemView.findViewById(R.id.seen3);
            this.chatImage=itemView.findViewById(R.id.chatImage);
            this.time1=itemView.findViewById(R.id.time1);
           this.time2=itemView.findViewById(R.id.time2);
           this.time3=itemView.findViewById(R.id.time3);
            this.materialRippleLayout1=itemView.findViewById(R.id.materialRippleLayout1);
            this.materialRippleLayout2=itemView.findViewById(R.id.materialRippleLayout2);
            this.materialRippleLayout3=itemView.findViewById(R.id.materialRippleLayout3);
           this.fileTypeLayout=itemView.findViewById(R.id.fileTypeLaypout);
           this.textTypeLayout=itemView.findViewById(R.id.textTypeLayout);
           this.fileTypeName=itemView.findViewById(R.id.fileTypeName);
           this.fileType= itemView.findViewById(R.id.fileType);
        }
    }

    @Override
    public int getItemViewType(int position) {
        //fuser= FirebaseAuth.getInstance().getCurrentUser();
        if(SharedPrefManager.getInstance(context).isLoggedIn()){

            User user = SharedPrefManager.getInstance(context).getUser();
            user_id=user.getId();
        }
        if (chatList.get(position).getSender().equals(user_id)){
            return MSG_TYPE_RIGHT;
        }else {
            return  MSG_TYPE_LEFT;
        }
    }


}
