package com.m4ub2b.iezant.model;

public class PostImageSlider {
    private int imageView;


    public PostImageSlider(int imageView) {
        this.imageView = imageView;
    }

    public int getImageView() {
        return imageView;
    }

    public void setImageView(int imageView) {
        this.imageView = imageView;
    }
}
