package com.m4ub2b.iezant.activity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.model.SellerPostResponse;
import com.m4ub2b.iezant.simpleclasses.RetrofitClient;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UpdatePost extends AppCompatActivity {


    List<String> imagesList;
    EditText titleName,price,description;
    Button bt_save;
    private String user_id,post_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_post);
        initToolbar();
        initComponent();
    }
    private void initToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_chevron_left);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Update Post");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private void initComponent() {
        titleName=findViewById(R.id.titleName);
        price=findViewById(R.id.price);
        description=findViewById(R.id.description);
        bt_save=findViewById(R.id.btn_save);
        titleName.setText(getIntent().getExtras().getString("title"));
        price.setText(getIntent().getExtras().getString("price"));
        description.setText(getIntent().getExtras().getString("description"));

        user_id=getIntent().getExtras().getString("uid");
        post_id=getIntent().getExtras().getString("pid");


        bt_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                postdata();
            }
        });
    }
    private void postdata() {

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();

        //first getting the values
        final String title = titleName.getText().toString();
        final String pricee = price.getText().toString();
        final String descriptionn = description.getText().toString();
        //validating inputs
        if (TextUtils.isEmpty(title)) {
            titleName.setError("Please enter Title");
            titleName.requestFocus();
            progressDialog.dismiss();
            return;
        }
        Call<SellerPostResponse> call = RetrofitClient.getInstance().getApi().updatepost(post_id,user_id,title,pricee,descriptionn);
        call.enqueue(new Callback<SellerPostResponse>() {
            @Override
            public void onResponse(Call<SellerPostResponse> call, Response<SellerPostResponse> response) {
                progressDialog.dismiss();
                if(response.body().isApistatus()){
                 Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                 //startActivity(new Intent(UpdatePost.this,MainActivity.class));
                 finish();
                }
                else{
                    Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<SellerPostResponse> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();


            }
        });
    }


    /*@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.c, menu);
        return true;
    }*/

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        } else {
            Toast.makeText(getApplicationContext(), item.getTitle(), Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }

}