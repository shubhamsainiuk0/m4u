package com.m4ub2b.iezant.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.activity.ItemDeatils;
import com.m4ub2b.iezant.model.User;
import com.m4ub2b.iezant.simpleclasses.URLs;
import com.mikhaellopez.circularimageview.CircularImageView;

import java.util.List;

public class AdapterCategoryItemList extends RecyclerView.Adapter<AdapterCategoryItemList.ViewHolder> {
    private List<User> userList;
    private Context context;
    private String category_id;

    public AdapterCategoryItemList(Context context, List<User> userList,String category_id) {
        this.userList = userList;
        this.context=context;
        this.category_id=category_id;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater=LayoutInflater.from(parent.getContext());
        View listItem=layoutInflater.inflate(R.layout.item_category_item_list,parent,false);
        AdapterCategoryItemList.ViewHolder viewHolder=new AdapterCategoryItemList.ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        User user=userList.get(position);
        holder.name.setText(user.getName());
       // Glide.with(context).load(user.getImage()).into(holder.image);
        Glide.with(context).load(URLs.IMAGE_URL+user.getImage()).into(holder.image);

        //holder.image.setImageResource(user.getImage());
        //holder.ratings.setText(userList[position].getRatings());*/
        holder.address.setText(user.getAddress());
       /* holder.location_distance.setText(userList[position].getDistance());*/
        holder.lyt_parent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(context, ItemDeatils.class);
                intent.putExtra("name",user.getName());
                intent.putExtra("image",user.getImage());
                intent.putExtra("imagebg",user.getImagebg());
                intent.putExtra("address",user.getAddress());
                intent.putExtra("bName",user.getBusinessName());
                intent.putExtra("bDesc",user.getBusiness_description());
                intent.putExtra("about",user.getAbout());
                intent.putExtra("mobile",user.getMobile());
                intent.putExtra("uid",user.getId());
                intent.putExtra("cat_id",category_id);
                context.startActivity(intent);

            }
        });
    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    public  static  class ViewHolder extends RecyclerView.ViewHolder{

        CircularImageView image;
        TextView name,ratings,location_distance,address;
        LinearLayout lyt_parent;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            image=(CircularImageView) itemView.findViewById(R.id.image);
            name=(TextView) itemView.findViewById(R.id.name);
            ratings=(TextView) itemView.findViewById(R.id.ratings);
            address=(TextView) itemView.findViewById(R.id.description);
            location_distance=(TextView) itemView.findViewById(R.id.location_distance);
            lyt_parent=itemView.findViewById(R.id.lyt_parent);
        }
    }
}
