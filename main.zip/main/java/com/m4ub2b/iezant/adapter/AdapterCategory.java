package com.m4ub2b.iezant.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.activity.CategoryItemList;
import com.m4ub2b.iezant.model.CategoryList;
import com.m4ub2b.iezant.simpleclasses.URLs;

import java.util.List;

public class AdapterCategory extends RecyclerView.Adapter<AdapterCategory.ViewHolder> {
    private List<CategoryList> categoryLists;
    private Context context;


    public AdapterCategory(Context context, List<CategoryList> categoryLists) {
        this.categoryLists = categoryLists;
        this.context=context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater=LayoutInflater.from(parent.getContext());
        View listItem=layoutInflater.inflate(R.layout.item_category_list,parent,false);
        AdapterCategory.ViewHolder viewHolder=new AdapterCategory.ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        CategoryList categoryList=categoryLists.get(position);
        holder.catName.setText(categoryList.getCat_name());
        Glide.with(context).load(URLs.IMAGE_URL+categoryList.getCat_image()).into(holder.catImage);
        holder.lyt_parent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(context, CategoryItemList.class);
                intent.putExtra("cat_id",categoryList.getId());
                intent.putExtra("cat_name",categoryList.getCat_name());
                context.startActivity(intent);

            }
        });
    }

    @Override
    public int getItemCount() {
        return categoryLists.size();
    }

    public  static  class ViewHolder extends RecyclerView.ViewHolder{

        ImageView catImage;
        TextView catName;
        LinearLayout lyt_parent;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            catImage=(ImageView) itemView.findViewById(R.id.cat_image);
            catName=(TextView) itemView.findViewById(R.id.cat_name);
            lyt_parent=itemView.findViewById(R.id.lyt_parent);
        }
    }
}
