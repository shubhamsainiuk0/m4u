package com.m4ub2b.iezant.fragments;

import android.app.Dialog;
import android.content.Intent;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.github.chrisbanes.photoview.PhotoView;
import com.m4ub2b.iezant.delivery.PackagingSlip;
import com.m4ub2b.iezant.model.Order;
import com.m4ub2b.iezant.simpleclasses.URLs;
import com.m4ub2b.iezant.utils.Tools;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.m4ub2b.iezant.R;


public class FragmentBottomSheetDialogFullMyorders extends BottomSheetDialogFragment {

    private BottomSheetBehavior mBehavior;
    private AppBarLayout app_bar_layout;
    private Order order;
   // private LinearLayout lyt_profile;

    public void setData(Order obj) {
        this.order = obj;
    }
    String pickImg_,deliverImg_;
    View pickedLine,deliveredLine;
    ImageView pickedImg,deliveredImg;
    TextView pickedTxt,deliveredTxt;
    LinearLayout pick_timeLL,deliver_timeLL;
    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        final BottomSheetDialog dialog = (BottomSheetDialog) super.onCreateDialog(savedInstanceState);
        final View view = View.inflate(getContext(), R.layout.fragment_bottom_sheet_dialog_full_myorders, null);

        dialog.setContentView(view);
        mBehavior = BottomSheetBehavior.from((View) view.getParent());
        mBehavior.setPeekHeight(BottomSheetBehavior.PEEK_HEIGHT_AUTO);

        app_bar_layout = (AppBarLayout) view.findViewById(R.id.app_bar_layout);
        TextView sender_name,sender_mobile,sender_address,receiver_name,receiver_mobile,receiver_alternate_mobile,receiver_address,order_id,
                ddate,order_status,delivery_charge,weight,pick_time,deliver_time,pickImg,deliverImg;

        order_id=view.findViewById(R.id.order_id);
        pickedTxt=view.findViewById(R.id.pickedTxt);
        deliveredTxt=view.findViewById(R.id.deliveredTxt);
        pickedLine=view.findViewById(R.id.pickedLine);
        deliveredLine=view.findViewById(R.id.deliveredLine);
        pickedImg=view.findViewById(R.id.pickedImg);
        deliveredImg=view.findViewById(R.id.deliveredImg);
        delivery_charge=view.findViewById(R.id.delivery_charge);
        weight=view.findViewById(R.id.weight);
        ddate=view.findViewById(R.id.ddate);

        pick_timeLL=view.findViewById(R.id.pick_timeLL);
        deliver_timeLL=view.findViewById(R.id.deliver_timeLL);

        order_status=view.findViewById(R.id.order_status);
        sender_name=view.findViewById(R.id.sender_name);
        sender_mobile=view.findViewById(R.id.sende_mobile);
        sender_address=view.findViewById(R.id.sender_address);
        receiver_name=view.findViewById(R.id.receiver_name);
        receiver_mobile=view.findViewById(R.id.receiver_mobile);
        receiver_alternate_mobile=view.findViewById(R.id.receiver_alternate_mobile);
        receiver_address=view.findViewById(R.id.receiver_address);
        pick_time=view.findViewById(R.id.pick_time);
        deliver_time=view.findViewById(R.id.deliver_time);

        pickImg=view.findViewById(R.id.pickImg);
        deliverImg=view.findViewById(R.id.deliverImg);
        order_id.setText("Order ID # "+order.getId());
        ddate.setText("Order Date : "+order.getCreated_at());


        order_status.setText("Order Status : "+order.getOrder_status());
        weight.setText("Weight : "+order.getWeight()+"kg");
        delivery_charge.setText("Delivery Charge ₹ "+order.getDelivery_charge());
        if(order.getPick_time()!=null){
            pick_timeLL.setVisibility(View.VISIBLE);
            pick_time.setText("Pickup time : "+order.getPick_time());
            pickImg_=order.getPick_image();
            pickedLine.setBackgroundColor(ContextCompat.getColor(getContext(), R.color.green_A700));
            pickedTxt.setTextColor(ContextCompat.getColor(getContext(), R.color.green_A700));
            pickedImg.setBackgroundResource(R.drawable.ic_check_circle_green);
            pickedImg.setColorFilter(getResources().getColor(R.color.green_500));
        }
        else{
            pickedImg.setBackgroundResource(R.drawable.ic_time);
        }
        if(order.getDeliver_time()!=null){
            deliver_timeLL.setVisibility(View.VISIBLE);
            deliver_time.setText("Deliver time : "+order.getDeliver_time());
            deliverImg_=order.getDeliver_image();
            deliveredTxt.setTextColor(ContextCompat.getColor(getContext(), R.color.green_A700));
            deliveredLine.setBackgroundColor(ContextCompat.getColor(getContext(), R.color.green_A700));
            deliveredImg.setBackgroundResource(R.drawable.ic_check_circle_green);
            deliveredImg.setColorFilter(getResources().getColor(R.color.green_A700)); // Add tint color
        }
        else{
            deliveredImg.setBackgroundResource(R.drawable.ic_time);
        }

        sender_name.setText("Name : "+order.getSender_name());
        sender_mobile.setText("Mobile : +91-"+order.getSender_mobile());
        sender_address.setText("Full Address : "+order.getSender_address());

        receiver_name.setText("Name : "+order.getReceiver_name());
        receiver_mobile.setText("Mobile : +91- "+order.getReceiver_mobile());
        receiver_alternate_mobile.setText("Alternate Num : +91- "+order.getReceiver_alternate_mobile());
        receiver_address.setText("Full Address : "+order.getReceiver_address());

        pickImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewImage(pickImg_);
            }
        });
        deliverImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewImage(deliverImg_);
            }
        });


        ((View) view.findViewById(R.id.lyt_spacer)).setMinimumHeight(Tools.getScreenHeight() / 2);
        hideView(app_bar_layout);

        mBehavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState) {
                if (BottomSheetBehavior.STATE_EXPANDED == newState) {
                    showView(app_bar_layout, getActionBarSize());
                   // hideView(lyt_profile);
                }
                if (BottomSheetBehavior.STATE_COLLAPSED == newState) {
                    hideView(app_bar_layout);
                    //showView(lyt_profile, getActionBarSize());
                }

                if (BottomSheetBehavior.STATE_HIDDEN == newState) {
                    dismiss();
                }
            }

            @Override
            public void onSlide(@NonNull View bottomSheet, float slideOffset) {

            }
        });
        ((ImageButton) view.findViewById(R.id.bt_close)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
        ((TextView) view.findViewById(R.id.download_slip)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getContext(), PackagingSlip.class);
                intent.putExtra("order_id",order.getId());
                startActivity(intent);
                dismiss();
            }
        });

        return dialog;
    }
    private void viewImage(String url){
        final Dialog dialog = new Dialog(getContext(),R.style.AppTheme);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
        dialog.setContentView(R.layout.fragment_view_image);
        PhotoView imageView=dialog.findViewById(R.id.imageViewChat);
        ImageButton imageButton=dialog.findViewById(R.id.bt_close);
        dialog.setCancelable(true);
        dialog.show();
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });

        RequestOptions options = new RequestOptions()
                .centerCrop()
                .placeholder(R.drawable.progress_animation)
                .error(R.drawable.ic_close)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .priority(Priority.HIGH)
                .dontAnimate()
                .dontTransform();
        Glide.with(getActivity().getApplicationContext()).load(URLs.IMAGE_URL+url).apply(options).into(imageView);


    }
    @Override
    public void onStart() {
        super.onStart();
        mBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
    }

    private void hideView(View view) {
        ViewGroup.LayoutParams params = view.getLayoutParams();
        params.height = 0;
        view.setLayoutParams(params);
    }

    private void showView(View view, int size) {
        ViewGroup.LayoutParams params = view.getLayoutParams();
        params.height = size;
        view.setLayoutParams(params);
    }

    private int getActionBarSize() {
        final TypedArray styledAttributes = getContext().getTheme().obtainStyledAttributes(new int[]{android.R.attr.actionBarSize});
        int size = (int) styledAttributes.getDimension(0, 0);
        return size;
    }
}
