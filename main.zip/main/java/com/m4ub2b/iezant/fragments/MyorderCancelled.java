package com.m4ub2b.iezant.fragments;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.adapter.AdapterMyorders;

public class MyorderCancelled extends Fragment {


    View root;
    private RecyclerView recyclerView;
    private AdapterMyorders mAdapter;

    public MyorderCancelled() {
        // Required empty public constructor
    }

    public static MyorderCancelled newInstance() {
        MyorderCancelled fragment = new MyorderCancelled();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        root= inflater.inflate(R.layout.fragment_myorder_cancelled, container, false);
/*
        MyOrdesModel[] allOrders=new MyOrdesModel[]{
                new MyOrdesModel("Cosmetic","Order has been Canceled","405","3332377241"),
                new MyOrdesModel("Document","Order has been Canceled","205","4332377241"),
                new MyOrdesModel("Books","Order has been Canceled","105","6732377241"),
                new MyOrdesModel("Document Packet","Order has been Canceled","45","5632377241"),
                new MyOrdesModel("Packet","Order has been Canceled","305","7632377241"),
                new MyOrdesModel("Books","Order has been Canceled","85","3232377241"),
                new MyOrdesModel("Garments Packet","Order has been Canceled","405","3332377241"),
                new MyOrdesModel("All Box Packet","Order has been Canceled","205","4332377241"),
                new MyOrdesModel("Mobile Packet","Order has been Canceled","105","6732377241"),
                new MyOrdesModel("Document Packet","Order has been Canceled","45","5632377241"),

        };

        recyclerView = (RecyclerView) root.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(mContext));
        recyclerView.setHasFixedSize(true);
        recyclerView.setNestedScrollingEnabled(false);
        mAdapter = new AdapterMyorders(mContext, allOrders,"cancel");
        recyclerView.setAdapter(mAdapter);
*/

        return root;
    }
    private Context mContext;
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mContext=context;
    }
}