package com.m4ub2b.iezant.simpleclasses;

import com.m4ub2b.iezant.notification.MyResponse;
import com.m4ub2b.iezant.notification.Sender;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface APIService {
    @Headers(
            {
                    "Content-type:application/json",
                    "Authorization:key=AAAAfploW5w:APA91bEZgKprzQRTIdzE0CazOvBfQqcrouIxNPrTAnff3QyxV5GbdFzeNavOY0G9T3PJ37ZMN60pPtkjccMJ-qZ0rEEAZaP1pYePWPzjhK0RVEDr3HulmquB5pUEhnsxRAO3GQ8m-Kv0"
            }
    )
    @POST("fcm/send")
    Call<MyResponse> sendNotification(@Body Sender body);
}
