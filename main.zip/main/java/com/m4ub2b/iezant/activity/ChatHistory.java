package com.m4ub2b.iezant.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.m4ub2b.iezant.Chat.ChatList;
import com.m4ub2b.iezant.Chat.HistoryAdapter;
import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.model.User;
import com.m4ub2b.iezant.simpleclasses.SharedPrefManager;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ChatHistory extends AppCompatActivity {

    private RecyclerView recyclerView;
    private HistoryAdapter mAdapter;
    TextView name;
    private List<User> mUsers;
    private  List<ChatList> chatLists;

    String user_id,msgCount;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_history);

        initToolbar();
        initComponent();

    }

    private void initToolbar() {
        androidx.appcompat.widget.Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_chevron_left);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Order History");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }


    private void initComponent() {

        if(SharedPrefManager.getInstance(getApplicationContext()).isLoggedIn()){

            User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();
            user_id=user.getId();
        }

        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));

        recyclerView.setHasFixedSize(true);
        recyclerView.setNestedScrollingEnabled(false);

        //set data and list adapter
        setAdapter();

    }

    private void setAdapter() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();
        chatLists=new ArrayList<>();

        reference= FirebaseDatabase.getInstance().getReference("Chatlist").child(user_id);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
               chatLists.clear();
                for(DataSnapshot dataSnapshot:snapshot.getChildren()){
                    ChatList chat=dataSnapshot.getValue(ChatList.class);
                    chatLists.add(chat);
                    mAdapter=new HistoryAdapter(chatLists,ChatHistory.this,true);
                    recyclerView.setAdapter(mAdapter);
                    progressDialog.dismiss();
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressDialog.dismiss();
            }
        });
        
    }



    /*private void chatList() {
        mUsers=new ArrayList<>();
        reference=FirebaseDatabase.getInstance().getReference("ChatList");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                mUsers.clear();
                for(DataSnapshot dataSnapshot:snapshot.getChildren()){
                    User user=dataSnapshot.getValue(User.class);
                    for(ChatList chatlist:chatLists){
                        if(user.getId().equals(chatlist.getId())){
                            mUsers.add(user);
                        }
                    }

                }
                mAdapter=new HistoryAdapter(mUsers,getApplicationContext(),true);
                recyclerView.setAdapter(mAdapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }*/

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.search_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        } else {
            Toast.makeText(getApplicationContext(), item.getTitle(), Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }
    private   void userStatus(String status)
    {
        DatabaseReference databaseReference=FirebaseDatabase.getInstance().getReference("Users").child(user_id);
        HashMap<String, Object> hashMap=new HashMap<>();
        hashMap.put("status",status);
        databaseReference.updateChildren(hashMap);

    }

    @Override
    protected void onResume() {
        super.onResume();
        userStatus("Online");
    }


    @Override
    protected void onPause() {
        super.onPause();
        userStatus("Offline");
    }

}