package com.m4ub2b.iezant.model;

public class Orders {
    private boolean apistatus;
    private Order[] orders;

    private Order order;

    public boolean isApistatus() {
        return apistatus;
    }

    public Order getOrder() {
        return order;
    }

    public Order[] getOreders() {
        return orders;
    }
}

