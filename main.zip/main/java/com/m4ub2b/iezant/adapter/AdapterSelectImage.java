package com.m4ub2b.iezant.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.m4ub2b.iezant.R;

import java.util.List;

public class AdapterSelectImage extends RecyclerView.Adapter<AdapterSelectImage.ViewHolder> {
    private List<Bitmap> bitmapList;
    private Context context;

    public AdapterSelectImage(Context context, List<Bitmap> bitmapList) {
        this.bitmapList=bitmapList;
        this.context=context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        AdapterSelectImage.ViewHolder viewHolder;
             LayoutInflater layoutInflater=LayoutInflater.from(parent.getContext());
            View listItem=layoutInflater.inflate(R.layout.item_seller_post,parent,false);
            viewHolder=new AdapterSelectImage.ViewHolder(listItem);


        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Bitmap bitmap=bitmapList.get(position);
        holder.image.setImageBitmap(bitmap);
      /*  holder.bt_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bitmapList.remove(position);
                notifyItemRemoved(position);
                notifyItemRangeChanged(position, bitmapList.size());
            }
        });
*/
    }

    @Override
    public int getItemCount() {
        return bitmapList.size();
    }


    public  static  class ViewHolder extends RecyclerView.ViewHolder{

         ImageView image;
         ImageButton bt_close;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            image=(ImageView) itemView.findViewById(R.id.images);
            bt_close=(ImageButton) itemView.findViewById(R.id.bt_close);

        }
    }


}
