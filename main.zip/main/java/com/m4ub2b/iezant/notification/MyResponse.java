package com.m4ub2b.iezant.notification;

public class MyResponse {
    private int success;

    public MyResponse(int success) {
        this.success = success;
    }

    public int getSuccess() {
        return success;
    }

    public void setSuccess(int success) {
        this.success = success;
    }
}
