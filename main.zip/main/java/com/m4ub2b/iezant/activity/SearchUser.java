package com.m4ub2b.iezant.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import com.bumptech.glide.Glide;
import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.model.User;
import com.m4ub2b.iezant.simpleclasses.RetrofitClient;
import com.m4ub2b.iezant.simpleclasses.SharedPrefManager;
import com.m4ub2b.iezant.simpleclasses.URLs;
import com.m4ub2b.iezant.utils.Tools;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SearchUser extends AppCompatActivity {

    private TextView name,email,mobile,address,pay_now;
    private CardView cardView;
    private CircleImageView image;
    private EditText search_box;
    private Button btn_search;
    String search_box_,send_to,wallet,uname,user_id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_user);
        initToolbar();
        initComponent();
    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(null);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Tools.setSystemBarColor(this, android.R.color.white);
        Tools.setSystemBarLight(this);
    }
    private void initComponent() {
        if(SharedPrefManager.getInstance(getApplicationContext()).isLoggedIn()){
            User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();
            user_id=user.getId();
        }
        search_box=findViewById(R.id.search_box);
        btn_search=findViewById(R.id.btn_search);
        name=findViewById(R.id.name);
        image=findViewById(R.id.image);
        email=findViewById(R.id.email);
        mobile=findViewById(R.id.mobile);
        address=findViewById(R.id.address);
        pay_now=findViewById(R.id.btn_pay);
        cardView=findViewById(R.id.card_view);
        wallet=getIntent().getExtras().getString("wallet");
        btn_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkUser();
            }
        });

    }

    private void checkUser() {
        search_box_ = search_box.getText().toString();
        if (TextUtils.isEmpty(search_box_)) {
            search_box.setError("Please enter");
            search_box.requestFocus();
            return;
        }
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();
        Call<User> call = RetrofitClient.getInstance().getApi().searchuser(user_id,search_box_);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                progressDialog.dismiss();
                User user= response.body();
                if(user.isStatus()) {
                    cardView.setVisibility(View.VISIBLE);
                    Toast.makeText(SearchUser.this, "Successfull", Toast.LENGTH_SHORT).show();
                    name.setText(user.getName());
                    send_to=user.getId();
                    uname=user.getName();
                    email.setText(user.getEmail());
                    mobile.setText("+91-"+user.getMobile());
                    address.setText(user.getAddress());
                    Glide.with(getApplicationContext()).load(URLs.IMAGE_URL+user.getImage()).into(image);
                    View view = getCurrentFocus();
                    InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                    pay_now.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent=new Intent(SearchUser.this, SendMoney.class);
                            intent.putExtra("wallet",wallet);
                            intent.putExtra("send_to",send_to);
                            intent.putExtra("uname",uname);
                            startActivity(intent);
                            finish();
                        }
                    });
                }
                else {
                    cardView.setVisibility(View.GONE);
                    View view = getCurrentFocus();
                    InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                    Toast.makeText(SearchUser.this, "No user found", Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onFailure(Call<User> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });


    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        } else {
            Toast.makeText(getApplicationContext(), item.getTitle(), Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }
}