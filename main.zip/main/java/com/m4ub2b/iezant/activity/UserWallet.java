package com.m4ub2b.iezant.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.adapter.AdapterWalletHistory;
import com.m4ub2b.iezant.model.User;
import com.m4ub2b.iezant.model.Wallet;
import com.m4ub2b.iezant.model.WalletBalance;
import com.m4ub2b.iezant.model.WalletHistory;
import com.m4ub2b.iezant.simpleclasses.RetrofitClient;
import com.m4ub2b.iezant.simpleclasses.SharedPrefManager;
import com.m4ub2b.iezant.utils.Tools;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UserWallet extends AppCompatActivity {

    private String user_id,wallet;
    private TextView wallet_balance;
    private CardView add_balance,send_money;
    int page_no=0,page_size=10;
    LinearLayoutManager layoutManager;
    private boolean isLoading=true;
    private int pastVisibleItems,visibleItemCount,totalItemCount,previous_total=0;
    private int viewThreshHold=0;
    ProgressDialog progressDialog;
    private RecyclerView recyclerView;
    private AdapterWalletHistory mAdapter;
    List<Wallet> walletList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_wallet);
        initToolbar();
        initComponent();

    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(null);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Tools.setSystemBarColor(this, android.R.color.white);
        Tools.setSystemBarLight(this);
    }

    private void initComponent() {
        add_balance=findViewById(R.id.add_balance);
        wallet_balance=findViewById(R.id.wallet_balance);
        send_money=findViewById(R.id.send_money);

        recyclerView = (RecyclerView) findViewById(R.id.wallet_history);
        layoutManager=new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.setNestedScrollingEnabled(false);

        if(SharedPrefManager.getInstance(getApplicationContext()).isLoggedIn()){
            User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();
            user_id=user.getId();
        }
        getBalance();
        add_balance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(UserWallet.this, AddWallet.class);
                intent.putExtra("wallet",wallet);
                startActivity(intent);
            }
        });
        send_money.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(UserWallet.this, SearchUser.class);
                intent.putExtra("wallet",wallet);
                startActivity(intent);
            }
        });
        setPosts();

    }
    private void getBalance() {

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();

        Call<WalletBalance> call = RetrofitClient.getInstance().getApi().walletbalance(user_id);
        call.enqueue(new Callback<WalletBalance>() {
            @Override
            public void onResponse(Call<WalletBalance> call, Response<WalletBalance> response) {
                 progressDialog.dismiss();

                //Toast.makeText(getApplicationContext(), response.body().getUser_id(), Toast.LENGTH_LONG).show();
                if (response.body().isStatus()) {
                    wallet="₹ "+response.body().getWallet_balance()+".0";
                    wallet_balance.setText("₹ "+response.body().getWallet_balance()+".0");
                }
                else{
                    wallet="₹ 0";
                   wallet_balance.setText("₹ 0");
                }
            }

            @Override
            public void onFailure(Call<WalletBalance> call, Throwable t) {
                  progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

    }
    private void setPosts() {
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();
        Call<WalletHistory> call = RetrofitClient.getInstance().getApi().wallethistorybyuser(user_id,page_no,page_size);
        call.enqueue(new Callback<WalletHistory>() {
            @Override
            public void onResponse(Call<WalletHistory> call, Response<WalletHistory> response) {
                progressDialog.dismiss();
                WalletHistory userDataResponse= response.body();

                if(userDataResponse.isApistatus()){
                    List<Wallet> walletList=new ArrayList<>(Arrays.asList(userDataResponse.getWallets()));
                    mAdapter = new AdapterWalletHistory(UserWallet.this, walletList);
                    recyclerView.setAdapter(mAdapter);
                }
                else {
                    Toast.makeText(UserWallet.this, "No History", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<WalletHistory> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                visibleItemCount=layoutManager.getChildCount();
                totalItemCount=layoutManager.getItemCount();
                pastVisibleItems=layoutManager.findFirstVisibleItemPosition();
                if(dy>0){
                    if(isLoading){
                        if(totalItemCount>previous_total){
                            isLoading=false;
                            previous_total=totalItemCount;
                        }
                    }
                    if(!isLoading&&(totalItemCount-visibleItemCount)<=(pastVisibleItems+viewThreshHold)){
                        page_no++;
                        performPagination();
                        isLoading=true;
                    }
                }
            }
        });
    }

    private void performPagination() {

        progressDialog.show();
        Call<WalletHistory> call = RetrofitClient.getInstance().getApi().wallethistorybyuser(user_id,page_no,page_size);
        call.enqueue(new Callback<WalletHistory>() {
            @Override
            public void onResponse(Call<WalletHistory> call, Response<WalletHistory> response) {
                progressDialog.dismiss();
                WalletHistory userDataResponse= response.body();

                if(userDataResponse.isApistatus()){
                    List<Wallet> walletList=new ArrayList<>(Arrays.asList(userDataResponse.getWallets()));
                    mAdapter.addCustomer(walletList);
                }
                else {
                    Toast.makeText(UserWallet.this, "No More History", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<WalletHistory> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        } else {
            Toast.makeText(getApplicationContext(), item.getTitle(), Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }
}