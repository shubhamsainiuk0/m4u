package com.m4ub2b.iezant.account;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Base64;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.m4ub2b.iezant.MainActivity;
import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.model.CategoryList;
import com.m4ub2b.iezant.model.User;
import com.m4ub2b.iezant.simpleclasses.RetrofitClient;
import com.m4ub2b.iezant.simpleclasses.SharedPrefManager;
import com.m4ub2b.iezant.simpleclasses.URLs;
import com.m4ub2b.iezant.utils.Tools;
import com.mikhaellopez.circularimageview.CircularImageView;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProfileActivity extends AppCompatActivity {


    Button btn_submit;
    TextView name,email,address,add_bank_details,mobile,gstin,business_name,business_description,about,change_location,logout,set_category,change_category;
    CircularImageView image;
    ImageView imagebg;
    String user_id,category_idd,category_name;
    List<CategoryList> categoryLists;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        initToolbar();
        initComponent();
        setCategory();

    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_chevron_left_white);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Settings");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Tools.setSystemBarColor(this, R.color.blue_600);
    }

    private void initComponent() {

        name = findViewById(R.id.name);
        email = findViewById(R.id.email);
        change_location = findViewById(R.id.change_location);
        logout = findViewById(R.id.logout);
        address = findViewById(R.id.address);
        business_name = findViewById(R.id.businessName);
        business_description = findViewById(R.id.businessDescription);
        about = findViewById(R.id.aboutUs);
        gstin = findViewById(R.id.gstinNumber);
        mobile = findViewById(R.id.mobile);
        image = findViewById(R.id.image);
        imagebg = findViewById(R.id.imagebg);
        add_bank_details = findViewById(R.id.add_bank_details);
        change_category = findViewById(R.id.change_category);
        set_category = findViewById(R.id.set_category);


        if (SharedPrefManager.getInstance(getApplicationContext()).isLoggedIn()) {

            User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();
            name.setText(user.getName());
            email.setText(user.getEmail());
            address.setText(user.getAddress());
            business_name.setText(user.getBusinessName());
            business_description.setText(user.getBusiness_description());
            about.setText(user.getAbout());
            gstin.setText(user.getGstin());
            mobile.setText(user.getMobile());
            user_id = user.getId();
            category_idd = user.getCategory_id();

            Picasso.get().load(URLs.IMAGE_URL + user.getImage()).into(image);
            Picasso.get().load(URLs.IMAGE_URL + user.getImagebg()).into(imagebg);

            change_location.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(ProfileActivity.this,AddLocation.class));
                }
            });
            change_category.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showCategoryDialog(v);
                }
            });
            add_bank_details.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(ProfileActivity.this, AddBankDeatils.class);
                    startActivity(intent);
                }
            });
            logout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(SharedPrefManager.getInstance(getApplicationContext()).isLoggedIn()){
                        SharedPrefManager.getInstance(getApplicationContext()).logout();
                        Intent intent = new Intent(ProfileActivity.this, LoginActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }
            });

        }


    }
    private void setCategory() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();

        Call<List<CategoryList>> call = RetrofitClient.getInstance().getApi().getCategory();
        call.enqueue(new Callback<List<CategoryList>>() {
            @Override
            public void onResponse(Call<List<CategoryList>> call, Response<List<CategoryList>> response) {
                progressDialog.dismiss();
                categoryLists=response.body();
                String id;
                for (int i = 0; i < categoryLists.size(); i++) {
                    //category_name = categoryLists.get(i).getCat_name();
                    id = categoryLists.get(i).getId();
                    if(id.equals(category_idd)){
                        set_category.setText(categoryLists.get(i).getCat_name());
                    }
                }
            }

            @Override
            public void onFailure(Call<List<CategoryList>> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
    private void showCategoryDialog(final View v) {
        String[] array = new String[categoryLists.size()];
        String[] arrayId = new String[categoryLists.size()];
        for (int i = 0; i < categoryLists.size(); i++) {
            array[i] = categoryLists.get(i).getCat_name();
            arrayId[i] = categoryLists.get(i).getId();
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select Category");
        builder.setSingleChoiceItems(array, -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
               // ((EditText) v).setText(array[i]);
                category_idd=arrayId[i];
                set_category.setText(array[i]);
                dialogInterface.dismiss();
                updateCategory(category_idd);
            }
        });
        builder.show();
    }
    private void updateCategory(String cat_id) {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();

        Call<User> call = RetrofitClient.getInstance().getApi().updatecategory(URLs.TOKEN,user_id,cat_id);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                progressDialog.dismiss();

                Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                if (response.body().isStatus()) {

                    SharedPrefManager.getInstance(getApplicationContext()).userLogin(response.body());
                    category_idd=response.body().getCategory_id();
                    setCategory();
                }
                else{
                    Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                }


            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.profile_menu_edit, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        } else {
            startActivity(new Intent(ProfileActivity.this,UpdateProfileActivity.class));
        }
        return super.onOptionsItemSelected(item);
    }
}