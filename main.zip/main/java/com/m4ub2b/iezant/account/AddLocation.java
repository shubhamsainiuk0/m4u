package com.m4ub2b.iezant.account;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.delivery.EasyShipping;
import com.m4ub2b.iezant.model.ApiResponse;
import com.m4ub2b.iezant.model.User;
import com.m4ub2b.iezant.simpleclasses.LocationPicker;
import com.m4ub2b.iezant.simpleclasses.MapUtilityy;
import com.m4ub2b.iezant.simpleclasses.RetrofitClient;
import com.m4ub2b.iezant.simpleclasses.SharedPrefManager;
import com.m4ub2b.iezant.utils.Tools;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.shivtechs.maplocationpicker.LocationPickerActivity;
import com.shivtechs.maplocationpicker.MapUtility;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddLocation extends FragmentActivity {

    private String user_id,email;
    private GoogleMap mMap;
    MarkerOptions markerOptions;
    Double latitudeTextView, longitTextView;
    int PERMISSION_ID = 44;
    CardView cardView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_location);
        MapUtilityy.apiKey = getResources().getString(R.string.google_maps_key);

        if (SharedPrefManager.getInstance(AddLocation.this).isLoggedIn()) {
            User customer = SharedPrefManager.getInstance(getApplicationContext()).getUser();
            user_id=customer.getId();
            email=customer.getEmail();
        }
        initComponent();
        userdata();

    }

    private void initComponent() {
        cardView=findViewById(R.id.cardView);
        cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AddLocation.this, LocationPicker.class);
                startActivityForResult(intent, PERMISSION_ID);
            }
        });
    }

    private void userdata() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();
        Call<User> call = RetrofitClient.getInstance().getApi().userbyid(user_id);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                progressDialog.dismiss();
                User user= response.body();
                if(user.getLatitude()==null){
                    latitudeTextView=28.527582;
                    longitTextView=77.0688975;
                }
                else{
                    latitudeTextView=user.getLatitude();
                    longitTextView=user.getLongitude();}
                initMapFragment();
            }
            @Override
            public void onFailure(Call<User> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
    private void initMapFragment() {
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(new OnMapReadyCallback() {
            @Override
            public void onMapReady(GoogleMap googleMap) {
                mMap = Tools.configActivityMaps(googleMap);
                markerOptions = new MarkerOptions().position(new LatLng(latitudeTextView, longitTextView));
                mMap.addMarker(markerOptions);
                mMap.moveCamera(zoomingLocation());
            }
        });
    }
    private void updateLocation() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();
        Call<ApiResponse> call = RetrofitClient.getInstance().getApi().cordinates(user_id,email,latitudeTextView,longitTextView);
        call.enqueue(new Callback<ApiResponse>() {
            @Override
            public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                finish();
            }
            @Override
            public void onFailure(Call<ApiResponse> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PERMISSION_ID) {
            try {
                if (data != null && data.getStringExtra(MapUtility.ADDRESS) != null) {

                    double currentLatitude = data.getDoubleExtra(MapUtility.LATITUDE, 0.0);
                    double currentLongitude = data.getDoubleExtra(MapUtility.LONGITUDE, 0.0);

                    latitudeTextView=currentLatitude;
                    longitTextView=currentLongitude;
                    updateLocation();
                    initMapFragment();

                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    private CameraUpdate zoomingLocation() {
        return CameraUpdateFactory.newLatLngZoom(new LatLng(latitudeTextView, longitTextView), 15);
    }


}