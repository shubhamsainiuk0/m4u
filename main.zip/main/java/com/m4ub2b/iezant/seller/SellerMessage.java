package com.m4ub2b.iezant.seller;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.m4ub2b.iezant.Chat.ChatModel;
import com.m4ub2b.iezant.Chat.MessageAdapter;
import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.activity.CustomerDetails;
import com.m4ub2b.iezant.model.User;
import com.m4ub2b.iezant.notification.Client;
import com.m4ub2b.iezant.notification.Data;
import com.m4ub2b.iezant.notification.MyResponse;
import com.m4ub2b.iezant.notification.Sender;
import com.m4ub2b.iezant.notification.Token;
import com.m4ub2b.iezant.simpleclasses.APIService;
import com.m4ub2b.iezant.simpleclasses.SharedPrefManager;
import com.m4ub2b.iezant.simpleclasses.URLs;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SellerMessage extends AppCompatActivity {
    TextView userName,message_send,status;
    CircleImageView profileImage;
    ImageButton sendBtn,addMedia;
    //Intent intent;

    MessageAdapter messageAdapter;
    List<ChatModel> chatList;
    RecyclerView recyclerView;
    ProgressDialog loadingbar;

    //FirebaseUser firebaseUser;
    String user_id,receiver_id,uname,imagee,sendername,senderimage;
    private String checker="",myUrl="";
    String messagePushIDCamera="";

    private Uri fileUri;
    private StorageTask storageTask;


    DatabaseReference databaseReference;
    APIService apiService;

    boolean notify=false;
    private String saveCurrentTime, saveCurrentDate;

    ValueEventListener valueEventListener;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);
        initToolbar();
        initComponent();
    }

    private void initToolbar() {
        androidx.appcompat.widget.Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_chevron_left);

        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }
    private void initComponent() {
        userName=findViewById(R.id.m_userName);
        status=findViewById(R.id.status);
        profileImage=findViewById(R.id.m_profileImage);
        message_send=findViewById(R.id.message);
        sendBtn=findViewById(R.id.send);
        addMedia=findViewById(R.id.addMedia);
        loadingbar= new ProgressDialog(this);

        SimpleDateFormat currentDate = new SimpleDateFormat("MMM dd, yyyy");

        Calendar calendar = Calendar.getInstance();
        saveCurrentDate = currentDate.format(calendar.getTime());

        SimpleDateFormat currentTime = new SimpleDateFormat("hh:mm a");
        saveCurrentTime = currentTime.format(calendar.getTime());
        imagee=getIntent().getExtras().getString("image");
        uname=getIntent().getExtras().getString("namee");
        Glide.with(getApplicationContext()).load(URLs.IMAGE_URL+imagee).into(profileImage);

        if(SharedPrefManager.getInstance(getApplicationContext()).isLoggedIn()){

            User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();
            user_id=user.getId();
            sendername=user.getName();
            senderimage=user.getImage();
        }

        setAdapter();
    }

    private void setAdapter() {
        apiService= Client.getClient("https://fcm.googleapis.com/").create(APIService.class);
        recyclerView=findViewById(R.id.rv_messageList);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(getApplicationContext());
        linearLayoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(linearLayoutManager);


        receiver_id=getIntent().getExtras().getString("uid");
        userName.setText(uname);
        databaseReference= FirebaseDatabase.getInstance().getReference("SellerUsers").child(receiver_id);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                status.setText( snapshot.child("status").getValue(String.class));
                Log.d("userstatus",snapshot.child("status").getValue(String.class));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error){
            }
        });



        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                notify=true;
                String msg=message_send.getText().toString().trim();
                if(!msg.equals("")){
                    sendMessage(user_id,receiver_id,msg);
                }else {
                    Toast.makeText(SellerMessage.this,"Please type a message",Toast.LENGTH_SHORT).show();

                }message_send.setText("");
            }
        });
        addMedia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CharSequence options[]=new CharSequence[]{
                        "Camera",
                        "Images",
                        "Pdf Files",
                        "Ms Words Files"
                };
                AlertDialog.Builder builder=new AlertDialog.Builder(SellerMessage.this);
                builder.setTitle("Select Category");
                builder.setItems(options, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if(which==0){
                            checker="camera";
                            Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                            startActivityForResult(cameraIntent, 438);
                        }
                        if(which==1){
                            checker="image";
                            Intent intent=new Intent();
                            intent.setAction(Intent.ACTION_GET_CONTENT);
                            intent.setType("image/*");
                            startActivityForResult(intent.createChooser(intent,"Select Image"),438);
                        }
                        if(which==2){
                            checker="pdf";
                            Intent intent=new Intent();
                            intent.setAction(Intent.ACTION_GET_CONTENT);
                            intent.setType("application/pdf");
                            startActivityForResult(intent.createChooser(intent,"Select Pdf File"),438);
                        }
                        if(which==3){
                            checker="docx";
                            Intent intent=new Intent();
                            intent.setAction(Intent.ACTION_GET_CONTENT);
                            intent.setType("application/msword");
                            startActivityForResult(intent.createChooser(intent,"Select MS Word File"),438);
                        }
                    }
                });
                builder.show();

            }
        });

        // databaseReference= FirebaseDatabase.getInstance().getReference("Users").child(receiver_id);
        readMessage(user_id,receiver_id);
    }


    private void readMessage(String user_id, String receiver_id) {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();
        chatList=new ArrayList<>();
        databaseReference=FirebaseDatabase.getInstance().getReference("SellerChats");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                chatList.clear();
                for(DataSnapshot dataSnapshot:snapshot.getChildren()){
                    ChatModel chat=dataSnapshot.getValue(ChatModel.class);
                    if(chat.getReceiver().equals(user_id)&&chat.getSender().equals(receiver_id)||
                            chat.getReceiver().equals(receiver_id)&&chat.getSender().equals(user_id)){
                        chatList.add(chat);
                    }
                    messageAdapter=new MessageAdapter(chatList,SellerMessage.this);
                    recyclerView.setAdapter(messageAdapter);
                    progressDialog.dismiss();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressDialog.dismiss();
            }
        });
        seenMessage(receiver_id);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(!checker.equals("camera")){
            if(requestCode==438 && resultCode==RESULT_OK && data!=null && data.getData()!=null){

                loadingbar.setTitle("Sending...");
                loadingbar.setCanceledOnTouchOutside(false);
                loadingbar.show();
                notify=true;
                fileUri=data.getData();

                if(checker.equals("docx")||checker.equals("pdf")){
                    StorageReference storageReference= FirebaseStorage.getInstance().getReference().child("Document Files");
                    DatabaseReference reference=FirebaseDatabase.getInstance().getReference().child("SellerChats").push();

                    final String messagePushID=reference.getKey();
                    StorageReference filePath=storageReference.child(messagePushID +"."+checker);

                    filePath.putFile(fileUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot task) {
                            final Task<Uri> firebaseUri = task.getStorage().getDownloadUrl();
                            firebaseUri.addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    HashMap<String,Object> hashMap=new HashMap<>();
                                    hashMap.put("type", checker);
                                    hashMap.put("sender",user_id);
                                    hashMap.put("receiver",receiver_id);
                                    hashMap.put("message",uri.toString());
                                    hashMap.put("messageID",messagePushID);
                                    hashMap.put("name",fileUri.getLastPathSegment());
                                    hashMap.put("time",saveCurrentTime);
                                    hashMap.put("date",saveCurrentDate);
                                    hashMap.put("isseen",false);

                                    reference.setValue(hashMap);
                                    final DatabaseReference sender1=FirebaseDatabase.getInstance().getReference("SellerChatlist").child(user_id)
                                            .child(receiver_id);
                                    sender1.addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot snapshot) {

                                            sender1.child("id").setValue(receiver_id);
                                            sender1.child("name").setValue(uname);
                                            sender1.child("image").setValue(imagee);

                                        }
                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) { }
                                    });
                                    final DatabaseReference receiver1=FirebaseDatabase.getInstance().getReference("SellerChatlist")
                                            .child(receiver_id)
                                            .child(user_id);
                                    receiver1.addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot snapshot) {

                                            receiver1.child("id").setValue(user_id);
                                            receiver1.child("name").setValue(sendername);
                                            receiver1.child("image").setValue(senderimage);

                                        }
                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) { }
                                    });
                                    final String message="Received a Document";
                                    if(notify){
                                        sendNotification(receiver_id,sendername,message,uname,senderimage);}
                                    notify=false;
                                    loadingbar.dismiss();
                                    Toast.makeText(SellerMessage.this, "File Sent Successfully", Toast.LENGTH_SHORT).show();
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    loadingbar.dismiss();
                                    Toast.makeText(SellerMessage.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            });

                        }
                    }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(@NonNull UploadTask.TaskSnapshot snapshot) {
                            double progress = (100.0 * snapshot.getBytesTransferred()) / snapshot.getTotalByteCount();
                            loadingbar.setMessage((int) progress + "% Uploading");
                        }
                    });

                }
                else if(checker.equals("image")){
                    StorageReference storageReference= FirebaseStorage.getInstance().getReference().child("Images");
                    DatabaseReference reference=FirebaseDatabase.getInstance().getReference().child("SellerChats").push();
                    final String messagePushID=reference.getKey();


                    StorageReference filePath=storageReference.child(messagePushID +"."+"jpg");
                    storageTask=filePath.putFile(fileUri);
                    storageTask.continueWithTask(new Continuation() {
                        @Override
                        public Object then(@NonNull Task task) throws Exception {
                            if(!task.isSuccessful()){
                                throw task.getException();
                            }
                            return filePath.getDownloadUrl();
                        }
                    }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                        @Override
                        public void onComplete(@NonNull Task<Uri> task) {
                            if(task.isSuccessful()){
                                Uri downloadUri=task.getResult();
                                myUrl=downloadUri.toString();
                                HashMap<String,Object> hashMap=new HashMap<>();
                                hashMap.put("type", checker);
                                hashMap.put("sender",user_id);
                                hashMap.put("receiver",receiver_id);
                                hashMap.put("message",myUrl);
                                hashMap.put("messageID",messagePushID);
                                hashMap.put("name",fileUri.getLastPathSegment());
                                hashMap.put("time",saveCurrentTime);
                                hashMap.put("date",saveCurrentDate);
                                hashMap.put("isseen",false);

                                reference.setValue(hashMap);

                                final DatabaseReference sender1=FirebaseDatabase.getInstance().getReference("SellerChatlist").child(user_id)
                                        .child(receiver_id);
                                sender1.addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                                        sender1.child("id").setValue(receiver_id);
                                        sender1.child("name").setValue(uname);
                                        sender1.child("image").setValue(imagee);

                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) { }
                                });
                                final DatabaseReference receiver1=FirebaseDatabase.getInstance().getReference("SellerChatlist")
                                        .child(receiver_id)
                                        .child(user_id);
                                receiver1.addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                                        receiver1.child("id").setValue(user_id);
                                        receiver1.child("name").setValue(sendername);
                                        receiver1.child("image").setValue(senderimage);

                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) { }
                                });
                                final String message="Received an Image";
                                if(notify){
                                    sendNotification(receiver_id,sendername,message,uname,senderimage);}
                                notify=false;
                                loadingbar.dismiss();
                                Toast.makeText(SellerMessage.this, "File Sent Successfully", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            loadingbar.dismiss();
                            Toast.makeText(SellerMessage.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        }
        else {
            if (requestCode == 438 && resultCode == RESULT_OK) {
                notify=true;
                loadingbar.setTitle("Sending...");
                loadingbar.setCanceledOnTouchOutside(false);
                loadingbar.show();
                Bitmap photo = (Bitmap) data.getExtras().get("data");

                //fileUri = data.getData();

                StorageReference storageReference = FirebaseStorage.getInstance().getReference().child("Images");
                DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("SellerChats").push();
                messagePushIDCamera = reference.getKey();


                StorageReference filePath = storageReference.child(messagePushIDCamera + "." + "jpg");
                storageTask = filePath.putFile(getImageUri(this,photo));
                storageTask.continueWithTask(new Continuation() {
                    @Override
                    public Object then(@NonNull Task task) throws Exception {
                        if (!task.isSuccessful()) {
                            throw task.getException();
                        }
                        return filePath.getDownloadUrl();
                    }
                }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                    @Override
                    public void onComplete(@NonNull Task<Uri> task) {
                        if (task.isSuccessful()) {
                            Uri downloadUri = task.getResult();
                            myUrl = downloadUri.toString();
                            HashMap<String, Object> hashMap = new HashMap<>();
                            hashMap.put("type", "image");
                            hashMap.put("sender", user_id);
                            hashMap.put("receiver", receiver_id);
                            hashMap.put("message", myUrl);
                            hashMap.put("messageID", messagePushIDCamera);
                            hashMap.put("name", messagePushIDCamera);
                            hashMap.put("time", saveCurrentTime);
                            hashMap.put("date", saveCurrentDate);
                            hashMap.put("isseen", false);

                            reference.setValue(hashMap);

                            final DatabaseReference sender1=FirebaseDatabase.getInstance().getReference("SellerChatlist").child(user_id)
                                    .child(receiver_id);
                            sender1.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {

                                    sender1.child("id").setValue(receiver_id);
                                    sender1.child("name").setValue(uname);
                                    sender1.child("image").setValue(imagee);

                                }
                                @Override
                                public void onCancelled(@NonNull DatabaseError error) { }
                            });
                            final DatabaseReference receiver1=FirebaseDatabase.getInstance().getReference("SellerChatlist")
                                    .child(receiver_id)
                                    .child(user_id);
                            receiver1.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {

                                    receiver1.child("id").setValue(user_id);
                                    receiver1.child("name").setValue(sendername);
                                    receiver1.child("image").setValue(senderimage);

                                }
                                @Override
                                public void onCancelled(@NonNull DatabaseError error) { }
                            });
                            final String message="Received an Image";
                            if(notify){
                                sendNotification(receiver_id,sendername,message,uname,imagee);}
                            notify=false;
                            loadingbar.dismiss();
                            Toast.makeText(SellerMessage.this, "File Sent Successfully", Toast.LENGTH_SHORT).show();
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        loadingbar.dismiss();
                        Toast.makeText(SellerMessage.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }

        }

    }

    private void sendMessage(String user_id, String receiver_id, String msg) {

        DatabaseReference reference=FirebaseDatabase.getInstance().getReference().child("SellerChats").push();
        final String messagePushID=reference.getKey();

        HashMap<String,Object> hashMap=new HashMap<>();
        hashMap.put("type", "text");
        hashMap.put("sender",user_id);
        hashMap.put("receiver",receiver_id);
        hashMap.put("message",msg);
        hashMap.put("messageID",messagePushID);
        hashMap.put("time",saveCurrentTime);
        hashMap.put("date",saveCurrentDate);
        hashMap.put("isseen",false);

        reference.setValue(hashMap);

        final DatabaseReference sender1=FirebaseDatabase.getInstance().getReference("SellerChatlist").child(user_id)
                .child(receiver_id);
        sender1.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                sender1.child("id").setValue(receiver_id);
                sender1.child("name").setValue(uname);
                sender1.child("image").setValue(imagee);

            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) { }
        });
        final DatabaseReference receiver1=FirebaseDatabase.getInstance().getReference("SellerChatlist")
                .child(receiver_id)
                .child(user_id);
        receiver1.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                receiver1.child("id").setValue(user_id);
                receiver1.child("name").setValue(sendername);
                receiver1.child("image").setValue(senderimage);

            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) { }
        });
        final String message=msg;
        if(notify){
            sendNotification(receiver_id,sendername,message,uname,senderimage);}
        notify=false;

    }

    private void sendNotification(String receiver_id, String sendername, String message,String uname,String imagee) {
        DatabaseReference tokens=FirebaseDatabase.getInstance().getReference("SellerTokens");
        Query query=tokens.orderByKey().equalTo(receiver_id);
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot dataSnapshot:snapshot.getChildren()){
                    Token token=dataSnapshot.getValue(Token.class);
                    Data data=new Data(user_id,R.drawable.badge_verified,message,sendername,receiver_id,uname,imagee);
                    Sender sender=new Sender(data,token.getToken());
                    Log.d("tokenn", String.valueOf(sender));
                    apiService.sendNotification(sender)
                            .enqueue(new Callback<MyResponse>() {
                                @Override
                                public void onResponse(Call<MyResponse> call, Response<MyResponse> response) {
                                    if(response.code()==200){
                                        if(response.body().getSuccess()==1){
                                            // Toast.makeText(MessageActivity.this, "success:"+response, Toast.LENGTH_LONG).show();
                                            //Log.d("token",token.getToken());
                                        }

                                    }
                                }

                                @Override
                                public void onFailure(Call<MyResponse> call, Throwable t) {

                                }
                            });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    private void seenMessage(final String userid){
        databaseReference=FirebaseDatabase.getInstance().getReference("SellerChats");
        valueEventListener=databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot dataSnapshot:snapshot.getChildren()){
                    ChatModel chat=dataSnapshot.getValue(ChatModel.class);
                    if(chat.getReceiver().equals(user_id) && chat.getSender().equals(userid)){
                        HashMap<String, Object> hashMap=new HashMap<>();
                        hashMap.put("isseen",true);
                        dataSnapshot.getRef().updateChildren(hashMap);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.profile_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        } else {
            Intent intent=new Intent(getApplicationContext(), CustomerDetails.class);
            String uid=getIntent().getExtras().getString("uid");
            intent.putExtra("uid",uid);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
    public Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 50, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, messagePushIDCamera, null);
        return Uri.parse(path);
    }

    private   void userStatus(String status)
    {
        databaseReference=FirebaseDatabase.getInstance().getReference("SellerUsers").child(user_id);
        HashMap<String, Object> hashMap=new HashMap<>();
        hashMap.put("status",status);
        databaseReference.updateChildren(hashMap);

    }

    @Override
    protected void onResume() {
        super.onResume();
        userStatus("Online");
    }


    @Override
    protected void onPause() {
        super.onPause();
        databaseReference.removeEventListener(valueEventListener);
        userStatus("Offline");
    }



}