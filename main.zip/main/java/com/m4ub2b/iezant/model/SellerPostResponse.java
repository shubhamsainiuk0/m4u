package com.m4ub2b.iezant.model;

public class SellerPostResponse {
    private String id,user_id,category_id,title,price,description,message,created_at,name,image;
    private String multimage;
    private boolean status,apistatus;

    public SellerPostResponse(String id, String user_id, String category_id,String title, String price, String description,String created_at, String message, String multimage, boolean status, boolean apistatus,String name, String image) {
        this.id = id;
        this.user_id=user_id;
        this.category_id=category_id;
        this.title = title;
        this.price = price;
        this.description = description;
        this.created_at = created_at;
        this.message = message;
        this.multimage = multimage;
        this.status = status;
        this.apistatus = apistatus;
        this.name=name;
        this.image=image;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getCategory_id() {
        return category_id;
    }

    public void setCategory_id(String category_id) {
        this.category_id = category_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public String getMultimage() {
        return multimage;
    }

    public void setMultimage(String multimage) {
        this.multimage = multimage;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public boolean isApistatus() {
        return apistatus;
    }

    public void setApistatus(boolean apistatus) {
        this.apistatus = apistatus;
    }
}
