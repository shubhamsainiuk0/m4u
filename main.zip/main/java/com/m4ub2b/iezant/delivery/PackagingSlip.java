package com.m4ub2b.iezant.delivery;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.model.Order;
import com.m4ub2b.iezant.model.Orders;
import com.m4ub2b.iezant.simpleclasses.RetrofitClient;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

public class PackagingSlip extends AppCompatActivity {

    TextView sender_name,sender_mobile,sender_address,receiver_name,receiver_mobile,receiver_alternate_mobile,receiver_address,order_id,
            ddate,order_status,delivery_charge,weight;
    private ImageButton btn;
    private LinearLayout llPdf;
    private Bitmap bitmap;
    String order_status_,order_id_,area_manager_id;
    Order order;
    List<Order> allOrderList;
    private static final int PERMISSION_REQUEST_CODE = 200;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_packaging_slip);

        //initToolbar();
        initComponent();

    }
    private void initComponent() {
        btn=findViewById(R.id.bt_savepdf);
        llPdf=findViewById(R.id.llPdf);
        if (checkPermission()) {
        } else {
            requestPermission();
        }

        order_id=findViewById(R.id.order_id);
        delivery_charge=findViewById(R.id.delivery_charge);
        weight=findViewById(R.id.weight);
        ddate=findViewById(R.id.ddate);
        order_status=findViewById(R.id.order_status);
        sender_name=findViewById(R.id.sender_name);
        sender_mobile=findViewById(R.id.sende_mobile);
        sender_address=findViewById(R.id.sender_address);
        receiver_name=findViewById(R.id.receiver_name);
        receiver_mobile=findViewById(R.id.receiver_mobile);
        receiver_alternate_mobile=findViewById(R.id.receiver_alternate_mobile);
        receiver_address=findViewById(R.id.receiver_address);

        order_id_=getIntent().getExtras().getString("order_id");

        getorderDetails();

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bitmap = loadBitmapFromView(llPdf, llPdf.getWidth(), llPdf.getHeight());
                createPdf();
            }
        });


    }
    private void getorderDetails() {
        final ProgressDialog progressDialog = new ProgressDialog(PackagingSlip.this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();
        Call<Orders> call = RetrofitClient.getInstance().getApi().orderbyid(order_id_);
        call.enqueue(new Callback<Orders>() {
            @Override
            public void onResponse(Call<Orders> call, Response<Orders> response) {
                progressDialog.dismiss();

                Orders userDataResponse= response.body();

                if(userDataResponse.isApistatus()){
                    allOrderList=new ArrayList<>(Arrays.asList(userDataResponse.getOreders()));
                    Order order=allOrderList.get(0);
                   setData(order);
                }
                else {
                    Toast.makeText(PackagingSlip.this, "No order", Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(Call<Orders> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();


            }
        });

    }

    private void setData(Order order) {
        order_status_= order.getOrder_status();
        area_manager_id= order.getArea_manager_id();
        order_id.setText("Order ID #"+order_id_);
        ddate.setText("Order Date : "+order.getCreated_at());

        weight.setText(""+order.getWeight()+"kg");
        //delivery_charge.setText(""+order.getDelivery_charge());

        sender_name.setText("Name : "+order.getSender_name());
        sender_mobile.setText("Mobile : +91-"+order.getSender_mobile());
        sender_address.setText("Address : "+order.getSender_address());

        receiver_name.setText("Name : "+order.getReceiver_name());
        receiver_mobile.setText("Mobile : +91- "+order.getReceiver_mobile());
        receiver_alternate_mobile.setText("Alternate Num : +91- "+order.getReceiver_alternate_mobile());
        receiver_address.setText("Address : "+order.getReceiver_address());

    }

    public static Bitmap loadBitmapFromView(View v, int width, int height) {
        Bitmap b = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        v.draw(c);
        return b;
    }
    private void createPdf(){
        WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        //  Display display = wm.getDefaultDisplay();
        DisplayMetrics displaymetrics = new DisplayMetrics();
        this.getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
        float hight = displaymetrics.heightPixels ;
        float width = displaymetrics.widthPixels ;

        int convertHighet = (int) hight, convertWidth = (int) width;

        PdfDocument document = new PdfDocument();
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(convertWidth, convertHighet, 1).create();
        PdfDocument.Page page = document.startPage(pageInfo);

        Canvas canvas = page.getCanvas();

        Paint paint = new Paint();
        canvas.drawPaint(paint);

        bitmap = Bitmap.createScaledBitmap(bitmap, convertWidth, convertHighet, true);

        paint.setColor(Color.BLUE);
        canvas.drawBitmap(bitmap, 0, 0 , null);
        document.finishPage(page);

        // write the document content
        String targetPdf = "/sdcard/order_"+order_id_+".pdf";
        File filePath;
        filePath = new File(targetPdf);
        try {
            document.writeTo(new FileOutputStream(filePath));

        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Something wrong: " + e.toString(), Toast.LENGTH_LONG).show();
        }
        // close the document
        document.close();
        Toast.makeText(this, "PDF Downloaded check in sdcard/m4ub2b/packagingslip.pdf", Toast.LENGTH_SHORT).show();

       // openGeneratedPDF();
    }
    private void openGeneratedPDF(){
        File file = new File("/sdcard/m4ub2b/packagingslip.pdf");
        if (file.exists())
        {
            Intent intent=new Intent(Intent.ACTION_VIEW);
            Uri uri = Uri.fromFile(file);
            intent.setDataAndType(uri, "application/pdf");
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

            try
            {
                startActivity(intent);
            }
            catch(ActivityNotFoundException e)
            {
                Toast.makeText(PackagingSlip.this, "No Application available to view pdf", Toast.LENGTH_LONG).show();
            }
        }
    }
    private boolean checkPermission() {
        // checking of permissions.
        int permission1 = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);
        int permission2 = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);
        return permission1 == PackageManager.PERMISSION_GRANTED && permission2 == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermission() {
        // requesting permissions if not provided.
        ActivityCompat.requestPermissions(this, new String[]{WRITE_EXTERNAL_STORAGE, READ_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0) {

                // after requesting permissions we are showing
                // users a toast message of permission granted.
                boolean writeStorage = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                boolean readStorage = grantResults[1] == PackageManager.PERMISSION_GRANTED;

                if (writeStorage && readStorage) {
                    Toast.makeText(this, "Permission Granted..", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Permission Denined.", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        }
    }
}