package com.m4ub2b.iezant.ui.newpost;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.m4ub2b.iezant.MainActivity;
import com.m4ub2b.iezant.R;
import com.m4ub2b.iezant.adapter.AdapterSelectImage;
import com.m4ub2b.iezant.adapter.RecyclerTouchListener;
import com.m4ub2b.iezant.model.SellerPostResponse;
import com.m4ub2b.iezant.model.User;
import com.m4ub2b.iezant.simpleclasses.RetrofitClient;
import com.m4ub2b.iezant.simpleclasses.SharedPrefManager;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.app.Activity.RESULT_OK;

public class FragmentNewPost extends Fragment {

    private View root;
    private Toolbar toolbar;
    private RecyclerView recyclerView;
    private AdapterSelectImage mAdapter;
    List<String> imagesList;
    List<Bitmap> bitmaps;
    EditText titleName,price,description;
    Button bt_save;
    ImageView addimages;
    final int REQUEST_EXTERNAL_STORAGE = 100;
    private String user_id,category_id;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
         root = inflater.inflate(R.layout.fragment_new_post, container, false);

        initToolbar();
        initComponent();

        setHasOptionsMenu(true);
        return root;
    }
    private void initToolbar() {
        toolbar = (Toolbar) root.findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_chevron_left);
       // nav_view = (NavigationView) root.findViewById(R.id.nav_view);
        //drawer = (DrawerLayout) root.findViewById(R.id.drawer_layout);
        ((AppCompatActivity)getActivity()).setSupportActionBar(toolbar);
        ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("New Post");
        ((AppCompatActivity)getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    private void initComponent() {
        if(SharedPrefManager.getInstance(mContext).isLoggedIn()){

            User user = SharedPrefManager.getInstance(mContext).getUser();
            user_id=user.getId();
        }

        recyclerView = (RecyclerView) root.findViewById(R.id.recyclerView);
        titleName=root.findViewById(R.id.titleName);
        price=root.findViewById(R.id.price);
        description=root.findViewById(R.id.description);
        bt_save=root.findViewById(R.id.btn_save);
        if(SharedPrefManager.getInstance(mContext.getApplicationContext()).isLoggedIn()){

            User user = SharedPrefManager.getInstance(mContext.getApplicationContext()).getUser();
            user_id=user.getId();
            category_id=user.getCategory_id();
        }

        recyclerView.setLayoutManager(new LinearLayoutManager(mContext.getApplicationContext(),LinearLayoutManager.HORIZONTAL,false));

        recyclerView.setHasFixedSize(true);
        recyclerView.setNestedScrollingEnabled(false);
        bitmaps = new ArrayList<>();
        imagesList = new ArrayList<>();
        mAdapter = new AdapterSelectImage(mContext, bitmaps);
        recyclerView.setAdapter(mAdapter);
        recyclerView.addOnItemTouchListener(new RecyclerTouchListener(mContext, recyclerView, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                imagesList.remove(position);
                bitmaps.remove(position);
                mAdapter.notifyDataSetChanged();
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));

        addimages = root.findViewById(R.id.image);

        addimages.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ActivityCompat.checkSelfPermission(mContext, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions((Activity) mContext, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_EXTERNAL_STORAGE);
//                    return;
                } else {
                    launchGalleryIntent();

                }
            }
        });
        bt_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                postdata();
            }
        });

    }
    public void launchGalleryIntent() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.putExtra(Intent.ACTION_GET_CONTENT, true);
        intent.setType("image/*");
        startActivityForResult(intent, REQUEST_EXTERNAL_STORAGE);
    }
    @Override
    public void onRequestPermissionsResult(int requestCode,String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case REQUEST_EXTERNAL_STORAGE: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    launchGalleryIntent();
                } else {
                }
                return;
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_EXTERNAL_STORAGE && resultCode == RESULT_OK) {

            Uri imageUri = data.getData();
            Log.d("URIImages1", imageUri.toString());

            try {
                InputStream inputStream = mContext.getContentResolver().openInputStream(imageUri);
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);

                setImage(bitmap,convertbitmaptostring(bitmap));

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }

        }

    }

    private void setImage(Bitmap bitmap, String convertbitmaptostring) {

        if (bitmaps.size()>=4){
            Toast.makeText(mContext, "Image Limit Reached", Toast.LENGTH_SHORT).show();
        }
        else{
            bitmaps.add(bitmap);
            imagesList.add(convertbitmaptostring);

        }
        mAdapter.notifyDataSetChanged();
    }

    public String convertbitmaptostring(Bitmap bitmap){

        ByteArrayOutputStream byteArrayOutputStreamObject  = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 40, byteArrayOutputStreamObject);

        byte[] byteArrayVar = byteArrayOutputStreamObject.toByteArray();
        final String ConvertImage = Base64.encodeToString(byteArrayVar, Base64.DEFAULT);
        return ConvertImage;
    }
    private void postdata() {

        final ProgressDialog progressDialog = new ProgressDialog(mContext);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();

        //first getting the values
        final String title = titleName.getText().toString();
        final String pricee = price.getText().toString();
        final String descriptionn = description.getText().toString();
        //validating inputs
        if (TextUtils.isEmpty(title)) {
            titleName.setError("Please enter Title");
            titleName.requestFocus();
            progressDialog.dismiss();
            return;
        }
        //Log.d("mypostdata",pricee+","+descriptionn+","+title+","+imagesList);
        Call<SellerPostResponse> call = RetrofitClient.getInstance().getApi().postdata(user_id,category_id,title,pricee,descriptionn,imagesList);
        call.enqueue(new Callback<SellerPostResponse>() {
            @Override
            public void onResponse(Call<SellerPostResponse> call, Response<SellerPostResponse> response) {
                progressDialog.dismiss();
                if(response.body().isApistatus()){
                    Toast.makeText(mContext.getApplicationContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                    startActivity(new Intent(mContext, MainActivity.class));
                    getActivity().finish();
                }
                else{
                    Toast.makeText(mContext.getApplicationContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<SellerPostResponse> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(mContext.getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();


            }
        });
    }

   /* @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.notifications_menu, menu);
    }
*/
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
         int id = item.getItemId();
        if (id == R.id.navigation_notifications_refresh) {

             return true;
        } return super.onOptionsItemSelected(item);
    }



    private Context mContext;
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mContext=context;
    }
}